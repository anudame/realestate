<template>
  <div id="app">
    <header class="header">
      <div class="container">
        <nav class="navbar">
          <router-link to="/" class="logo">
            <i class="fas fa-home"></i> RealEstate
          </router-link>
          <ul class="nav-links">
            <li><router-link to="/">Home</router-link></li>
            <li><router-link to="/properties">Properties</router-link></li>
            <li><router-link to="/about">About</router-link></li>
            <li><router-link to="/contact">Contact</router-link></li>
            <li v-if="isLoggedIn"><router-link to="/admin">Dashboard</router-link></li>
            <li v-if="isLoggedIn && authStore.user?.role === 'admin'">
              <router-link to="/super-admin" style="color: #ffc107;">
                <i class="fas fa-crown"></i> Super Admin
              </router-link>
            </li>
            <li v-if="isLoggedIn"><a href="#" @click.prevent="logout">Logout</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <main>
      <router-view />
    </main>

    <footer class="footer">
      <div class="container">
        <div class="footer-content">
          <div>
            <h3>About Us</h3>
            <p>Your trusted partner in finding the perfect property. We offer the best real estate deals in Ethiopia.</p>
          </div>
          <div>
            <h3>Quick Links</h3>
            <router-link to="/properties">Browse Properties</router-link>
            <router-link to="/about">About Us</router-link>
            <router-link to="/contact">Contact</router-link>
          </div>
          <div>
            <h3>Contact Info</h3>
            <p><i class="fas fa-phone"></i> +251 920 744 790</p>
            <p><i class="fas fa-phone"></i> +251 911 239 694</p>
            <p><i class="fas fa-envelope"></i> moti82284@gmail.com</p>
            <p><i class="fas fa-map-marker-alt"></i> Addis Ababa, Ethiopia</p>
          </div>
        </div>
        <div class="footer-bottom">
          <p>&copy; 2025 RealEstate. All rights reserved.</p>
        </div>
      </div>
    </footer>

    <!-- Global Dialog Component -->
    <Dialog
      :is-open="dialogState.isOpen"
      :type="dialogState.type"
      :title="dialogState.title"
      :message="dialogState.message"
      :confirm-text="dialogState.confirmText"
      :cancel-text="dialogState.cancelText"
      :show-cancel="dialogState.showCancel"
      @confirm="handleConfirm"
      @cancel="handleCancel"
      @close="closeDialog"
    />
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from './stores/auth'
import Dialog from './components/Dialog.vue'
import { useDialog } from './composables/useDialog'

const router = useRouter()
const authStore = useAuthStore()
const { dialogState, closeDialog, handleConfirm, handleCancel } = useDialog()

const isLoggedIn = computed(() => authStore.isAuthenticated)

const logout = () => {
  authStore.logout()
  router.push('/')
}
</script>
