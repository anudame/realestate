import axios from 'axios'

const api = axios.create({
  baseURL: '/api'
})

// Add token to requests
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export default {
  // Properties
  getProperties(params) {
    return api.get('/properties', { params })
  },
  getProperty(id) {
    return api.get(`/properties/${id}`)
  },
  createProperty(data) {
    return api.post('/properties', data)
  },
  updateProperty(id, data) {
    return api.put(`/properties/${id}`, data)
  },
  deleteProperty(id) {
    return api.delete(`/properties/${id}`)
  },
  duplicateProperty(id) {
    return api.post(`/properties/${id}/duplicate`)
  },
  archiveProperty(id) {
    return api.patch(`/properties/${id}/archive`)
  },
  toggleVisibility(id, is_hidden) {
    return api.patch(`/properties/${id}/visibility`, { is_hidden })
  },
  approveProperty(id) {
    return api.patch(`/properties/${id}/approve`)
  },
  uploadImages(id, formData) {
    return api.post(`/properties/${id}/images`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },
  uploadVideos(id, formData) {
    return api.post(`/properties/${id}/videos`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },
  getPropertyAnalytics(id) {
    return api.get(`/properties/${id}/analytics`)
  },

  // Public
  getCities() {
    return api.get('/public/cities')
  },
  getCategories() {
    return api.get('/public/categories')
  },
  getAmenities() {
    return api.get('/public/amenities')
  },
  getFeaturedProperties() {
    return api.get('/public/featured-properties')
  },
  submitInquiry(data) {
    return api.post('/public/inquiries', data)
  },
  submitBooking(data) {
    return api.post('/public/bookings', data)
  },
  submitReview(data) {
    return api.post('/public/reviews', data)
  },
  getReviews(propertyId) {
    return api.get(`/public/reviews/${propertyId}`)
  },
  submitContact(data) {
    return api.post('/public/contact', data)
  },

  // Admin
  getInquiries(params) {
    return api.get('/admin/inquiries', { params })
  },
  updateInquiry(id, data) {
    return api.put(`/admin/inquiries/${id}`, data)
  },
  getBookings(params) {
    return api.get('/admin/bookings', { params })
  },
  updateBooking(id, data) {
    return api.put(`/admin/bookings/${id}`, data)
  },
  getReviewsAdmin(params) {
    return api.get('/admin/reviews', { params })
  },
  updateReview(id, data) {
    return api.put(`/admin/reviews/${id}`, data)
  },
  deleteReview(id) {
    return api.delete(`/admin/reviews/${id}`)
  },
  getStats() {
    return api.get('/admin/stats')
  },

  // Auth
  login(email, password) {
    return api.post('/auth/login', { email, password })
  },
  getMe() {
    return api.get('/auth/me')
  },
  getUsers() {
    return api.get('/auth/users')
  },
  createUser(data) {
    return api.post('/auth/users', data)
  },
  updateUser(id, data) {
    return api.put(`/auth/users/${id}`, data)
  },
  deleteUser(id) {
    return api.delete(`/auth/users/${id}`)
  }
}
