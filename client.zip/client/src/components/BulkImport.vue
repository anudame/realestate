<template>
  <div class="bulk-import-container">
    <div class="bulk-import-actions">
      <button @click="downloadTemplate" class="btn btn-secondary">
        📥 Download {{ entityName }} Template
      </button>
      <label class="btn btn-secondary">
        📤 Bulk Import {{ entityName }}
        <input 
          type="file" 
          @change="handleFileSelect" 
          accept=".xlsx,.xls" 
          style="display: none"
          ref="fileInput"
        >
      </label>
    </div>

    <!-- Import Progress -->
    <div v-if="uploading" class="import-progress">
      <div class="spinner"></div>
      <p>Uploading and processing {{ fileName }}...</p>
    </div>

    <!-- Import Result Modal -->
    <div v-if="importResult" class="modal" @click.self="closeResult">
      <div class="modal-content">
        <h2>📊 Import Results</h2>
        
        <div class="result-summary">
          <div class="result-item success">
            <span class="icon">✅</span>
            <div>
              <div class="count">{{ importResult.successCount }}</div>
              <div class="label">Successfully Imported</div>
            </div>
          </div>
          
          <div v-if="importResult.errorCount > 0" class="result-item error">
            <span class="icon">❌</span>
            <div>
              <div class="count">{{ importResult.errorCount }}</div>
              <div class="label">Failed</div>
            </div>
          </div>
        </div>

        <p class="message">{{ importResult.message }}</p>

        <!-- Error Details -->
        <div v-if="importResult.errors && importResult.errors.length > 0" class="errors-section">
          <h3>⚠️ Error Details</h3>
          <div class="error-list">
            <div v-for="(err, idx) in importResult.errors" :key="idx" class="error-item">
              <span class="error-row">Row {{ err.row }}</span>
              <span class="error-data" v-if="err.data">{{ err.data }}</span>
              <span class="error-message">{{ err.error }}</span>
            </div>
          </div>
          <p class="error-tip">
            💡 Tip: Fix these errors in your Excel file and re-upload only the failed rows.
          </p>
        </div>

        <div class="modal-actions">
          <button @click="closeResult" class="btn btn-primary">
            {{ importResult.errorCount > 0 ? 'Close & Fix Errors' : 'Done' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../api'

export default {
  name: 'BulkImport',
  props: {
    entityType: {
      type: String,
      required: true,
      validator: (value) => ['medicines', 'stock', 'customers', 'suppliers', 'cosmetics'].includes(value)
    },
    entityName: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      uploading: false,
      fileName: '',
      importResult: null
    }
  },
  methods: {
    async downloadTemplate() {
      try {
        const response = await api.get(`/bulk-import/template/${this.entityType}`, {
          responseType: 'blob'
        })
        
        const url = window.URL.createObjectURL(new Blob([response.data]))
        const link = document.createElement('a')
        link.href = url
        link.setAttribute('download', `${this.entityType}_template.xlsx`)
        document.body.appendChild(link)
        link.click()
        link.remove()
        
        this.$emit('template-downloaded')
      } catch (error) {
        alert('Error downloading template: ' + error.message)
      }
    },
    
    async handleFileSelect(event) {
      const file = event.target.files[0]
      if (!file) return

      this.fileName = file.name
      this.uploading = true

      const formData = new FormData()
      formData.append('file', file)

      try {
        const { data } = await api.post(`/bulk-import/${this.entityType}`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        })
        
        this.importResult = data
        this.$emit('import-complete', data)
      } catch (error) {
        alert('Error importing file: ' + (error.response?.data?.error || error.message))
      } finally {
        this.uploading = false
        event.target.value = ''
      }
    },
    
    closeResult() {
      this.importResult = null
      this.$emit('result-closed')
    }
  }
}
</script>

<style scoped>
.bulk-import-container {
  margin: 10px 0;
}

.bulk-import-actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.import-progress {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 15px;
  background: #e3f2fd;
  border-radius: 8px;
  margin-top: 15px;
}

.spinner {
  width: 24px;
  height: 24px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid #3498db;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 30px;
  border-radius: 12px;
  max-width: 600px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0,0,0,0.2);
}

.modal-content h2 {
  margin-top: 0;
  color: #2c3e50;
}

.result-summary {
  display: flex;
  gap: 20px;
  margin: 20px 0;
}

.result-item {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 20px;
  border-radius: 8px;
  background: #f8f9fa;
}

.result-item.success {
  background: #d4edda;
  border: 2px solid #28a745;
}

.result-item.error {
  background: #f8d7da;
  border: 2px solid #dc3545;
}

.result-item .icon {
  font-size: 32px;
}

.result-item .count {
  font-size: 32px;
  font-weight: bold;
  color: #2c3e50;
}

.result-item .label {
  font-size: 14px;
  color: #6c757d;
}

.message {
  font-size: 16px;
  color: #495057;
  margin: 15px 0;
  padding: 15px;
  background: #f8f9fa;
  border-radius: 6px;
  text-align: center;
}

.errors-section {
  margin-top: 25px;
}

.errors-section h3 {
  color: #dc3545;
  margin-bottom: 15px;
}

.error-list {
  max-height: 300px;
  overflow-y: auto;
  background: #fff5f5;
  border: 1px solid #feb2b2;
  border-radius: 6px;
  padding: 10px;
}

.error-item {
  display: flex;
  gap: 10px;
  padding: 10px;
  margin-bottom: 8px;
  background: white;
  border-radius: 4px;
  border-left: 3px solid #dc3545;
  font-size: 14px;
}

.error-row {
  font-weight: bold;
  color: #dc3545;
  min-width: 60px;
}

.error-data {
  color: #6c757d;
  font-style: italic;
  min-width: 100px;
}

.error-message {
  color: #495057;
  flex: 1;
}

.error-tip {
  margin-top: 15px;
  padding: 12px;
  background: #fff3cd;
  border: 1px solid #ffc107;
  border-radius: 6px;
  font-size: 14px;
  color: #856404;
}

.modal-actions {
  display: flex;
  justify-content: center;
  margin-top: 25px;
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.3s;
}

.btn-primary {
  background: #3498db;
  color: white;
}

.btn-primary:hover {
  background: #2980b9;
}

.btn-secondary {
  background: #6c757d;
  color: white;
}

.btn-secondary:hover {
  background: #5a6268;
}
</style>
