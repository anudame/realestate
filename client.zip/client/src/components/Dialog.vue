<template>
  <Teleport to="body">
    <Transition name="dialog">
      <div v-if="isOpen" class="dialog-overlay" @click.self="handleCancel">
        <div class="dialog-box" :class="`dialog-${type}`">
          <div class="dialog-header">
            <div class="dialog-icon">
              <i v-if="type === 'success'" class="fas fa-check-circle"></i>
              <i v-else-if="type === 'error'" class="fas fa-times-circle"></i>
              <i v-else-if="type === 'warning'" class="fas fa-exclamation-triangle"></i>
              <i v-else-if="type === 'confirm'" class="fas fa-question-circle"></i>
              <i v-else class="fas fa-info-circle"></i>
            </div>
            <h3>{{ title }}</h3>
          </div>
          
          <div class="dialog-body">
            <p>{{ message }}</p>
          </div>
          
          <div class="dialog-footer">
            <button 
              v-if="showCancel" 
              class="btn btn-outline" 
              @click="handleCancel"
            >
              {{ cancelText }}
            </button>
            <button 
              class="btn" 
              :class="confirmButtonClass"
              @click="handleConfirm"
            >
              {{ confirmText }}
            </button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  isOpen: Boolean,
  type: {
    type: String,
    default: 'info', // info, success, error, warning, confirm
    validator: (value) => ['info', 'success', 'error', 'warning', 'confirm'].includes(value)
  },
  title: {
    type: String,
    default: 'Notification'
  },
  message: {
    type: String,
    required: true
  },
  confirmText: {
    type: String,
    default: 'OK'
  },
  cancelText: {
    type: String,
    default: 'Cancel'
  },
  showCancel: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['confirm', 'cancel', 'close'])

const confirmButtonClass = computed(() => {
  switch (props.type) {
    case 'success':
      return 'btn-success'
    case 'error':
      return 'btn-danger'
    case 'warning':
      return 'btn-warning'
    default:
      return 'btn-primary'
  }
})

const handleConfirm = () => {
  emit('confirm')
  emit('close')
}

const handleCancel = () => {
  emit('cancel')
  emit('close')
}
</script>

<style scoped>
.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  padding: 1rem;
}

.dialog-box {
  background: white;
  border-radius: 12px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
  max-width: 500px;
  width: 100%;
  animation: slideDown 0.3s ease-out;
}

@keyframes slideDown {
  from {
    transform: translateY(-50px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.dialog-header {
  padding: 2rem 2rem 1rem;
  text-align: center;
}

.dialog-icon {
  font-size: 3.5rem;
  margin-bottom: 1rem;
}

.dialog-success .dialog-icon {
  color: #28a745;
}

.dialog-error .dialog-icon {
  color: #dc3545;
}

.dialog-warning .dialog-icon {
  color: #ffc107;
}

.dialog-confirm .dialog-icon {
  color: #17a2b8;
}

.dialog-info .dialog-icon {
  color: #007bff;
}

.dialog-header h3 {
  margin: 0;
  font-size: 1.5rem;
  color: #333;
}

.dialog-body {
  padding: 1rem 2rem;
  text-align: center;
}

.dialog-body p {
  margin: 0;
  color: #666;
  font-size: 1rem;
  line-height: 1.6;
}

.dialog-footer {
  padding: 1rem 2rem 2rem;
  display: flex;
  gap: 1rem;
  justify-content: center;
}

.btn {
  padding: 0.75rem 2rem;
  border: none;
  border-radius: 6px;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  min-width: 100px;
}

.btn-primary {
  background: #007bff;
  color: white;
}

.btn-primary:hover {
  background: #0056b3;
}

.btn-success {
  background: #28a745;
  color: white;
}

.btn-success:hover {
  background: #218838;
}

.btn-danger {
  background: #dc3545;
  color: white;
}

.btn-danger:hover {
  background: #c82333;
}

.btn-warning {
  background: #ffc107;
  color: #333;
}

.btn-warning:hover {
  background: #e0a800;
}

.btn-outline {
  background: white;
  color: #666;
  border: 1px solid #ddd;
}

.btn-outline:hover {
  background: #f8f9fa;
  border-color: #999;
}

.dialog-enter-active,
.dialog-leave-active {
  transition: opacity 0.3s ease;
}

.dialog-enter-from,
.dialog-leave-to {
  opacity: 0;
}
</style>
