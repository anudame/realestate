<template>
  <div class="profile-container">
    <div class="profile-header">
      <h2>👤 My Profile</h2>
    </div>

    <div v-if="loading" class="loading">Loading profile...</div>

    <div v-else class="profile-content">
      <!-- Profile Information Card -->
      <div class="profile-card">
        <h3>Profile Information</h3>
        
        <div class="profile-info">
          <div class="info-row">
            <label>Username:</label>
            <span v-if="!editingProfile">{{ profile.username }}</span>
            <input v-else v-model="editForm.username" type="text" class="edit-input" required />
          </div>
          
          <div class="info-row">
            <label>Full Name:</label>
            <span v-if="!editingProfile">{{ profile.full_name }}</span>
            <input v-else v-model="editForm.fullName" type="text" class="edit-input" required />
          </div>
          
          <div class="info-row">
            <label>Role:</label>
            <span class="role-badge">{{ profile.role_name }}</span>
          </div>
          
          <div class="info-row">
            <label>Branch:</label>
            <span>{{ profile.branch_name || 'N/A' }}</span>
          </div>
          
          <div class="info-row">
            <label>Location:</label>
            <span>{{ profile.location || 'N/A' }}</span>
          </div>
          
          <div class="info-row">
            <label>Status:</label>
            <span :class="'status-badge ' + profile.status">{{ profile.status }}</span>
          </div>
          
          <div class="info-row">
            <label>Member Since:</label>
            <span>{{ formatDate(profile.created_at) }}</span>
          </div>
        </div>

        <div class="button-group">
          <button v-if="!editingProfile" @click="startEdit" class="btn btn-primary">
            ✏️ Edit Profile
          </button>
          <template v-else>
            <button @click="saveProfile" class="btn btn-success">💾 Save</button>
            <button @click="cancelEdit" class="btn btn-secondary">❌ Cancel</button>
          </template>
        </div>
      </div>

      <!-- Change Password Card -->
      <div class="profile-card">
        <h3>🔒 Change Password</h3>
        
        <div v-if="passwordMessage" :class="'message ' + passwordMessage.type">
          {{ passwordMessage.text }}
        </div>

        <form @submit.prevent="changePassword" class="password-form">
          <div class="form-group">
            <label>Current Password:</label>
            <input 
              v-model="passwordForm.currentPassword" 
              type="password" 
              required 
              class="form-input"
              placeholder="Enter current password"
            />
          </div>
          
          <div class="form-group">
            <label>New Password:</label>
            <input 
              v-model="passwordForm.newPassword" 
              type="password" 
              required 
              minlength="6"
              class="form-input"
              placeholder="Enter new password (min 6 characters)"
            />
          </div>
          
          <div class="form-group">
            <label>Confirm New Password:</label>
            <input 
              v-model="passwordForm.confirmPassword" 
              type="password" 
              required 
              class="form-input"
              placeholder="Confirm new password"
            />
          </div>

          <button type="submit" class="btn btn-primary">🔑 Change Password</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../api';

export default {
  name: 'Profile',
  data() {
    return {
      profile: {},
      loading: true,
      editingProfile: false,
      editForm: {
        username: '',
        fullName: ''
      },
      passwordForm: {
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      },
      passwordMessage: null
    };
  },
  mounted() {
    this.loadProfile();
  },
  methods: {
    async loadProfile() {
      try {
        this.loading = true;
        const response = await api.get('/users/profile');
        this.profile = response.data;
        this.editForm.username = this.profile.username;
        this.editForm.fullName = this.profile.full_name;
      } catch (error) {
        alert('Failed to load profile: ' + (error.response?.data?.error || error.message));
      } finally {
        this.loading = false;
      }
    },
    
    startEdit() {
      this.editingProfile = true;
      this.editForm.username = this.profile.username;
      this.editForm.fullName = this.profile.full_name;
    },
    
    cancelEdit() {
      this.editingProfile = false;
      this.editForm.username = this.profile.username;
      this.editForm.fullName = this.profile.full_name;
    },
    
    async saveProfile() {
      try {
        await api.patch('/users/profile', {
          username: this.editForm.username,
          fullName: this.editForm.fullName
        });
        
        this.profile.username = this.editForm.username;
        this.profile.full_name = this.editForm.fullName;
        this.editingProfile = false;
        
        // Update localStorage if username changed
        const user = JSON.parse(localStorage.getItem('user'));
        user.username = this.editForm.username;
        user.fullName = this.editForm.fullName;
        localStorage.setItem('user', JSON.stringify(user));
        
        alert('✅ Profile updated successfully!');
      } catch (error) {
        alert('Failed to update profile: ' + (error.response?.data?.error || error.message));
      }
    },
    
    async changePassword() {
      if (this.passwordForm.newPassword !== this.passwordForm.confirmPassword) {
        this.passwordMessage = { type: 'error', text: 'New passwords do not match!' };
        return;
      }
      
      if (this.passwordForm.newPassword.length < 6) {
        this.passwordMessage = { type: 'error', text: 'Password must be at least 6 characters!' };
        return;
      }
      
      try {
        await api.patch('/users/profile/password', {
          currentPassword: this.passwordForm.currentPassword,
          newPassword: this.passwordForm.newPassword
        });
        
        this.passwordMessage = { type: 'success', text: '✅ Password changed successfully!' };
        this.passwordForm = {
          currentPassword: '',
          newPassword: '',
          confirmPassword: ''
        };
        
        setTimeout(() => {
          this.passwordMessage = null;
        }, 3000);
      } catch (error) {
        this.passwordMessage = { 
          type: 'error', 
          text: error.response?.data?.error || 'Failed to change password' 
        };
      }
    },
    
    formatDate(dateString) {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    }
  }
};
</script>

<style scoped>
.profile-container {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.profile-header {
  margin-bottom: 30px;
}

.profile-header h2 {
  color: #2c3e50;
  font-size: 28px;
}

.loading {
  text-align: center;
  padding: 40px;
  color: #7f8c8d;
}

.profile-content {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 20px;
}

.profile-card {
  background: white;
  border-radius: 12px;
  padding: 25px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.profile-card h3 {
  color: #2c3e50;
  margin-bottom: 20px;
  font-size: 20px;
  border-bottom: 2px solid #3498db;
  padding-bottom: 10px;
}

.profile-info {
  margin-bottom: 20px;
}

.info-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  border-bottom: 1px solid #ecf0f1;
}

.info-row label {
  font-weight: 600;
  color: #7f8c8d;
}

.info-row span {
  color: #2c3e50;
}

.role-badge {
  background: #3498db;
  color: white;
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 600;
}

.status-badge {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 600;
  text-transform: uppercase;
}

.status-badge.active {
  background: #27ae60;
  color: white;
}

.status-badge.inactive {
  background: #e74c3c;
  color: white;
}

.edit-input {
  padding: 6px 12px;
  border: 2px solid #3498db;
  border-radius: 6px;
  font-size: 14px;
  width: 60%;
}

.button-group {
  display: flex;
  gap: 10px;
  margin-top: 20px;
}

.password-form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-group label {
  font-weight: 600;
  color: #2c3e50;
}

.form-input {
  padding: 10px;
  border: 2px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
}

.form-input:focus {
  outline: none;
  border-color: #3498db;
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: all 0.3s;
}

.btn-primary {
  background: #3498db;
  color: white;
}

.btn-primary:hover {
  background: #2980b9;
}

.btn-success {
  background: #27ae60;
  color: white;
}

.btn-success:hover {
  background: #229954;
}

.btn-secondary {
  background: #95a5a6;
  color: white;
}

.btn-secondary:hover {
  background: #7f8c8d;
}

.message {
  padding: 12px;
  border-radius: 6px;
  margin-bottom: 15px;
  font-weight: 500;
}

.message.success {
  background: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.message.error {
  background: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}
</style>
