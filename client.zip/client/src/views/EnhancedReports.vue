<template>
  <div class="container">
    <v-card elevation="2" class="mb-4">
      <v-card-title class="d-flex align-center">
        <v-icon class="mr-2">mdi-chart-box</v-icon>
        Reports & Analytics
      </v-card-title>
    </v-card>

    <!-- Report Type Tabs -->
    <v-card elevation="2" class="mb-4">
      <v-tabs v-model="activeTab" bg-color="primary">
        <v-tab value="sales">
          <v-icon class="mr-2">mdi-cash-register</v-icon>
          Sales
        </v-tab>
        <v-tab value="inventory">
          <v-icon class="mr-2">mdi-package-variant</v-icon>
          Inventory
        </v-tab>
        <v-tab value="expiry">
          <v-icon class="mr-2">mdi-calendar-alert</v-icon>
          Expiry
        </v-tab>
        <v-tab value="topProducts">
          <v-icon class="mr-2">mdi-star</v-icon>
          Top Products
        </v-tab>
        <v-tab value="slowMoving">
          <v-icon class="mr-2">mdi-turtle</v-icon>
          Slow Moving
        </v-tab>
        <v-tab value="branch">
          <v-icon class="mr-2">mdi-office-building</v-icon>
          Branch Performance
        </v-tab>
      </v-tabs>
    </v-card>

    <!-- Filters -->
    <v-card elevation="2" class="mb-4">
      <v-card-text>
        <v-row>
          <v-col cols="12" md="3">
            <v-text-field
              v-model="filters.fromDate"
              label="From Date"
              type="date"
              variant="outlined"
              density="compact"
            ></v-text-field>
          </v-col>
          <v-col cols="12" md="3">
            <v-text-field
              v-model="filters.toDate"
              label="To Date"
              type="date"
              variant="outlined"
              density="compact"
            ></v-text-field>
          </v-col>
          <v-col cols="12" md="3">
            <v-select
              v-model="filters.branchId"
              :items="branches"
              item-title="branch_name"
              item-value="branch_id"
              label="Branch"
              variant="outlined"
              density="compact"
              clearable
            ></v-select>
          </v-col>
          <v-col cols="12" md="3" class="d-flex gap-2">
            <v-btn
              @click="loadReport"
              color="primary"
              prepend-icon="mdi-magnify"
              block
            >
              Generate
            </v-btn>
            <v-btn
              @click="exportToExcel"
              color="success"
              prepend-icon="mdi-file-excel"
              :disabled="!reportData"
              block
            >
              Export
            </v-btn>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>

    <!-- Loading -->
    <v-card v-if="loading" class="text-center pa-8">
      <v-progress-circular indeterminate color="primary" size="64"></v-progress-circular>
      <p class="mt-4">Loading report...</p>
    </v-card>

    <!-- Report Content -->
    <div v-if="!loading && reportData">
      <!-- Sales Report -->
      <div v-if="activeTab === 'sales'">
        <v-row>
          <v-col cols="12" md="3">
            <v-card color="primary" dark>
              <v-card-text>
                <div class="text-h6">Total Sales</div>
                <div class="text-h4">ETB {{ formatNumber(reportData.totalSales) }}</div>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="12" md="3">
            <v-card color="success" dark>
              <v-card-text>
                <div class="text-h6">Transactions</div>
                <div class="text-h4">{{ reportData.transactionCount }}</div>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="12" md="3">
            <v-card color="info" dark>
              <v-card-text>
                <div class="text-h6">Avg Transaction</div>
                <div class="text-h4">ETB {{ formatNumber(reportData.avgTransaction) }}</div>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="12" md="3">
            <v-card color="warning" dark>
              <v-card-text>
                <div class="text-h6">Profit</div>
                <div class="text-h4">ETB {{ formatNumber(reportData.totalProfit) }}</div>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>

        <v-card class="mt-4">
          <v-card-title>Sales Details</v-card-title>
          <v-card-text>
            <v-table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Invoice No</th>
                  <th>Items</th>
                  <th>Amount</th>
                  <th>Payment Method</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="sale in reportData.sales" :key="sale.invoice_id">
                  <td>{{ formatDate(sale.sale_date) }}</td>
                  <td>{{ sale.invoice_number }}</td>
                  <td>{{ sale.item_count }}</td>
                  <td>ETB {{ formatNumber(sale.total_amount) }}</td>
                  <td>{{ sale.payment_method }}</td>
                </tr>
              </tbody>
            </v-table>
          </v-card-text>
        </v-card>
      </div>

      <!-- Inventory Valuation Report -->
      <div v-if="activeTab === 'inventory'">
        <v-row>
          <v-col cols="12" md="4">
            <v-card color="primary" dark>
              <v-card-text>
                <div class="text-h6">Total Inventory Value</div>
                <div class="text-h4">ETB {{ formatNumber(reportData.totalValue) }}</div>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="12" md="4">
            <v-card color="success" dark>
              <v-card-text>
                <div class="text-h6">Total Items</div>
                <div class="text-h4">{{ reportData.totalItems }}</div>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="12" md="4">
            <v-card color="warning" dark>
              <v-card-text>
                <div class="text-h6">Low Stock Items</div>
                <div class="text-h4">{{ reportData.lowStockCount }}</div>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>

        <v-card class="mt-4">
          <v-card-title>Inventory by Category</v-card-title>
          <v-card-text>
            <v-table>
              <thead>
                <tr>
                  <th>Category</th>
                  <th>Items</th>
                  <th>Total Quantity</th>
                  <th>Value</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="cat in reportData.byCategory" :key="cat.category">
                  <td>{{ cat.category }}</td>
                  <td>{{ cat.item_count }}</td>
                  <td>{{ cat.total_quantity }}</td>
                  <td>ETB {{ formatNumber(cat.total_value) }}</td>
                </tr>
              </tbody>
            </v-table>
          </v-card-text>
        </v-card>
      </div>

      <!-- Expiry Report -->
      <div v-if="activeTab === 'expiry'">
        <v-row>
          <v-col cols="12" md="3">
            <v-card color="error" dark>
              <v-card-text>
                <div class="text-h6">Expired</div>
                <div class="text-h4">{{ reportData.expired.count }}</div>
                <div class="text-caption">ETB {{ formatNumber(reportData.expired.value) }}</div>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="12" md="3">
            <v-card color="warning" dark>
              <v-card-text>
                <div class="text-h6">This Month</div>
                <div class="text-h4">{{ reportData.thisMonth.count }}</div>
                <div class="text-caption">ETB {{ formatNumber(reportData.thisMonth.value) }}</div>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="12" md="3">
            <v-card color="orange" dark>
              <v-card-text>
                <div class="text-h6">Next 3 Months</div>
                <div class="text-h4">{{ reportData.next3Months.count }}</div>
                <div class="text-caption">ETB {{ formatNumber(reportData.next3Months.value) }}</div>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col cols="12" md="3">
            <v-card color="info" dark>
              <v-card-text>
                <div class="text-h6">Next 6 Months</div>
                <div class="text-h4">{{ reportData.next6Months.count }}</div>
                <div class="text-caption">ETB {{ formatNumber(reportData.next6Months.value) }}</div>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>

        <v-card class="mt-4">
          <v-card-title>Expiring Items Details</v-card-title>
          <v-card-text>
            <v-table>
              <thead>
                <tr>
                  <th>Medicine</th>
                  <th>Batch Number</th>
                  <th>Expiry Date</th>
                  <th>Quantity</th>
                  <th>Value</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="item in reportData.items" :key="item.batch_id">
                  <td>{{ item.medicine_name }}</td>
                  <td>{{ item.batch_number }}</td>
                  <td>{{ formatDate(item.expiry_date) }}</td>
                  <td>{{ item.quantity }}</td>
                  <td>ETB {{ formatNumber(item.value) }}</td>
                  <td>
                    <v-chip :color="getExpiryColor(item.days_until_expiry)" size="small">
                      {{ getExpiryStatus(item.days_until_expiry) }}
                    </v-chip>
                  </td>
                </tr>
              </tbody>
            </v-table>
          </v-card-text>
        </v-card>
      </div>

      <!-- Top Products Report -->
      <div v-if="activeTab === 'topProducts'">
        <v-card>
          <v-card-title>Top Selling Products</v-card-title>
          <v-card-text>
            <v-table>
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Product</th>
                  <th>Quantity Sold</th>
                  <th>Revenue</th>
                  <th>Profit</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(product, idx) in reportData.topProducts" :key="product.medicine_id">
                  <td>
                    <v-chip :color="idx < 3 ? 'success' : 'default'" size="small">
                      #{{ idx + 1 }}
                    </v-chip>
                  </td>
                  <td>{{ product.medicine_name }}</td>
                  <td>{{ product.quantity_sold }}</td>
                  <td>ETB {{ formatNumber(product.revenue) }}</td>
                  <td>ETB {{ formatNumber(product.profit) }}</td>
                </tr>
              </tbody>
            </v-table>
          </v-card-text>
        </v-card>
      </div>

      <!-- Slow Moving Stock Report -->
      <div v-if="activeTab === 'slowMoving'">
        <v-card>
          <v-card-title>Slow Moving Stock</v-card-title>
          <v-card-subtitle>Items with no sales in the selected period</v-card-subtitle>
          <v-card-text>
            <v-table>
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Category</th>
                  <th>Current Stock</th>
                  <th>Value</th>
                  <th>Last Sale Date</th>
                  <th>Days Since Sale</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="item in reportData.slowMoving" :key="item.medicine_id">
                  <td>{{ item.medicine_name }}</td>
                  <td>{{ item.category }}</td>
                  <td>{{ item.current_stock }}</td>
                  <td>ETB {{ formatNumber(item.value) }}</td>
                  <td>{{ item.last_sale_date ? formatDate(item.last_sale_date) : 'Never' }}</td>
                  <td>
                    <v-chip :color="item.days_since_sale > 90 ? 'error' : 'warning'" size="small">
                      {{ item.days_since_sale || 'N/A' }} days
                    </v-chip>
                  </td>
                </tr>
              </tbody>
            </v-table>
          </v-card-text>
        </v-card>
      </div>

      <!-- Branch Performance Report -->
      <div v-if="activeTab === 'branch'">
        <v-card>
          <v-card-title>Branch Performance Comparison</v-card-title>
          <v-card-text>
            <v-table>
              <thead>
                <tr>
                  <th>Branch</th>
                  <th>Sales</th>
                  <th>Transactions</th>
                  <th>Avg Transaction</th>
                  <th>Stock Value</th>
                  <th>Performance</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="branch in reportData.branches" :key="branch.branch_id">
                  <td>{{ branch.branch_name }}</td>
                  <td>ETB {{ formatNumber(branch.total_sales) }}</td>
                  <td>{{ branch.transaction_count }}</td>
                  <td>ETB {{ formatNumber(branch.avg_transaction) }}</td>
                  <td>ETB {{ formatNumber(branch.stock_value) }}</td>
                  <td>
                    <v-progress-linear
                      :model-value="branch.performance_score"
                      :color="branch.performance_score > 75 ? 'success' : 'warning'"
                      height="20"
                    >
                      {{ branch.performance_score }}%
                    </v-progress-linear>
                  </td>
                </tr>
              </tbody>
            </v-table>
          </v-card-text>
        </v-card>
      </div>
    </div>

    <!-- No Data -->
    <v-card v-if="!loading && !reportData" class="text-center pa-8">
      <v-icon size="64" color="grey">mdi-chart-line</v-icon>
      <p class="mt-4 text-grey">Select filters and click Generate to view report</p>
    </v-card>
  </div>
</template>

<script>
import api from '../api'
import * as XLSX from 'xlsx'

export default {
  data() {
    return {
      activeTab: 'sales',
      loading: false,
      reportData: null,
      branches: [],
      filters: {
        fromDate: this.getDefaultFromDate(),
        toDate: this.getDefaultToDate(),
        branchId: null
      }
    }
  },
  async mounted() {
    await this.loadBranches()
  },
  methods: {
    getDefaultFromDate() {
      const date = new Date()
      date.setDate(1) // First day of month
      return date.toISOString().split('T')[0]
    },
    getDefaultToDate() {
      return new Date().toISOString().split('T')[0]
    },
    async loadBranches() {
      try {
        const { data } = await api.get('/branches')
        this.branches = [{ branch_id: null, branch_name: 'All Branches' }, ...data]
      } catch (error) {
        console.error('Error loading branches:', error)
      }
    },
    async loadReport() {
      this.loading = true
      try {
        const params = {
          fromDate: this.filters.fromDate,
          toDate: this.filters.toDate,
          branchId: this.filters.branchId
        }
        
        const { data } = await api.get(`/reports/${this.activeTab}`, { params })
        this.reportData = data
      } catch (error) {
        alert('Error loading report: ' + error.message)
      } finally {
        this.loading = false
      }
    },
    formatNumber(num) {
      return Number(num || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    },
    formatDate(dateString) {
      if (!dateString) return '-'
      return new Date(dateString).toLocaleDateString()
    },
    getExpiryColor(days) {
      if (days < 0) return 'error'
      if (days < 30) return 'warning'
      if (days < 90) return 'orange'
      return 'info'
    },
    getExpiryStatus(days) {
      if (days < 0) return 'Expired'
      if (days < 30) return 'Critical'
      if (days < 90) return 'Warning'
      return 'OK'
    },
    exportToExcel() {
      if (!this.reportData) return
      
      let data = []
      let filename = `${this.activeTab}_report_${this.filters.fromDate}_to_${this.filters.toDate}.xlsx`
      
      // Prepare data based on report type
      switch (this.activeTab) {
        case 'sales':
          data = this.reportData.sales
          break
        case 'inventory':
          data = this.reportData.byCategory
          break
        case 'expiry':
          data = this.reportData.items
          break
        case 'topProducts':
          data = this.reportData.topProducts
          break
        case 'slowMoving':
          data = this.reportData.slowMoving
          break
        case 'branch':
          data = this.reportData.branches
          break
      }
      
      const ws = XLSX.utils.json_to_sheet(data)
      const wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, ws, this.activeTab)
      XLSX.writeFile(wb, filename)
    }
  }
}
</script>

<style scoped>
.d-flex {
  display: flex;
}

.gap-2 {
  gap: 8px;
}
</style>
