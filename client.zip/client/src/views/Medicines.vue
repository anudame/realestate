<template>
  <div class="container">
    <div class="header-row">
      <h1>Medicines</h1>
      <div class="actions">
        <button @click="showAddModal = true" class="btn btn-primary">
          ➕ Add Medicine
        </button>
      </div>
    </div>

    <!-- Search -->
    <div class="card">
      <input 
        v-model="searchQuery" 
        type="text" 
        placeholder="Search by name, barcode, or SKU..." 
        class="search-input"
      >
    </div>

    <!-- Medicines Table -->
    <div class="card">
      <table class="table">
        <thead>
          <tr>
            <th>Generic Name</th>
            <th>Brand Name</th>
            <th>Category</th>
            <th>Form</th>
            <th>Strength</th>
            <th>Barcode</th>
            <th>SKU</th>
            <th>Stock</th>
            <th>Price</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="med in filteredMedicines" :key="med.medicine_id">
            <td>{{ med.generic_name }}</td>
            <td>{{ med.brand_name || '-' }}</td>
            <td>{{ med.category_name || '-' }}</td>
            <td>{{ med.form_name || '-' }}</td>
            <td>{{ med.strength || '-' }}</td>
            <td>{{ med.barcode || '-' }}</td>
            <td>{{ med.sku || '-' }}</td>
            <td :class="{'low-stock': med.total_stock <= med.reorder_level}">
              {{ med.total_stock }}
            </td>
            <td>₹{{ med.default_selling_price }}</td>
            <td>
              <button @click="editMedicine(med)" class="btn-small">✏️</button>
              <button @click="deleteMedicine(med.medicine_id)" class="btn-small btn-danger">🗑️</button>
            </td>
          </tr>
        </tbody>
      </table>
      <p v-if="filteredMedicines.length === 0" class="no-data">No medicines found</p>
    </div>

    <!-- Add/Edit Medicine Modal -->
    <div v-if="showAddModal" class="modal" @click.self="closeModal">
      <div class="modal-content">
        <h2>{{ editingMedicine ? 'Edit Medicine' : 'Add New Medicine' }}</h2>
        <form @submit.prevent="saveMedicine">
          <div class="form-row">
            <div class="form-group">
              <label>Generic Name *</label>
              <input v-model="form.genericName" required>
            </div>
            <div class="form-group">
              <label>Brand Name</label>
              <input v-model="form.brandName">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Category</label>
              <input v-model="form.category" 
                     list="categories" 
                     placeholder="Type or select category">
              <datalist id="categories">
                <option v-for="cat in categories" :key="cat" :value="cat"></option>
              </datalist>
            </div>
            <div class="form-group">
              <label>Form</label>
              <input v-model="form.form" 
                     list="forms" 
                     placeholder="Type or select form">
              <datalist id="forms">
                <option v-for="f in forms" :key="f" :value="f"></option>
              </datalist>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Strength</label>
              <input v-model="form.strength" placeholder="e.g., 500mg">
            </div>
            <div class="form-group">
              <label>Barcode</label>
              <input v-model="form.barcode">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>SKU</label>
              <input v-model="form.sku">
            </div>
            <div class="form-group">
              <label>Reorder Level</label>
              <input v-model.number="form.reorderLevel" type="number" min="0">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Purchase Price *</label>
              <input v-model.number="form.purchasePrice" type="number" step="0.01" required>
            </div>
            <div class="form-group">
              <label>Selling Price *</label>
              <input v-model.number="form.sellingPrice" type="number" step="0.01" required>
            </div>
          </div>

          <div class="modal-actions">
            <button type="button" @click="closeModal" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn btn-primary">
              {{ editingMedicine ? 'Update' : 'Add' }} Medicine
            </button>
          </div>
        </form>
      </div>
    </div>

  </div>
</template>

<script>
import api from '../api'

export default {
  data() {
    return {
      medicines: [],
      searchQuery: '',
      showAddModal: false,
      editingMedicine: null,
      categories: [],
      forms: [],
      form: {
        genericName: '',
        brandName: '',
        category: '',
        form: '',
        strength: '',
        barcode: '',
        sku: '',
        purchasePrice: 0,
        sellingPrice: 0,
        reorderLevel: 10
      }
    }
  },
  computed: {
    filteredMedicines() {
      if (!this.searchQuery) return this.medicines
      const query = this.searchQuery.toLowerCase()
      return this.medicines.filter(med => 
        med.generic_name?.toLowerCase().includes(query) ||
        med.brand_name?.toLowerCase().includes(query) ||
        med.barcode?.toLowerCase().includes(query) ||
        med.sku?.toLowerCase().includes(query)
      )
    }
  },
  async mounted() {
    await this.loadMedicines()
    await this.loadCategories()
    await this.loadForms()
  },
  methods: {
    async loadMedicines() {
      try {
        const { data } = await api.get('/medicines')
        this.medicines = data
      } catch (error) {
        alert('Error loading medicines: ' + error.message)
      }
    },
    async loadCategories() {
      try {
        const { data } = await api.get('/categories')
        this.categories = data.map(c => c.category_name)
      } catch (error) {
        console.error('Error loading categories:', error)
      }
    },
    async loadForms() {
      try {
        const { data } = await api.get('/forms')
        this.forms = data.map(f => f.form_name)
      } catch (error) {
        console.error('Error loading forms:', error)
      }
    },
    editMedicine(med) {
      this.editingMedicine = med
      this.form = {
        genericName: med.generic_name,
        brandName: med.brand_name || '',
        category: med.category_name || '',
        form: med.form_name || '',
        strength: med.strength || '',
        barcode: med.barcode || '',
        sku: med.sku || '',
        purchasePrice: med.default_purchase_price || 0,
        sellingPrice: med.default_selling_price || 0,
        reorderLevel: med.reorder_level || 10
      }
      this.showAddModal = true
    },
    async saveMedicine() {
      try {
        const payload = {
          genericName: this.form.genericName,
          brandName: this.form.brandName,
          category: this.form.category,
          form: this.form.form,
          strength: this.form.strength,
          barcode: this.form.barcode,
          sku: this.form.sku,
          purchasePrice: this.form.purchasePrice,
          sellingPrice: this.form.sellingPrice,
          reorderLevel: this.form.reorderLevel
        }

        if (this.editingMedicine) {
          await api.put(`/medicines/${this.editingMedicine.medicine_id}`, payload)
          alert('Medicine updated successfully!')
        } else {
          await api.post('/medicines', payload)
          alert('Medicine added successfully!')
        }

        this.closeModal()
        await this.loadMedicines()
      } catch (error) {
        alert('Error saving medicine: ' + error.message)
      }
    },
    async deleteMedicine(id) {
      if (!confirm('Are you sure you want to delete this medicine?')) return
      
      try {
        await api.delete(`/medicines/${id}`)
        alert('Medicine deleted successfully!')
        await this.loadMedicines()
      } catch (error) {
        alert('Error deleting medicine: ' + error.message)
      }
    },
    closeModal() {
      this.showAddModal = false
      this.editingMedicine = null
      this.form = {
        genericName: '',
        brandName: '',
        category: '',
        form: '',
        strength: '',
        barcode: '',
        sku: '',
        purchasePrice: 0,
        sellingPrice: 0,
        reorderLevel: 10
      }
    }
  }
}
</script>

<style scoped>
.header-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.actions {
  display: flex;
  gap: 10px;
}

.search-input {
  width: 100%;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.low-stock {
  color: #e74c3c;
  font-weight: bold;
}

.btn-small {
  padding: 5px 10px;
  margin: 0 2px;
  border: none;
  background: #3498db;
  color: white;
  border-radius: 4px;
  cursor: pointer;
}

.btn-small.btn-danger {
  background: #e74c3c;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 30px;
  border-radius: 8px;
  max-width: 600px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 15px;
  margin-bottom: 15px;
}

.form-group {
  display: flex;
  flex-direction: column;
}

.form-group label {
  margin-bottom: 5px;
  font-weight: bold;
}

.form-group input {
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}

.no-data {
  text-align: center;
  padding: 20px;
  color: #999;
}

.error-list {
  max-height: 200px;
  overflow-y: auto;
  background: #fee;
  padding: 10px;
  border-radius: 4px;
}

.success {
  color: #27ae60;
  font-weight: bold;
}

.error {
  color: #e74c3c;
  font-weight: bold;
}
</style>
