<template>
  <div class="container" style="padding: 3rem 0;">
    <h1>Contact Us</h1>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-top: 2rem;">
      <div class="info-section">
        <h2>Send us a Message</h2>
        <form @submit.prevent="submitContact">
          <div class="form-group">
            <label>Name</label>
            <input v-model="form.name" type="text" required>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input v-model="form.email" type="email" required>
          </div>
          <div class="form-group">
            <label>Phone</label>
            <input v-model="form.phone" type="tel">
          </div>
          <div class="form-group">
            <label>Subject</label>
            <input v-model="form.subject" type="text">
          </div>
          <div class="form-group">
            <label>Message</label>
            <textarea v-model="form.message" required></textarea>
          </div>
          
          <div v-if="success" class="alert alert-success">
            Message sent successfully!
          </div>
          
          <button type="submit" class="btn btn-primary" :disabled="loading">
            {{ loading ? 'Sending...' : 'Send Message' }}
          </button>
        </form>
      </div>

      <div class="info-section">
        <h2>Contact Information</h2>
        <div style="line-height: 2.5;">
          <p><i class="fas fa-map-marker-alt"></i> <strong>Address:</strong><br>Addis Ababa, Ethiopia</p>
          <p><i class="fas fa-phone"></i> <strong>Phone:</strong><br>+251 920 744 790<br>+251 911 239 694</p>
          <p><i class="fas fa-envelope"></i> <strong>Email:</strong><br>moti82284@gmail.com</p>
          <p><i class="fas fa-clock"></i> <strong>Hours:</strong><br>Mon-Fri: 9:00 AM - 6:00 PM<br>Sat: 10:00 AM - 4:00 PM</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import api from '../api'

const loading = ref(false)
const success = ref(false)

const form = ref({
  name: '',
  email: '',
  phone: '',
  subject: '',
  message: ''
})

const submitContact = async () => {
  loading.value = true
  success.value = false
  
  try {
    await api.submitContact(form.value)
    success.value = true
    form.value = { name: '', email: '', phone: '', subject: '', message: '' }
  } catch (error) {
    alert('Error sending message. Please try again.')
  } finally {
    loading.value = false
  }
}
</script>
