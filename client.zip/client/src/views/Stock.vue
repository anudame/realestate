<template>
  <div class="container">
    <h1>Stock Management</h1>
    
    <div class="card">
      <h3>Near Expiry Items</h3>
      <table class="table">
        <thead>
          <tr>
            <th>Medicine</th>
            <th>Batch Number</th>
            <th>Expiry Date</th>
            <th>Quantity</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in nearExpiry" :key="item.batch_id">
            <td>{{ item.generic_name }} - {{ item.brand_name }}</td>
            <td>{{ item.batch_number }}</td>
            <td>{{ new Date(item.expiry_date).toLocaleDateString() }}</td>
            <td>{{ item.quantity_in_stock }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import api from '../api'

export default {
  data() {
    return {
      nearExpiry: []
    }
  },
  async mounted() {
    const { data } = await api.get('/stock/near-expiry')
    this.nearExpiry = data
  }
}
</script>
