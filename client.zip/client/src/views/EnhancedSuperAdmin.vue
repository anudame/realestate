<template>
  <v-container fluid class="pa-6">
    <v-row>
      <v-col cols="12">
        <div class="d-flex align-center mb-6">
          <v-icon size="48" color="primary" class="mr-3">mdi-shield-crown</v-icon>
          <div>
            <h1 class="text-h4 font-weight-bold">Super Admin Control Center</h1>
            <p class="text-subtitle-1 text-grey">System-wide configuration and oversight</p>
          </div>
        </div>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="6" md="3">
        <v-card elevation="2" color="primary" dark>
          <v-card-text>
            <div class="d-flex align-center">
              <v-avatar color="white" size="56" class="mr-4">
                <v-icon size="32" color="primary">mdi-office-building</v-icon>
              </v-avatar>
              <div>
                <div class="text-h4 font-weight-bold">{{ branches.length }}</div>
                <div class="text-subtitle-2">Active Branches</div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card elevation="2" color="success" dark>
          <v-card-text>
            <div class="d-flex align-center">
              <v-avatar color="white" size="56" class="mr-4">
                <v-icon size="32" color="success">mdi-account-group</v-icon>
              </v-avatar>
              <div>
                <div class="text-h4 font-weight-bold">{{ users.length }}</div>
                <div class="text-subtitle-2">Active Users</div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <v-row class="mt-4">
      <v-col cols="12" md="6">
        <v-card elevation="2">
          <v-card-title>
            <v-icon left>mdi-account-multiple</v-icon>
            User Management
          </v-card-title>
          <v-card-text>
            <p>Control user accounts, roles, permissions, and access across all branches.</p>
          </v-card-text>
          <v-card-actions>
            <v-btn color="primary" @click="$router.push('/users')">Manage Users</v-btn>
          </v-card-actions>
        </v-card>
      </v-col>

      <v-col cols="12" md="6">
        <v-card elevation="2">
          <v-card-title>
            <v-icon left>mdi-office-building</v-icon>
            Branch Management
          </v-card-title>
          <v-card-text>
            <p>Configure and manage pharmacy branches across your organization.</p>
          </v-card-text>
          <v-card-actions>
            <v-btn color="primary" @click="$router.push('/branches')">Manage Branches</v-btn>
          </v-card-actions>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import api from '../api';

export default {
  name: 'EnhancedSuperAdmin',
  data() {
    return {
      branches: [],
      users: []
    };
  },
  mounted() {
    this.loadData();
  },
  methods: {
    async loadData() {
      try {
        const [branchesRes, usersRes] = await Promise.all([
          api.get('/branches'),
          api.get('/users')
        ]);
        this.branches = branchesRes.data;
        this.users = usersRes.data;
      } catch (error) {
        console.error('Error loading data:', error);
      }
    }
  }
};
</script>
