<template>
  <div class="container">
    <h1>📊 Bulk Import Center</h1>
    <p class="subtitle">Import large amounts of data quickly using Excel files</p>

    <!-- Import Cards -->
    <div class="import-grid">
      <!-- Medicines -->
      <div class="import-card">
        <div class="card-icon">💊</div>
        <h3>Medicines</h3>
        <p>Import medicine catalog with batch stock information</p>
        <BulkImport 
          entity-type="medicines"
          entity-name="Medicines"
          @import-complete="handleImportComplete"
        />
        <div class="card-info">
          <small>Includes: Generic name, brand, category, form, strength, pricing, batch info</small>
        </div>
      </div>

      <!-- Stock -->
      <div class="import-card">
        <div class="card-icon">📦</div>
        <h3>Stock Batches</h3>
        <p>Add stock batches to existing medicines</p>
        <BulkImport 
          entity-type="stock"
          entity-name="Stock"
          @import-complete="handleImportComplete"
        />
        <div class="card-info">
          <small>Includes: Batch number, quantity, expiry date, warehouse location</small>
        </div>
      </div>

      <!-- Customers -->
      <div class="import-card">
        <div class="card-icon">👥</div>
        <h3>Customers</h3>
        <p>Import customer and patient records</p>
        <BulkImport 
          entity-type="customers"
          entity-name="Customers"
          @import-complete="handleImportComplete"
        />
        <div class="card-info">
          <small>Includes: Name, phone, email, address, credit limit</small>
        </div>
      </div>

      <!-- Suppliers -->
      <div class="import-card">
        <div class="card-icon">🏢</div>
        <h3>Suppliers</h3>
        <p>Import supplier information</p>
        <BulkImport 
          entity-type="suppliers"
          entity-name="Suppliers"
          @import-complete="handleImportComplete"
        />
        <div class="card-info">
          <small>Includes: Name, contact person, phone, email, payment terms</small>
        </div>
      </div>

      <!-- Cosmetics -->
      <div class="import-card">
        <div class="card-icon">💄</div>
        <h3>Cosmetics</h3>
        <p>Import cosmetic products</p>
        <BulkImport 
          entity-type="cosmetics"
          entity-name="Cosmetics"
          @import-complete="handleImportComplete"
        />
        <div class="card-info">
          <small>Includes: Product name, brand, category, pricing, quantity</small>
        </div>
      </div>
    </div>

    <!-- Quick Guide -->
    <div class="card guide-section">
      <h2>📖 Quick Guide</h2>
      
      <div class="guide-steps">
        <div class="step">
          <div class="step-number">1</div>
          <div class="step-content">
            <h4>Download Template</h4>
            <p>Click "Download Template" for the data type you want to import</p>
          </div>
        </div>

        <div class="step">
          <div class="step-number">2</div>
          <div class="step-content">
            <h4>Fill Your Data</h4>
            <p>Open the Excel file and fill in your data. Follow the format shown in the template</p>
          </div>
        </div>

        <div class="step">
          <div class="step-number">3</div>
          <div class="step-content">
            <h4>Upload File</h4>
            <p>Click "Bulk Import" and select your filled Excel file</p>
          </div>
        </div>

        <div class="step">
          <div class="step-number">4</div>
          <div class="step-content">
            <h4>Review Results</h4>
            <p>Check the import results. Fix any errors and re-upload if needed</p>
          </div>
        </div>
      </div>

      <div class="tips">
        <h4>💡 Tips for Success</h4>
        <ul>
          <li>Always download and use the template to ensure correct format</li>
          <li>Test with a small file (5-10 rows) first</li>
          <li>Use YYYY-MM-DD format for dates (e.g., 2025-12-31)</li>
          <li>Use dot (.) for decimals, not comma (e.g., 5.50)</li>
          <li>Remove empty rows from your Excel file</li>
          <li>Maximum file size: 5MB (split larger files)</li>
          <li>Upload 100-500 items at a time for best performance</li>
        </ul>
      </div>
    </div>

    <!-- Recent Imports -->
    <div v-if="recentImports.length > 0" class="card">
      <h2>📋 Recent Imports</h2>
      <div class="recent-imports">
        <div v-for="(imp, idx) in recentImports" :key="idx" class="import-history-item">
          <div class="import-icon">{{ getEntityIcon(imp.type) }}</div>
          <div class="import-details">
            <div class="import-type">{{ imp.type }}</div>
            <div class="import-stats">
              <span class="success">✅ {{ imp.successCount }}</span>
              <span v-if="imp.errorCount > 0" class="error">❌ {{ imp.errorCount }}</span>
            </div>
          </div>
          <div class="import-time">{{ formatTime(imp.timestamp) }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import BulkImport from '../components/BulkImport.vue'

export default {
  name: 'BulkImportCenter',
  components: {
    BulkImport
  },
  data() {
    return {
      recentImports: []
    }
  },
  mounted() {
    this.loadRecentImports()
  },
  methods: {
    handleImportComplete(result) {
      // Add to recent imports
      this.recentImports.unshift({
        type: result.entityType || 'Unknown',
        successCount: result.successCount,
        errorCount: result.errorCount,
        timestamp: new Date()
      })

      // Keep only last 10 imports
      if (this.recentImports.length > 10) {
        this.recentImports = this.recentImports.slice(0, 10)
      }

      // Save to localStorage
      localStorage.setItem('recentImports', JSON.stringify(this.recentImports))

      // Show success message
      if (result.errorCount === 0) {
        alert(`✅ Successfully imported ${result.successCount} items!`)
      }
    },

    loadRecentImports() {
      const saved = localStorage.getItem('recentImports')
      if (saved) {
        this.recentImports = JSON.parse(saved).map(imp => ({
          ...imp,
          timestamp: new Date(imp.timestamp)
        }))
      }
    },

    getEntityIcon(type) {
      const icons = {
        medicines: '💊',
        stock: '📦',
        customers: '👥',
        suppliers: '🏢',
        cosmetics: '💄'
      }
      return icons[type] || '📄'
    },

    formatTime(date) {
      const now = new Date()
      const diff = now - date
      const minutes = Math.floor(diff / 60000)
      const hours = Math.floor(minutes / 60)
      const days = Math.floor(hours / 24)

      if (minutes < 1) return 'Just now'
      if (minutes < 60) return `${minutes}m ago`
      if (hours < 24) return `${hours}h ago`
      if (days < 7) return `${days}d ago`
      return date.toLocaleDateString()
    }
  }
}
</script>

<style scoped>
.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 20px;
}

h1 {
  color: #2c3e50;
  margin-bottom: 10px;
}

.subtitle {
  color: #7f8c8d;
  font-size: 16px;
  margin-bottom: 30px;
}

.import-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.import-card {
  background: white;
  border-radius: 12px;
  padding: 25px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.import-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
}

.card-icon {
  font-size: 48px;
  margin-bottom: 15px;
}

.import-card h3 {
  color: #2c3e50;
  margin: 10px 0;
}

.import-card p {
  color: #7f8c8d;
  font-size: 14px;
  margin-bottom: 20px;
  min-height: 40px;
}

.card-info {
  margin-top: 15px;
  padding-top: 15px;
  border-top: 1px solid #ecf0f1;
}

.card-info small {
  color: #95a5a6;
  font-size: 12px;
}

.card {
  background: white;
  border-radius: 12px;
  padding: 25px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  margin-bottom: 20px;
}

.guide-section h2 {
  color: #2c3e50;
  margin-bottom: 25px;
}

.guide-steps {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.step {
  display: flex;
  gap: 15px;
  align-items: flex-start;
}

.step-number {
  width: 40px;
  height: 40px;
  background: #3498db;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 18px;
  flex-shrink: 0;
}

.step-content h4 {
  color: #2c3e50;
  margin: 0 0 8px 0;
}

.step-content p {
  color: #7f8c8d;
  font-size: 14px;
  margin: 0;
}

.tips {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid #3498db;
}

.tips h4 {
  color: #2c3e50;
  margin-top: 0;
}

.tips ul {
  margin: 10px 0 0 0;
  padding-left: 20px;
}

.tips li {
  color: #495057;
  margin-bottom: 8px;
  font-size: 14px;
}

.recent-imports {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.import-history-item {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 15px;
  background: #f8f9fa;
  border-radius: 8px;
  transition: background 0.3s;
}

.import-history-item:hover {
  background: #e9ecef;
}

.import-icon {
  font-size: 32px;
}

.import-details {
  flex: 1;
}

.import-type {
  font-weight: bold;
  color: #2c3e50;
  text-transform: capitalize;
}

.import-stats {
  display: flex;
  gap: 15px;
  margin-top: 5px;
  font-size: 14px;
}

.import-stats .success {
  color: #28a745;
}

.import-stats .error {
  color: #dc3545;
}

.import-time {
  color: #6c757d;
  font-size: 13px;
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.3s;
}

.btn-primary {
  background: #3498db;
  color: white;
}

.btn-primary:hover {
  background: #2980b9;
}
</style>
