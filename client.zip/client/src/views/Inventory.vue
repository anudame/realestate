<template>
  <div class="container">
    <h1>Inventory Management</h1>
    
    <v-card elevation="3" class="mb-4">
      <v-card-text>
        <v-row align="center">
          <v-col cols="12" md="5">
            <v-text-field
              v-model="searchQuery"
              @input="filterInventory"
              prepend-inner-icon="mdi-magnify"
              label="Search medicine or batch"
              variant="outlined"
              density="compact"
              hide-details
              clearable
            ></v-text-field>
          </v-col>
          <v-col cols="12" md="4">
            <v-select
              v-model="filterType"
              @update:model-value="filterInventory"
              :items="filterOptions"
              item-title="text"
              item-value="value"
              prepend-inner-icon="mdi-filter"
              label="Filter by status"
              variant="outlined"
              density="compact"
              hide-details
            ></v-select>
          </v-col>
          <v-col cols="12" md="3" class="d-flex gap-2">
            <v-btn
              @click="loadInventory"
              color="primary"
              prepend-icon="mdi-refresh"
              variant="elevated"
              block
            >
              Refresh
            </v-btn>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>

    <div class="card">

      <div style="overflow-x: auto;">
        <table class="table">
          <thead>
            <tr>
              <th>Medicine</th>
              <th>Category</th>
              <th>Form</th>
              <th>Batch Number</th>
              <th>Expiry Date</th>
              <th>Quantity</th>
              <th>Purchase Price</th>
              <th>Selling Price</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="item in filteredInventory" :key="item.batch_id" 
                :style="{ backgroundColor: getRowColor(item) }">
              <td>
                <strong>{{ item.generic_name }}</strong><br>
                <small>{{ item.brand_name }} ({{ item.strength }})</small>
              </td>
              <td>{{ item.category_name }}</td>
              <td>{{ item.form_name }}</td>
              <td>{{ item.batch_number }}</td>
              <td>{{ formatDate(item.expiry_date) }}</td>
              <td>
                <strong :style="{ color: item.quantity_in_stock <= item.reorder_level ? 'red' : 'green' }">
                  {{ item.quantity_in_stock }}
                </strong>
              </td>
              <td>ETB {{ item.purchase_price }}</td>
              <td>ETB {{ item.selling_price }}</td>
              <td>
                <span :style="{ 
                  padding: '4px 8px', 
                  borderRadius: '4px', 
                  fontSize: '12px',
                  backgroundColor: getStatusColor(item),
                  color: 'white'
                }">
                  {{ getStatus(item) }}
                </span>
              </td>
              <td>
                <div class="d-flex gap-1">
                  <v-btn
                    @click="editBatch(item)"
                    color="primary"
                    size="small"
                    icon="mdi-pencil"
                    variant="tonal"
                    density="comfortable"
                  ></v-btn>
                  <v-btn
                    @click="adjustStock(item)"
                    color="orange"
                    size="small"
                    icon="mdi-package-variant"
                    variant="tonal"
                    density="comfortable"
                  ></v-btn>
                  <v-btn
                    @click="deleteBatch(item.batch_id)"
                    color="error"
                    size="small"
                    icon="mdi-delete"
                    variant="tonal"
                    density="comfortable"
                  ></v-btn>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 4px;">
        <h4>Summary</h4>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
          <div>
            <strong>Total Items:</strong> {{ filteredInventory.length }}
          </div>
          <div>
            <strong>Total Stock Value:</strong> ETB {{ totalValue.toFixed(2) }}
          </div>
          <div>
            <strong style="color: #e74c3c;">Low Stock Items:</strong> {{ lowStockCount }}
          </div>
          <div>
            <strong style="color: #f39c12;">Near Expiry:</strong> {{ nearExpiryCount }}
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Batch Modal -->
    <div v-if="showEditModal" class="modal" @click.self="closeEditModal">
      <div class="modal-content">
        <h2>Edit Batch Stock</h2>
        <form @submit.prevent="saveBatch">
          <div class="form-group">
            <label>Medicine</label>
            <input :value="editForm.medicine_name" disabled>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label>Batch Number *</label>
              <input v-model="editForm.batch_number" required>
            </div>
            <div class="form-group">
              <label>Expiry Date *</label>
              <input v-model="editForm.expiry_date" type="date" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Quantity *</label>
              <input v-model.number="editForm.quantity" type="number" min="0" required>
            </div>
            <div class="form-group">
              <label>Purchase Price *</label>
              <input v-model.number="editForm.purchase_price" type="number" step="0.01" required>
            </div>
          </div>

          <div class="form-group">
            <label>Selling Price *</label>
            <input v-model.number="editForm.selling_price" type="number" step="0.01" required>
          </div>

          <div class="modal-actions">
            <button type="button" @click="closeEditModal" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn btn-primary">Update Batch</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Stock Adjustment Modal -->
    <div v-if="showAdjustModal" class="modal" @click.self="closeAdjustModal">
      <div class="modal-content">
        <h2>Adjust Stock</h2>
        <p><strong>{{ adjustForm.medicine_name }}</strong> - Batch: {{ adjustForm.batch_number }}</p>
        <p>Current Stock: <strong>{{ adjustForm.current_quantity }}</strong></p>
        
        <form @submit.prevent="saveAdjustment">
          <div class="form-group">
            <label>Adjustment Type *</label>
            <select v-model="adjustForm.type" required>
              <option value="add">Add Stock</option>
              <option value="remove">Remove Stock</option>
              <option value="set">Set Exact Quantity</option>
            </select>
          </div>

          <div class="form-group">
            <label>{{ adjustForm.type === 'set' ? 'New Quantity' : 'Quantity to ' + (adjustForm.type === 'add' ? 'Add' : 'Remove') }} *</label>
            <input v-model.number="adjustForm.quantity" type="number" min="0" required>
          </div>

          <div class="form-group">
            <label>Reason *</label>
            <select v-model="adjustForm.reason" required>
              <option value="damage">Damaged</option>
              <option value="expiry">Expired</option>
              <option value="return">Return to Supplier</option>
              <option value="correction">Stock Correction</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div class="form-group">
            <label>Notes</label>
            <textarea v-model="adjustForm.notes" rows="3"></textarea>
          </div>

          <div class="modal-actions">
            <button type="button" @click="closeAdjustModal" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn btn-primary">Apply Adjustment</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../api'

export default {
  data() {
    return {
      inventory: [],
      filteredInventory: [],
      searchQuery: '',
      filterType: 'all',
      filterOptions: [
        { text: 'All Stock', value: 'all' },
        { text: 'In Stock', value: 'in-stock' },
        { text: 'Low Stock', value: 'low-stock' },
        { text: 'Out of Stock', value: 'out-of-stock' },
        { text: 'Near Expiry', value: 'near-expiry' },
        { text: 'Expired', value: 'expired' }
      ],
      showEditModal: false,
      showAdjustModal: false,
      editForm: {
        batch_id: null,
        medicine_name: '',
        batch_number: '',
        expiry_date: '',
        quantity: 0,
        purchase_price: 0,
        selling_price: 0
      },
      adjustForm: {
        batch_id: null,
        medicine_name: '',
        batch_number: '',
        current_quantity: 0,
        type: 'add',
        quantity: 0,
        reason: 'correction',
        notes: ''
      }
    }
  },
  computed: {
    totalValue() {
      return this.filteredInventory.reduce((sum, item) => 
        sum + (item.quantity_in_stock * item.purchase_price), 0
      )
    },
    lowStockCount() {
      return this.inventory.filter(item => 
        item.quantity_in_stock <= item.reorder_level && item.quantity_in_stock > 0
      ).length
    },
    nearExpiryCount() {
      const sixMonthsFromNow = new Date()
      sixMonthsFromNow.setMonth(sixMonthsFromNow.getMonth() + 6)
      return this.inventory.filter(item => {
        const expiryDate = new Date(item.expiry_date)
        return expiryDate <= sixMonthsFromNow && expiryDate > new Date()
      }).length
    }
  },
  async mounted() {
    await this.loadInventory()
  },
  methods: {
    async loadInventory() {
      try {
        const { data } = await api.get('/stock/inventory')
        this.inventory = data
        this.filteredInventory = data
      } catch (err) {
        console.error(err)
        alert('Failed to load inventory')
      }
    },
    filterInventory() {
      let filtered = this.inventory

      // Apply search filter
      if (this.searchQuery) {
        const query = this.searchQuery.toLowerCase()
        filtered = filtered.filter(item =>
          item.generic_name.toLowerCase().includes(query) ||
          item.brand_name.toLowerCase().includes(query) ||
          item.batch_number.toLowerCase().includes(query)
        )
      }

      // Apply type filter
      const now = new Date()
      const sixMonthsFromNow = new Date()
      sixMonthsFromNow.setMonth(sixMonthsFromNow.getMonth() + 6)

      switch (this.filterType) {
        case 'in-stock':
          filtered = filtered.filter(item => item.quantity_in_stock > item.reorder_level)
          break
        case 'low-stock':
          filtered = filtered.filter(item => 
            item.quantity_in_stock <= item.reorder_level && item.quantity_in_stock > 0
          )
          break
        case 'out-of-stock':
          filtered = filtered.filter(item => item.quantity_in_stock === 0)
          break
        case 'near-expiry':
          filtered = filtered.filter(item => {
            const expiryDate = new Date(item.expiry_date)
            return expiryDate <= sixMonthsFromNow && expiryDate > now
          })
          break
        case 'expired':
          filtered = filtered.filter(item => new Date(item.expiry_date) <= now)
          break
      }

      this.filteredInventory = filtered
    },
    formatDate(dateString) {
      const date = new Date(dateString)
      return date.toLocaleDateString()
    },
    getStatus(item) {
      const now = new Date()
      const expiryDate = new Date(item.expiry_date)
      const sixMonthsFromNow = new Date()
      sixMonthsFromNow.setMonth(sixMonthsFromNow.getMonth() + 6)

      if (expiryDate <= now) return 'Expired'
      if (item.quantity_in_stock === 0) return 'Out of Stock'
      if (item.quantity_in_stock <= item.reorder_level) return 'Low Stock'
      if (expiryDate <= sixMonthsFromNow) return 'Near Expiry'
      return 'In Stock'
    },
    getStatusColor(item) {
      const status = this.getStatus(item)
      switch (status) {
        case 'Expired': return '#c0392b'
        case 'Out of Stock': return '#7f8c8d'
        case 'Low Stock': return '#e74c3c'
        case 'Near Expiry': return '#f39c12'
        case 'In Stock': return '#27ae60'
        default: return '#3498db'
      }
    },
    getRowColor(item) {
      const now = new Date()
      const expiryDate = new Date(item.expiry_date)
      
      if (expiryDate <= now) return '#ffebee'
      if (item.quantity_in_stock === 0) return '#f5f5f5'
      if (item.quantity_in_stock <= item.reorder_level) return '#fff3e0'
      return 'white'
    },
    editBatch(item) {
      this.editForm = {
        batch_id: item.batch_id,
        medicine_name: `${item.generic_name} ${item.brand_name}`,
        batch_number: item.batch_number,
        expiry_date: item.expiry_date.split('T')[0],
        quantity: item.quantity_in_stock,
        purchase_price: item.purchase_price,
        selling_price: item.selling_price
      }
      this.showEditModal = true
    },
    async saveBatch() {
      try {
        await api.put(`/stock/batch/${this.editForm.batch_id}`, {
          batchNumber: this.editForm.batch_number,
          expiryDate: this.editForm.expiry_date,
          quantity: this.editForm.quantity,
          purchasePrice: this.editForm.purchase_price,
          sellingPrice: this.editForm.selling_price
        })
        alert('Batch updated successfully!')
        this.closeEditModal()
        await this.loadInventory()
      } catch (error) {
        alert('Error updating batch: ' + error.message)
      }
    },
    closeEditModal() {
      this.showEditModal = false
      this.editForm = {
        batch_id: null,
        medicine_name: '',
        batch_number: '',
        expiry_date: '',
        quantity: 0,
        purchase_price: 0,
        selling_price: 0
      }
    },
    adjustStock(item) {
      this.adjustForm = {
        batch_id: item.batch_id,
        medicine_name: `${item.generic_name} ${item.brand_name}`,
        batch_number: item.batch_number,
        current_quantity: item.quantity_in_stock,
        type: 'add',
        quantity: 0,
        reason: 'correction',
        notes: ''
      }
      this.showAdjustModal = true
    },
    async saveAdjustment() {
      try {
        let newQuantity = this.adjustForm.current_quantity
        
        if (this.adjustForm.type === 'add') {
          newQuantity += this.adjustForm.quantity
        } else if (this.adjustForm.type === 'remove') {
          newQuantity -= this.adjustForm.quantity
        } else {
          newQuantity = this.adjustForm.quantity
        }

        if (newQuantity < 0) {
          alert('Quantity cannot be negative!')
          return
        }

        await api.post('/stock/adjust', {
          batchId: this.adjustForm.batch_id,
          newQuantity: newQuantity,
          reason: this.adjustForm.reason,
          notes: this.adjustForm.notes
        })
        
        alert('Stock adjusted successfully!')
        this.closeAdjustModal()
        await this.loadInventory()
      } catch (error) {
        alert('Error adjusting stock: ' + error.message)
      }
    },
    closeAdjustModal() {
      this.showAdjustModal = false
      this.adjustForm = {
        batch_id: null,
        medicine_name: '',
        batch_number: '',
        current_quantity: 0,
        type: 'add',
        quantity: 0,
        reason: 'correction',
        notes: ''
      }
    },
    async deleteBatch(batchId) {
      if (!confirm('Are you sure you want to delete this batch? This action cannot be undone.')) {
        return
      }

      try {
        await api.delete(`/stock/batch/${batchId}`)
        alert('Batch deleted successfully!')
        await this.loadInventory()
      } catch (error) {
        alert('Error deleting batch: ' + error.message)
      }
    }
  }
}
</script>

<style scoped>
.d-flex {
  display: flex;
}

.gap-1 {
  gap: 4px;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 30px;
  border-radius: 8px;
  max-width: 600px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 15px;
  margin-bottom: 15px;
}

.form-group {
  display: flex;
  flex-direction: column;
  margin-bottom: 15px;
}

.form-group label {
  margin-bottom: 5px;
  font-weight: bold;
}

.form-group input,
.form-group select,
.form-group textarea {
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}
</style>
