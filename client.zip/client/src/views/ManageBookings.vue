<template>
  <div class="container" style="padding: 3rem 0;">
    <h1 style="margin-bottom: 2rem;">📅 Booking Management</h1>

    <!-- Filters -->
    <div class="info-section" style="margin-bottom: 2rem;">
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
        <div class="form-group">
          <label>Status</label>
          <select v-model="filters.status" @change="loadBookings">
            <option value="">All Status</option>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>

        <div class="form-group">
          <label>Date From</label>
          <input v-model="filters.date_from" type="date" @change="loadBookings">
        </div>

        <div class="form-group">
          <label>Date To</label>
          <input v-model="filters.date_to" type="date" @change="loadBookings">
        </div>

        <div class="form-group">
          <label>Search</label>
          <input v-model="filters.search" type="text" placeholder="Name, email, phone..." @input="debounceSearch">
        </div>
      </div>
    </div>

    <!-- Stats Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
      <div class="stat-card" style="background: #fff3cd; border-left: 4px solid #ffc107;">
        <div class="stat-value">{{ stats.pending }}</div>
        <div class="stat-label">Pending</div>
      </div>
      <div class="stat-card" style="background: #d1ecf1; border-left: 4px solid #17a2b8;">
        <div class="stat-value">{{ stats.confirmed }}</div>
        <div class="stat-label">Confirmed</div>
      </div>
      <div class="stat-card" style="background: #d4edda; border-left: 4px solid #28a745;">
        <div class="stat-value">{{ stats.completed }}</div>
        <div class="stat-label">Completed</div>
      </div>
      <div class="stat-card" style="background: #f8d7da; border-left: 4px solid #dc3545;">
        <div class="stat-value">{{ stats.cancelled }}</div>
        <div class="stat-label">Cancelled</div>
      </div>
    </div>

    <!-- Loading -->
    <div v-if="loading" class="loading">
      <div class="spinner"></div>
      <p>Loading bookings...</p>
    </div>

    <!-- Error -->
    <div v-else-if="error" class="alert alert-error">
      {{ error }}
    </div>

    <!-- Bookings Table -->
    <div v-else class="info-section">
      <div v-if="bookings.length === 0" style="text-align: center; padding: 2rem;">
        <i class="fas fa-calendar-times" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
        <p>No bookings found</p>
      </div>

      <div v-else class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Property</th>
              <th>Customer</th>
              <th>Contact</th>
              <th>Booking Date</th>
              <th>Time</th>
              <th>Status</th>
              <th>Created</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="booking in bookings" :key="booking.booking_id">
              <td>#{{ booking.booking_id }}</td>
              <td>
                <div style="font-weight: 500;">{{ booking.property_title }}</div>
                <small style="color: #666;">{{ booking.property_type }}</small>
              </td>
              <td>{{ booking.name }}</td>
              <td>
                <div>📧 {{ booking.email }}</div>
                <div>📱 {{ booking.phone }}</div>
              </td>
              <td>{{ formatDate(booking.booking_date) }}</td>
              <td>{{ booking.booking_time }}</td>
              <td>
                <span :class="['badge', `badge-${booking.status}`]">
                  {{ booking.status }}
                </span>
              </td>
              <td>{{ formatDateTime(booking.created_at) }}</td>
              <td>
                <div class="action-buttons">
                  <button 
                    class="btn-icon" 
                    title="View Details"
                    @click="viewBooking(booking)"
                  >
                    <i class="fas fa-eye"></i>
                  </button>
                  <button 
                    v-if="booking.status === 'pending'"
                    class="btn-icon btn-success" 
                    title="Confirm"
                    @click="updateStatus(booking.booking_id, 'confirmed')"
                  >
                    <i class="fas fa-check"></i>
                  </button>
                  <button 
                    v-if="booking.status === 'confirmed'"
                    class="btn-icon btn-primary" 
                    title="Complete"
                    @click="updateStatus(booking.booking_id, 'completed')"
                  >
                    <i class="fas fa-check-double"></i>
                  </button>
                  <button 
                    v-if="['pending', 'confirmed'].includes(booking.status)"
                    class="btn-icon btn-danger" 
                    title="Cancel"
                    @click="updateStatus(booking.booking_id, 'cancelled')"
                  >
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div v-if="pagination.pages > 1" class="pagination">
        <button 
          @click="changePage(pagination.page - 1)" 
          :disabled="pagination.page === 1"
          class="btn btn-outline"
        >
          Previous
        </button>
        <span>Page {{ pagination.page }} of {{ pagination.pages }}</span>
        <button 
          @click="changePage(pagination.page + 1)" 
          :disabled="pagination.page === pagination.pages"
          class="btn btn-outline"
        >
          Next
        </button>
      </div>
    </div>

    <!-- Booking Details Modal -->
    <div v-if="selectedBooking" class="modal" @click.self="selectedBooking = null">
      <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
          <h2>Booking Details #{{ selectedBooking.booking_id }}</h2>
          <button class="btn-close" @click="selectedBooking = null">×</button>
        </div>
        <div class="modal-body">
          <div class="detail-section">
            <h3>Customer Information</h3>
            <div class="detail-row">
              <span class="detail-label">Name:</span>
              <span>{{ selectedBooking.name }}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Email:</span>
              <span>{{ selectedBooking.email }}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Phone:</span>
              <span>{{ selectedBooking.phone }}</span>
            </div>
          </div>

          <div class="detail-section">
            <h3>Property Information</h3>
            <div class="detail-row">
              <span class="detail-label">Property:</span>
              <span>{{ selectedBooking.property_title }}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Type:</span>
              <span>{{ selectedBooking.property_type }}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Location:</span>
              <span>{{ selectedBooking.city_name }}</span>
            </div>
          </div>

          <div class="detail-section">
            <h3>Booking Details</h3>
            <div class="detail-row">
              <span class="detail-label">Date:</span>
              <span>{{ formatDate(selectedBooking.booking_date) }}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Time:</span>
              <span>{{ selectedBooking.booking_time }}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Status:</span>
              <span :class="['badge', `badge-${selectedBooking.status}`]">
                {{ selectedBooking.status }}
              </span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Created:</span>
              <span>{{ formatDateTime(selectedBooking.created_at) }}</span>
            </div>
          </div>

          <div v-if="selectedBooking.notes" class="detail-section">
            <h3>Notes</h3>
            <p>{{ selectedBooking.notes }}</p>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline" @click="selectedBooking = null">Close</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
import { useDialog } from '../composables/useDialog'

const { confirm, success, error: showError } = useDialog()

const loading = ref(true)
const error = ref('')
const bookings = ref([])
const selectedBooking = ref(null)
const stats = ref({
  pending: 0,
  confirmed: 0,
  completed: 0,
  cancelled: 0
})

const filters = ref({
  status: '',
  date_from: '',
  date_to: '',
  search: ''
})

const pagination = ref({
  page: 1,
  limit: 20,
  total: 0,
  pages: 1
})

let searchTimeout = null

onMounted(() => {
  loadBookings()
})

const loadBookings = async () => {
  try {
    loading.value = true
    error.value = ''
    
    const params = {
      page: pagination.value.page,
      limit: pagination.value.limit,
      ...filters.value
    }

    const response = await api.getBookings(params)
    bookings.value = response.data.bookings
    pagination.value = response.data.pagination
    stats.value = response.data.stats || stats.value
  } catch (err) {
    console.error('Error loading bookings:', err)
    error.value = 'Failed to load bookings'
  } finally {
    loading.value = false
  }
}

const debounceSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    loadBookings()
  }, 500)
}

const changePage = (page) => {
  pagination.value.page = page
  loadBookings()
}

const updateStatus = async (bookingId, status) => {
  const confirmed = await confirm(
    `Are you sure you want to ${status} this booking?`,
    'Confirm Action'
  )
  
  if (!confirmed) return

  try {
    await api.updateBooking(bookingId, { status })
    await success(`Booking ${status} successfully!`)
    await loadBookings()
  } catch (err) {
    console.error('Error updating booking:', err)
    await showError('Failed to update booking status. Please try again.')
  }
}

const viewBooking = (booking) => {
  selectedBooking.value = booking
}

const formatDate = (date) => {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })
}

const formatDateTime = (date) => {
  return new Date(date).toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}
</script>

<style scoped>
.stat-card {
  padding: 1.5rem;
  border-radius: 8px;
  text-align: center;
}

.stat-value {
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
}

.stat-label {
  color: #666;
  font-size: 0.9rem;
}

.table-responsive {
  overflow-x: auto;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
}

.data-table th,
.data-table td {
  padding: 1rem;
  text-align: left;
  border-bottom: 1px solid #eee;
}

.data-table th {
  background: #f8f9fa;
  font-weight: 600;
  color: #333;
}

.data-table tbody tr:hover {
  background: #f8f9fa;
}

.badge {
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.85rem;
  font-weight: 500;
  text-transform: capitalize;
}

.badge-pending {
  background: #fff3cd;
  color: #856404;
}

.badge-confirmed {
  background: #d1ecf1;
  color: #0c5460;
}

.badge-completed {
  background: #d4edda;
  color: #155724;
}

.badge-cancelled {
  background: #f8d7da;
  color: #721c24;
}

.action-buttons {
  display: flex;
  gap: 0.5rem;
}

.btn-icon {
  padding: 0.5rem;
  border: none;
  background: #007bff;
  color: white;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-icon:hover {
  opacity: 0.8;
}

.btn-icon.btn-success {
  background: #28a745;
}

.btn-icon.btn-danger {
  background: #dc3545;
}

.btn-icon.btn-primary {
  background: #007bff;
}

.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1rem;
  margin-top: 2rem;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 8px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  border-bottom: 1px solid #eee;
}

.modal-header h2 {
  margin: 0;
}

.btn-close {
  background: none;
  border: none;
  font-size: 2rem;
  cursor: pointer;
  color: #999;
}

.btn-close:hover {
  color: #333;
}

.modal-body {
  padding: 1.5rem;
}

.modal-footer {
  padding: 1.5rem;
  border-top: 1px solid #eee;
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
}

.detail-section {
  margin-bottom: 2rem;
}

.detail-section h3 {
  margin-bottom: 1rem;
  color: #333;
  font-size: 1.1rem;
}

.detail-row {
  display: flex;
  padding: 0.75rem 0;
  border-bottom: 1px solid #f0f0f0;
}

.detail-label {
  font-weight: 600;
  width: 150px;
  color: #666;
}
</style>
