<template>
  <v-container fluid>
    <!-- Super Admin Banner -->
    <v-alert
      v-if="user?.isSuperAdmin"
      type="info"
      variant="tonal"
      prominent
      class="mb-4"
      border="start"
    >
      <v-row align="center">
        <v-col>
          <div class="text-h6">
            <v-icon size="large" class="mr-2">mdi-shield-crown</v-icon>
            Super Admin Control Center
          </div>
          <div class="text-body-2 mt-1">
            You have Super Admin privileges. Manage all branches, users, and view consolidated reports.
          </div>
        </v-col>
        <v-col cols="auto">
          <v-btn
            color="primary"
            size="large"
            prepend-icon="mdi-shield-crown"
            to="/super-admin"
          >
            Open Super Admin Dashboard
          </v-btn>
        </v-col>
      </v-row>
    </v-alert>

    <!-- Page Header -->
    <v-row class="mb-4">
      <v-col cols="12">
        <h1 class="text-h4 font-weight-bold">Dashboard</h1>
      </v-col>
    </v-row>

    <!-- Date Range Filter -->
    <v-card class="mb-6" elevation="2">
      <v-card-title class="d-flex justify-space-between align-center">
        <span>Sales Report</span>
        <div class="d-flex align-center" style="gap: 12px;">
          <v-text-field
            v-model="startDate"
            type="date"
            label="Start Date"
            density="compact"
            variant="outlined"
            hide-details
            @change="loadSalesReport"
            style="max-width: 180px;"
          ></v-text-field>
          <v-text-field
            v-model="endDate"
            type="date"
            label="End Date"
            density="compact"
            variant="outlined"
            hide-details
            @change="loadSalesReport"
            style="max-width: 180px;"
          ></v-text-field>
          <v-btn
            color="primary"
            prepend-icon="mdi-refresh"
            @click="refreshAll"
          >
            Refresh
          </v-btn>
          <v-btn
            color="success"
            prepend-icon="mdi-download"
            @click="downloadReport"
          >
            Download Report
          </v-btn>
        </div>
      </v-card-title>

      <!-- Stats Cards -->
      <v-card-text>
        <v-row>
          <v-col cols="12" sm="6" md="3">
            <v-card class="stat-card gradient-success" elevation="8">
              <v-card-text>
                <div class="d-flex align-center justify-space-between">
                  <div>
                    <div class="text-caption text-white text-uppercase mb-2">Total Sales</div>
                    <div class="text-h4 font-weight-bold text-white">{{ formatCurrency(salesReport?.summary?.total_sales) }}</div>
                  </div>
                  <v-avatar size="64" color="rgba(255,255,255,0.2)">
                    <v-icon size="40" color="white">mdi-cash-multiple</v-icon>
                  </v-avatar>
                </div>
                <v-progress-linear
                  color="white"
                  model-value="100"
                  height="4"
                  rounded
                  class="mt-4"
                ></v-progress-linear>
              </v-card-text>
            </v-card>
          </v-col>

          <v-col cols="12" sm="6" md="3">
            <v-card class="stat-card gradient-info" elevation="8">
              <v-card-text>
                <div class="d-flex align-center justify-space-between">
                  <div>
                    <div class="text-caption text-white text-uppercase mb-2">Transactions</div>
                    <div class="text-h4 font-weight-bold text-white">{{ salesReport?.summary?.total_transactions || 0 }}</div>
                  </div>
                  <v-avatar size="64" color="rgba(255,255,255,0.2)">
                    <v-icon size="40" color="white">mdi-chart-line</v-icon>
                  </v-avatar>
                </div>
                <v-progress-linear
                  color="white"
                  model-value="100"
                  height="4"
                  rounded
                  class="mt-4"
                ></v-progress-linear>
              </v-card-text>
            </v-card>
          </v-col>

          <v-col cols="12" sm="6" md="3">
            <v-card class="stat-card gradient-warning" elevation="8">
              <v-card-text>
                <div class="d-flex align-center justify-space-between">
                  <div>
                    <div class="text-caption text-white text-uppercase mb-2">Tax Collected</div>
                    <div class="text-h4 font-weight-bold text-white">{{ formatCurrency(salesReport?.summary?.total_tax) }}</div>
                  </div>
                  <v-avatar size="64" color="rgba(255,255,255,0.2)">
                    <v-icon size="40" color="white">mdi-receipt</v-icon>
                  </v-avatar>
                </div>
                <v-progress-linear
                  color="white"
                  model-value="100"
                  height="4"
                  rounded
                  class="mt-4"
                ></v-progress-linear>
              </v-card-text>
            </v-card>
          </v-col>

          <v-col cols="12" sm="6" md="3">
            <v-card class="stat-card gradient-error" elevation="8">
              <v-card-text>
                <div class="d-flex align-center justify-space-between">
                  <div>
                    <div class="text-caption text-white text-uppercase mb-2">Discounts</div>
                    <div class="text-h4 font-weight-bold text-white">{{ formatCurrency(salesReport?.summary?.total_discount) }}</div>
                  </div>
                  <v-avatar size="64" color="rgba(255,255,255,0.2)">
                    <v-icon size="40" color="white">mdi-gift</v-icon>
                  </v-avatar>
                </div>
                <v-progress-linear
                  color="white"
                  model-value="100"
                  height="4"
                  rounded
                  class="mt-4"
                ></v-progress-linear>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>

    <!-- Charts Row -->
    <v-row v-if="salesReport" class="mb-6">
      <v-col cols="12" md="6">
        <v-card elevation="4" class="chart-card">
          <v-card-title class="d-flex align-center">
            <v-icon class="mr-2" color="success">mdi-chart-line-variant</v-icon>
            Weekly Sales Trend
          </v-card-title>
          <v-divider></v-divider>
          <v-card-text>
            <div v-if="salesReport.dailySales && salesReport.dailySales.length" style="height: 300px;">
              <canvas ref="salesChart"></canvas>
            </div>
            <v-alert v-else type="info" variant="tonal">No sales data available</v-alert>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" md="6">
        <v-card elevation="4" class="chart-card">
          <v-card-title class="d-flex align-center">
            <v-icon class="mr-2" color="primary">mdi-pill</v-icon>
            Top 10 Selling Medicines
          </v-card-title>
          <v-divider></v-divider>
          <v-card-text>
            <div v-if="salesReport.topMedicines && salesReport.topMedicines.length">
              <div v-for="(med, idx) in salesReport.topMedicines.slice(0, 10)" :key="idx" class="mb-3">
                <div class="text-caption mb-1">{{ med.generic_name }}</div>
                <v-progress-linear
                  :model-value="getBarWidth(med.total_quantity, maxMedicineQty)"
                  :color="getProgressColor(idx)"
                  height="25"
                  rounded
                >
                  <template v-slot:default>
                    <strong>{{ med.total_quantity }}</strong>
                  </template>
                </v-progress-linear>
              </div>
            </div>
            <v-alert v-else type="info" variant="tonal">No medicine sales data</v-alert>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <!-- Tables Row -->
    <v-row v-if="salesReport" class="mb-6">
      <v-col cols="12" md="6">
        <v-card elevation="4" class="chart-card">
          <v-card-title class="d-flex align-center">
            <v-icon class="mr-2" color="info">mdi-account-cash</v-icon>
            User Sales Report
          </v-card-title>
          <v-divider></v-divider>
          <v-card-text>
            <v-table density="compact">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Transactions</th>
                  <th>Total Sales</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(cashier, idx) in salesReport.byCashier" :key="idx">
                  <td>{{ cashier.full_name }}</td>
                  <td>{{ cashier.transactions }}</td>
                  <td>{{ formatCurrency(cashier.total_sales) }}</td>
                </tr>
              </tbody>
            </v-table>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" md="6">
        <v-card elevation="4" class="chart-card">
          <v-card-title class="d-flex align-center">
            <v-icon class="mr-2" color="success">mdi-credit-card</v-icon>
            Sales by Payment Mode
          </v-card-title>
          <v-divider></v-divider>
          <v-card-text>
            <v-table density="compact">
              <thead>
                <tr>
                  <th>Payment Mode</th>
                  <th>Transactions</th>
                  <th>Total Amount</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(mode, idx) in salesReport.byPaymentMode" :key="idx">
                  <td class="text-capitalize">{{ mode.payment_mode }}</td>
                  <td>{{ mode.transactions }}</td>
                  <td>{{ formatCurrency(mode.total_amount) }}</td>
                </tr>
              </tbody>
            </v-table>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <!-- Alerts Row -->
    <v-row class="mb-6">
      <v-col cols="12" md="6">
        <v-card class="stat-card gradient-error" elevation="8">
          <v-card-text class="text-center py-8">
            <v-avatar size="80" color="rgba(255,255,255,0.2)" class="mb-4">
              <v-icon size="48" color="white">mdi-alert-circle</v-icon>
            </v-avatar>
            <div class="text-h6 text-white mb-2">Low Stock Items</div>
            <div class="text-h2 font-weight-bold text-white">{{ lowStock.length }}</div>
            <v-btn
              variant="outlined"
              color="white"
              class="mt-4"
              size="small"
              to="/inventory"
            >
              View Details
            </v-btn>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" md="6">
        <v-card class="stat-card gradient-warning" elevation="8">
          <v-card-text class="text-center py-8">
            <v-avatar size="80" color="rgba(255,255,255,0.2)" class="mb-4">
              <v-icon size="48" color="white">mdi-clock-alert</v-icon>
            </v-avatar>
            <div class="text-h6 text-white mb-2">Near Expiry</div>
            <div class="text-h2 font-weight-bold text-white">{{ nearExpiry.length }}</div>
            <v-btn
              variant="outlined"
              color="white"
              class="mt-4"
              size="small"
              to="/inventory"
            >
              View Details
            </v-btn>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <!-- Top Selling Products -->
    <v-row class="mb-6">
      <v-col cols="12" md="6">
        <v-card elevation="4" class="chart-card">
          <v-card-title class="d-flex align-center">
            <v-icon class="mr-2" color="warning">mdi-trophy</v-icon>
            Top Selling Medicines
          </v-card-title>
          <v-divider></v-divider>
          <v-card-text>
            <v-table density="compact">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Medicine</th>
                  <th>Category</th>
                  <th>Quantity</th>
                  <th>Revenue</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(med, idx) in topMedicines" :key="idx">
                  <td>
                    <v-avatar :color="idx < 3 ? 'warning' : 'grey'" size="32">
                      <span class="text-white font-weight-bold">{{ idx + 1 }}</span>
                    </v-avatar>
                  </td>
                  <td>
                    <div class="font-weight-bold">{{ med.generic_name }}</div>
                    <div class="text-caption text-medium-emphasis">{{ med.brand_name }}</div>
                  </td>
                  <td>{{ med.category_name }}</td>
                  <td>
                    <v-chip color="success" size="small">{{ med.total_quantity }} units</v-chip>
                  </td>
                  <td class="font-weight-bold text-primary">{{ formatCurrency(med.total_revenue) }}</td>
                </tr>
              </tbody>
            </v-table>
            <v-alert v-if="topMedicines.length === 0" type="info" variant="tonal" class="mt-4">
              No medicine sales data
            </v-alert>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" md="6">
        <v-card elevation="4" class="chart-card">
          <v-card-title class="d-flex align-center">
            <v-icon class="mr-2" color="pink">mdi-lipstick</v-icon>
            Top Selling Cosmetics
          </v-card-title>
          <v-divider></v-divider>
          <v-card-text>
            <v-table density="compact">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Product</th>
                  <th>Category</th>
                  <th>Quantity</th>
                  <th>Revenue</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(cos, idx) in topCosmetics" :key="idx">
                  <td>
                    <v-avatar :color="idx < 3 ? 'pink' : 'grey'" size="32">
                      <span class="text-white font-weight-bold">{{ idx + 1 }}</span>
                    </v-avatar>
                  </td>
                  <td>
                    <div class="font-weight-bold">{{ cos.product_name }}</div>
                    <div class="text-caption text-medium-emphasis">{{ cos.brand }}</div>
                  </td>
                  <td>{{ cos.category }}</td>
                  <td>
                    <v-chip color="success" size="small">{{ cos.total_quantity }} units</v-chip>
                  </td>
                  <td class="font-weight-bold text-primary">{{ formatCurrency(cos.total_revenue) }}</td>
                </tr>
              </tbody>
            </v-table>
            <v-alert v-if="topCosmetics.length === 0" type="info" variant="tonal" class="mt-4">
              No cosmetic sales data
            </v-alert>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <!-- Low Stock Alert Table -->
    <v-row>
      <v-col cols="12">
        <v-card elevation="4" class="chart-card">
          <v-card-title class="d-flex align-center">
            <v-icon class="mr-2" color="error">mdi-alert</v-icon>
            Low Stock Alert
          </v-card-title>
          <v-divider></v-divider>
          <v-card-text>
            <v-table density="compact">
              <thead>
                <tr>
                  <th>Medicine</th>
                  <th>Current Stock</th>
                  <th>Reorder Level</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="item in lowStock" :key="item.medicine_id">
                  <td>{{ item.generic_name }} ({{ item.brand_name }})</td>
                  <td>
                    <v-chip color="error" size="small">{{ item.total_stock }}</v-chip>
                  </td>
                  <td>{{ item.reorder_level }}</td>
                </tr>
              </tbody>
            </v-table>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import api from '../api'
import { Chart, registerables } from 'chart.js'

Chart.register(...registerables)

export default {
  data() {
    const endDate = new Date()
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - 6)
    
    return {
      lowStock: [],
      nearExpiry: [],
      salesReport: null,
      refreshInterval: null,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0],
      user: null,
      salesChart: null
    }
  },
  mounted() {
    this.user = JSON.parse(localStorage.getItem('user'))
    this.loadData()
    this.loadSalesReport()
    
    this.refreshInterval = setInterval(() => {
      this.loadData()
      this.loadSalesReport()
    }, 30000)
  },
  computed: {
    user() {
      const userStr = localStorage.getItem('user')
      return userStr ? JSON.parse(userStr) : null
    },
    maxDailySales() {
      if (!this.salesReport?.dailySales?.length) return 1
      return Math.max(...this.salesReport.dailySales.map(d => d.total_sales || 0))
    },
    maxMedicineQty() {
      if (!this.salesReport?.topMedicines?.length) return 1
      return Math.max(...this.salesReport.topMedicines.map(m => m.total_quantity || 0))
    },
    topMedicines() {
      return this.salesReport?.topMedicines || []
    },
    topCosmetics() {
      return this.salesReport?.topCosmetics || []
    }
  },

  beforeUnmount() {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval)
    }
    if (this.salesChart) {
      this.salesChart.destroy()
    }
  },
  methods: {
    async refreshAll() {
      this.endDate = new Date().toISOString().split('T')[0]
      await this.loadData()
      await this.loadSalesReport()
    },
    downloadReport() {
      if (!this.salesReport) {
        alert('No report data available')
        return
      }

      // Create CSV content
      let csv = 'Sales Report\n'
      csv += `Period: ${this.startDate} to ${this.endDate}\n\n`
      
      // Summary
      csv += 'SUMMARY\n'
      csv += `Total Transactions,${this.salesReport.summary?.total_transactions || 0}\n`
      csv += `Total Sales,${this.salesReport.summary?.total_sales || 0}\n`
      csv += `Total Tax,${this.salesReport.summary?.total_tax || 0}\n`
      csv += `Total Discount,${this.salesReport.summary?.total_discount || 0}\n\n`
      
      // User Sales Report
      csv += 'USER SALES REPORT\n'
      csv += 'User,Transactions,Total Sales\n'
      if (this.salesReport.byCashier) {
        this.salesReport.byCashier.forEach(cashier => {
          csv += `${cashier.full_name},${cashier.transactions},${cashier.total_sales}\n`
        })
      }
      csv += '\n'
      
      // Payment Mode
      csv += 'SALES BY PAYMENT MODE\n'
      csv += 'Payment Mode,Transactions,Total Amount\n'
      if (this.salesReport.byPaymentMode) {
        this.salesReport.byPaymentMode.forEach(mode => {
          csv += `${mode.payment_mode},${mode.transactions},${mode.total_amount}\n`
        })
      }
      csv += '\n'
      
      // Top Medicines
      csv += 'TOP SELLING MEDICINES\n'
      csv += 'Medicine,Quantity,Revenue\n'
      if (this.salesReport.topMedicines) {
        this.salesReport.topMedicines.forEach(med => {
          csv += `${med.generic_name},${med.total_quantity},${med.total_revenue}\n`
        })
      }
      csv += '\n'
      
      // Top Cosmetics
      csv += 'TOP SELLING COSMETICS\n'
      csv += 'Product,Quantity,Revenue\n'
      if (this.salesReport.topCosmetics) {
        this.salesReport.topCosmetics.forEach(cos => {
          csv += `${cos.product_name},${cos.total_quantity},${cos.total_revenue}\n`
        })
      }
      
      // Create download
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
      const link = document.createElement('a')
      const url = URL.createObjectURL(blob)
      link.setAttribute('href', url)
      link.setAttribute('download', `sales_report_${this.startDate}_to_${this.endDate}.csv`)
      link.style.visibility = 'hidden'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    },
    async loadData() {
      try {
        const user = JSON.parse(localStorage.getItem('user'))
        
        // Check if main branch to get consolidated data
        if (user && user.branchId) {
          const { data: branchData } = await api.get(`/branches/${user.branchId}`)
          
          if (branchData.is_main) {
            // Get data from all sub-branches
            const { data: subBranches } = await api.get(`/branches/${user.branchId}/sub-branches`)
            
            // Aggregate low stock and near expiry from all branches
            const allBranchIds = [user.branchId, ...subBranches.map(b => b.branch_id)]
            
            const [lowStockRes, nearExpiryRes] = await Promise.all([
              api.get('/stock/low-stock'),
              api.get('/stock/near-expiry')
            ])
            
            this.lowStock = lowStockRes.data
            this.nearExpiry = nearExpiryRes.data
            return
          }
        }
        
        // Regular single-branch data
        const [lowStockRes, nearExpiryRes] = await Promise.all([
          api.get('/stock/low-stock'),
          api.get('/stock/near-expiry')
        ])
        this.lowStock = lowStockRes.data
        this.nearExpiry = nearExpiryRes.data
      } catch (err) {
        console.error(err)
      }
    },
    async loadSalesReport() {
      try {
        const user = JSON.parse(localStorage.getItem('user'))
        const viewBranchId = localStorage.getItem('viewBranchId')
        
        // If viewing a specific branch, get that branch's report
        if (viewBranchId && viewBranchId !== user.branchId.toString()) {
          const { data } = await api.get(`/sales/report?startDate=${this.startDate}&endDate=${this.endDate}&branchId=${viewBranchId}`)
          this.salesReport = data
          this.renderSalesChart()
          return
        }
        
        // Regular single-branch report
        const { data } = await api.get(`/sales/report?startDate=${this.startDate}&endDate=${this.endDate}`)
        this.salesReport = data
        this.renderSalesChart()
      } catch (err) {
        console.error('Error loading sales report:', err)
      }
    },
    getBarWidth(value, max) {
      if (!max || max === 0) return 0
      return Math.min((value / max) * 100, 100)
    },
    getProgressColor(index) {
      const colors = ['primary', 'error', 'warning', 'success', 'purple', 'teal', 'orange', 'grey', 'cyan', 'red']
      return colors[index % colors.length]
    },
    formatDate(dateString) {
      const date = new Date(dateString)
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    },
    formatCurrency(value) {
      const num = parseFloat(value)
      return isNaN(num) ? 'ETB 0.00' : `ETB ${num.toFixed(2)}`
    },
    renderSalesChart() {
      if (!this.salesReport?.dailySales?.length) return
      
      // Wait for next tick to ensure canvas is rendered
      this.$nextTick(() => {
        // Destroy existing chart
        if (this.salesChart) {
          this.salesChart.destroy()
        }
        
        const canvas = this.$refs.salesChart
        if (!canvas) return
        
        const ctx = canvas.getContext('2d')
        
        // Prepare data - show last 7 days
        const last7Days = this.salesReport.dailySales.slice(-7)
        const labels = last7Days.map(day => this.formatDate(day.sale_date))
        const data = last7Days.map(day => parseFloat(day.total_sales) || 0)
        
        this.salesChart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: labels,
            datasets: [{
              label: 'Sales (ETB)',
              data: data,
              borderColor: '#27ae60',
              backgroundColor: 'rgba(39, 174, 96, 0.1)',
              borderWidth: 3,
              fill: true,
              tension: 0.4,
              pointRadius: 5,
              pointHoverRadius: 7,
              pointBackgroundColor: '#27ae60',
              pointBorderColor: '#fff',
              pointBorderWidth: 2
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: true,
                position: 'top'
              },
              tooltip: {
                callbacks: {
                  label: function(context) {
                    return `Sales: ETB ${context.parsed.y.toFixed(2)}`
                  }
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                  callback: function(value) {
                    return 'ETB ' + value.toFixed(0)
                  }
                }
              }
            }
          }
        })
      })
    }
  }
}
</script>

<style scoped>
.stat-card {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  position: relative;
}

.stat-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
  transition: left 0.5s;
}

.stat-card:hover::before {
  left: 100%;
}

.stat-card:hover {
  transform: translateY(-8px) scale(1.02);
  box-shadow: 0 12px 24px rgba(0,0,0,0.15) !important;
}

.gradient-success {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
}

.gradient-info {
  background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
}

.gradient-warning {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
}

.gradient-error {
  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
}

.gradient-purple {
  background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
}

.gradient-teal {
  background: linear-gradient(135deg, #14b8a6 0%, #0d9488 100%);
}

/* Card animations */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.v-card {
  animation: fadeInUp 0.5s ease-out;
}

.v-col:nth-child(1) .stat-card {
  animation-delay: 0s;
}

.v-col:nth-child(2) .stat-card {
  animation-delay: 0.1s;
}

.v-col:nth-child(3) .stat-card {
  animation-delay: 0.2s;
}

.v-col:nth-child(4) .stat-card {
  animation-delay: 0.3s;
}

/* Progress bar animation */
.v-progress-linear {
  animation: slideIn 1s ease-out;
}

@keyframes slideIn {
  from {
    transform: translateX(-100%);
  }
  to {
    transform: translateX(0);
  }
}

/* Table hover effect */
.v-table tbody tr {
  transition: all 0.2s;
}

.v-table tbody tr:hover {
  background: rgba(99, 102, 241, 0.05);
  transform: scale(1.01);
}

/* Chip animation */
.v-chip {
  transition: all 0.2s;
}

.v-chip:hover {
  transform: scale(1.1);
}

/* Chart card styling */
.chart-card {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  border-top: 3px solid transparent;
}

.chart-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.12) !important;
  border-top-color: rgb(var(--v-theme-primary));
}

/* Avatar pulse animation */
@keyframes pulse {
  0%, 100% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.05);
    opacity: 0.9;
  }
}

.v-avatar {
  animation: pulse 2s ease-in-out infinite;
}

/* Button hover effect */
.v-btn {
  transition: all 0.3s;
}

.v-btn:hover {
  transform: translateY(-2px);
}
</style>
