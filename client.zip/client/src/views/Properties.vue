<template>
  <div class="properties-page">
    <div class="container" style="padding: 2rem 0;">
      <h1>Browse Properties</h1>
      
      <!-- Filters -->
      <div class="filters-section" style="margin: 2rem 0;">
        <div class="search-bar">
          <input v-model="filters.search" type="text" placeholder="Search..." @input="debounceSearch">
          <select v-model="filters.city_id" @change="loadProperties">
            <option value="">All Cities</option>
            <option v-for="city in cities" :key="city.city_id" :value="city.city_id">
              {{ city.name }}
            </option>
          </select>
          <select v-model="filters.type" @change="loadProperties">
            <option value="">All Types</option>
            <option value="apartment">Apartment</option>
            <option value="villa">Villa</option>
            <option value="house">House</option>
            <option value="commercial">Commercial</option>
            <option value="land">Land</option>
          </select>
          <select v-model="filters.listing_type" @change="loadProperties">
            <option value="">Sale/Rent</option>
            <option value="sale">For Sale</option>
            <option value="rent">For Rent</option>
            <option value="lease">For Lease</option>
          </select>
          <select v-model="filters.sort" @change="loadProperties">
            <option value="newest">Newest</option>
            <option value="price_low">Price: Low to High</option>
            <option value="price_high">Price: High to Low</option>
            <option value="popular">Most Popular</option>
          </select>
        </div>

        <!-- Price Range Filter -->
        <div class="price-range-filter">
          <div class="price-inputs">
            <div class="price-input-group">
              <label>Min Price (ETB)</label>
              <input 
                v-model.number="filters.min_price" 
                type="number" 
                placeholder="0"
                @input="debounceSearch"
              >
            </div>
            <span style="padding: 0 1rem; align-self: flex-end; padding-bottom: 0.75rem;">-</span>
            <div class="price-input-group">
              <label>Max Price (ETB)</label>
              <input 
                v-model.number="filters.max_price" 
                type="number" 
                placeholder="Any"
                @input="debounceSearch"
              >
            </div>
          </div>
          <div class="price-range-display" v-if="filters.min_price || filters.max_price">
            <span>
              {{ formatPrice(filters.min_price || 0) }} - 
              {{ filters.max_price ? formatPrice(filters.max_price) : 'Any' }} ETB
            </span>
            <button class="btn-clear" @click="clearPriceRange">Clear</button>
          </div>
        </div>
      </div>

      <!-- Results -->
      <div v-if="loading" class="loading">
        <div class="spinner"></div>
        <p>Loading properties...</p>
      </div>

      <div v-else>
        <p style="margin-bottom: 1rem; color: var(--text-light);">
          Found {{ pagination.total }} properties
        </p>

        <div v-if="properties.length === 0" class="loading">
          <p>No properties found</p>
        </div>

        <div v-else class="property-grid">
          <div 
            v-for="property in properties" 
            :key="property.property_id"
            class="property-card"
            @click="viewProperty(property.property_id)"
          >
            <img 
              :src="property.primary_image || '/placeholder.jpg'" 
              :alt="property.title"
              class="property-image"
            >
            <div class="property-content">
              <div class="property-price">
                {{ formatPrice(property.price) }} ETB
              </div>
              <h3 class="property-title">{{ property.title }}</h3>
              <div class="property-location">
                <i class="fas fa-map-marker-alt"></i>
                {{ property.city_name || 'Location' }}
              </div>
              <div class="property-features">
                <span v-if="property.bedrooms">
                  <i class="fas fa-bed"></i> {{ property.bedrooms }}
                </span>
                <span v-if="property.bathrooms">
                  <i class="fas fa-bath"></i> {{ property.bathrooms }}
                </span>
                <span v-if="property.size">
                  <i class="fas fa-ruler-combined"></i> {{ property.size }} m²
                </span>
              </div>
            </div>
          </div>
        </div>

        <!-- Pagination -->
        <div v-if="pagination.pages > 1" style="display: flex; justify-content: center; gap: 0.5rem; margin-top: 2rem;">
          <button 
            class="btn btn-outline" 
            :disabled="pagination.page === 1"
            @click="changePage(pagination.page - 1)"
          >
            Previous
          </button>
          <span style="padding: 0.75rem 1rem;">
            Page {{ pagination.page }} of {{ pagination.pages }}
          </span>
          <button 
            class="btn btn-outline"
            :disabled="pagination.page === pagination.pages"
            @click="changePage(pagination.page + 1)"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import api from '../api'

const router = useRouter()
const route = useRoute()
const loading = ref(true)
const properties = ref([])
const cities = ref([])
const pagination = ref({ page: 1, pages: 1, total: 0 })

const filters = ref({
  search: route.query.search || '',
  city_id: route.query.city_id || '',
  type: route.query.type || '',
  listing_type: route.query.listing_type || '',
  min_price: route.query.min_price || '',
  max_price: route.query.max_price || '',
  sort: 'newest',
  page: 1
})

let searchTimeout = null

onMounted(async () => {
  const citiesRes = await api.getCities()
  cities.value = citiesRes.data
  await loadProperties()
})

const loadProperties = async () => {
  loading.value = true
  try {
    const response = await api.getProperties(filters.value)
    properties.value = response.data.properties
    pagination.value = response.data.pagination
  } catch (error) {
    console.error('Error loading properties:', error)
  } finally {
    loading.value = false
  }
}

const debounceSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    loadProperties()
  }, 500)
}

const clearPriceRange = () => {
  filters.value.min_price = ''
  filters.value.max_price = ''
  loadProperties()
}

const formatPrice = (price) => {
  return new Intl.NumberFormat('en-US').format(price)
}

const viewProperty = (id) => {
  router.push(`/properties/${id}`)
}

const changePage = (page) => {
  filters.value.page = page
  loadProperties()
  window.scrollTo(0, 0)
}
</script>

<style scoped>
.filters-section {
  background: white;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.price-range-filter {
  margin-top: 1.5rem;
  padding-top: 1.5rem;
  border-top: 1px solid #eee;
}

.price-inputs {
  display: flex;
  align-items: flex-end;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.price-input-group {
  flex: 1;
  min-width: 150px;
}

.price-input-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
  color: #555;
  font-size: 0.9rem;
}

.price-input-group input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}

.price-range-display {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 1rem;
  padding: 0.75rem 1rem;
  background: #f8f9fa;
  border-radius: 4px;
}

.price-range-display span {
  font-weight: 500;
  color: #333;
}

.btn-clear {
  padding: 0.5rem 1rem;
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: all 0.2s;
}

.btn-clear:hover {
  background: #c82333;
}
</style>
