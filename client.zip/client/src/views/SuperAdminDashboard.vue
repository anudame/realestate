<template>
  <v-container>
    <h1>Super Admin Dashboard</h1>
    <p>System-wide administration and oversight</p>
    
    <v-row class="mt-4">
      <v-col cols="12" md="6">
        <v-card>
          <v-card-title>Quick Actions</v-card-title>
          <v-card-text>
            <v-btn color="primary" block class="mb-2" @click="$router.push('/users')">Manage Users</v-btn>
            <v-btn color="primary" block class="mb-2" @click="$router.push('/branches')">Manage Branches</v-btn>
            <v-btn color="primary" block @click="$router.push('/reports')">View Reports</v-btn>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: 'SuperAdminDashboard'
}
</script>
