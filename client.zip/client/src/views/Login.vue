<template>
  <div class="container" style="max-width: 400px; padding: 3rem 0;">
    <div class="info-section">
      <h1 style="text-align: center; margin-bottom: 2rem;">Admin Login</h1>
      
      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label>Email</label>
          <input v-model="email" type="email" required>
        </div>
        <div class="form-group">
          <label>Password</label>
          <input v-model="password" type="password" required>
        </div>
        
        <div v-if="error" class="alert alert-error">
          {{ error }}
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%;" :disabled="loading">
          {{ loading ? 'Logging in...' : 'Login' }}
        </button>
      </form>

      <p style="margin-top: 1rem; text-align: center; color: var(--text-light); font-size: 0.875rem;">
        Admin and Agent access only
      </p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const router = useRouter()
const authStore = useAuthStore()

const email = ref('')
const password = ref('')
const loading = ref(false)
const error = ref('')

const handleLogin = async () => {
  loading.value = true
  error.value = ''
  
  const result = await authStore.login(email.value, password.value)
  
  if (result.success) {
    router.push('/admin')
  } else {
    error.value = result.error
  }
  
  loading.value = false
}
</script>
