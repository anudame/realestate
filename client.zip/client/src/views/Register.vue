<template>
  <div class="container" style="max-width: 600px; margin-top: 50px;">
    <div class="card" style="text-align: center;">
      <div class="logo" style="justify-content: center; margin-bottom: 10px;">
        <div class="logo-icon" style="width: 60px; height: 60px; font-size: 36px;">💊</div>
      </div>
      <h1 style="color: #2c3e50; text-shadow: none; margin-bottom: 5px; font-size: 28px;">Moto Moto Solution</h1>
      <p style="color: #7f8c8d; margin-bottom: 30px;">Register Your Pharmacy</p>
      
      <form @submit.prevent="register" style="text-align: left;">
        <h3 style="margin-bottom: 15px; color: #667eea;">Pharmacy Information</h3>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div class="form-group">
            <label>Pharmacy Name *</label>
            <input v-model="pharmacy.name" required />
          </div>
          <div class="form-group">
            <label>Location *</label>
            <input v-model="pharmacy.location" required />
          </div>
          <div class="form-group">
            <label>Phone Number *</label>
            <input v-model="pharmacy.phone" type="tel" required />
          </div>
          <div class="form-group">
            <label>Email</label>
            <input v-model="pharmacy.email" type="email" />
          </div>
        </div>

        <h3 style="margin: 25px 0 15px 0; color: #667eea;">System License</h3>
        
        <div style="padding: 25px; border: 3px solid #667eea; border-radius: 12px; background: linear-gradient(135deg, #f0f4ff 0%, #e8f0ff 100%); margin-bottom: 20px; text-align: center;">
          <h4 style="margin: 0 0 10px 0; color: #667eea; font-size: 20px;">One-Time Purchase</h4>
          <p style="font-size: 48px; font-weight: bold; margin: 15px 0; color: #2c3e50;">$499</p>
          <p style="font-size: 16px; color: #7f8c8d; margin: 10px 0;">Lifetime Access</p>
          <ul style="list-style: none; padding: 0; margin: 15px 0; text-align: left; max-width: 300px; margin: 15px auto;">
            <li style="padding: 5px 0; color: #27ae60;">✓ Unlimited Users</li>
            <li style="padding: 5px 0; color: #27ae60;">✓ All Features Included</li>
            <li style="padding: 5px 0; color: #27ae60;">✓ Free Updates</li>
            <li style="padding: 5px 0; color: #27ae60;">✓ Technical Support</li>
            <li style="padding: 5px 0; color: #27ae60;">✓ No Monthly Fees</li>
          </ul>
        </div>

        <h3 style="margin: 25px 0 15px 0; color: #667eea;">Payment Information</h3>
        
        <div class="form-group">
          <label>Payment Method *</label>
          <select v-model="payment.method" required>
            <option value="">Select Payment Method</option>
            <option value="mobile">Mobile Payment (Chapa/Telebirr)</option>
            <option value="bank">Bank Transfer</option>
            <option value="card">Credit/Debit Card</option>
          </select>
        </div>

        <div v-if="payment.method === 'mobile'" class="form-group">
          <label>Phone Number *</label>
          <input v-model="payment.phoneNumber" type="tel" required placeholder="+251..." />
        </div>

        <div v-if="payment.method === 'bank'" style="padding: 15px; background: #f8f9fa; border-radius: 8px; margin-bottom: 15px;">
          <p style="margin: 0 0 10px 0; font-weight: bold;">Bank Transfer Details:</p>
          <p style="margin: 5px 0; font-size: 14px;">Bank: Commercial Bank of Ethiopia</p>
          <p style="margin: 5px 0; font-size: 14px;">Account: 1000123456789</p>
          <p style="margin: 5px 0; font-size: 14px;">Account Name: Moto Moto Solution</p>
          <div class="form-group" style="margin-top: 10px;">
            <label>Transaction Reference *</label>
            <input v-model="payment.transactionRef" required placeholder="Enter transaction reference" />
          </div>
        </div>

        <div v-if="payment.method === 'card'" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div class="form-group" style="grid-column: 1 / -1;">
            <label>Card Number *</label>
            <input v-model="payment.cardNumber" required placeholder="1234 5678 9012 3456" maxlength="19" />
          </div>
          <div class="form-group">
            <label>Expiry Date *</label>
            <input v-model="payment.expiryDate" required placeholder="MM/YY" maxlength="5" />
          </div>
          <div class="form-group">
            <label>CVV *</label>
            <input v-model="payment.cvv" required placeholder="123" maxlength="3" type="password" />
          </div>
        </div>

        <h3 style="margin: 25px 0 15px 0; color: #667eea;">Admin Account</h3>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div class="form-group">
            <label>Full Name *</label>
            <input v-model="admin.fullName" required />
          </div>
          <div class="form-group">
            <label>Username *</label>
            <input v-model="admin.username" required minlength="4" />
          </div>
          <div class="form-group">
            <label>Password *</label>
            <input v-model="admin.password" type="password" required minlength="6" />
          </div>
          <div class="form-group">
            <label>Confirm Password *</label>
            <input v-model="admin.confirmPassword" type="password" required minlength="6" />
          </div>
        </div>

        <div style="margin: 20px 0;">
          <label style="display: flex; align-items: center; cursor: pointer;">
            <input type="checkbox" v-model="agreedToTerms" required style="margin-right: 8px; width: auto;" />
            <span style="font-size: 14px;">I agree to the Terms of Service and Privacy Policy</span>
          </label>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%;" :disabled="loading">
          {{ loading ? 'Creating Account...' : 'Register Pharmacy' }}
        </button>
        
        <p v-if="error" style="color: red; margin-top: 15px; text-align: center;">{{ error }}</p>
        <p v-if="success" style="color: green; margin-top: 15px; text-align: center;">{{ success }}</p>
        
        <p style="text-align: center; margin-top: 20px; color: #7f8c8d;">
          Already have an account? 
          <router-link to="/login" style="color: #667eea; font-weight: bold;">Login here</router-link>
        </p>
      </form>
    </div>
  </div>
</template>

<script>
import api from '../api'

export default {
  data() {
    return {
      pharmacy: {
        name: '',
        location: '',
        phone: '',
        email: ''
      },
      admin: {
        fullName: '',
        username: '',
        password: '',
        confirmPassword: ''
      },
      selectedPlan: 'lifetime',
      payment: {
        method: '',
        phoneNumber: '',
        transactionRef: '',
        cardNumber: '',
        expiryDate: '',
        cvv: ''
      },
      agreedToTerms: false,
      loading: false,
      error: '',
      success: ''
    }
  },
  methods: {
    async register() {
      this.error = ''
      this.success = ''
      
      // Validation
      if (this.admin.password !== this.admin.confirmPassword) {
        this.error = 'Passwords do not match'
        return
      }
      
      if (this.admin.password.length < 6) {
        this.error = 'Password must be at least 6 characters'
        return
      }
      
      if (!this.agreedToTerms) {
        this.error = 'Please agree to the Terms of Service'
        return
      }
      
      // Validate payment
      if (!this.payment.method) {
        this.error = 'Please select a payment method'
        return
      }
      
      if (this.payment.method === 'mobile' && !this.payment.phoneNumber) {
        this.error = 'Please enter your phone number'
        return
      }
      
      if (this.payment.method === 'bank' && !this.payment.transactionRef) {
        this.error = 'Please enter transaction reference'
        return
      }
      
      this.loading = true
      
      try {
        const response = await api.post('/auth/register', {
          pharmacy: this.pharmacy,
          admin: {
            fullName: this.admin.fullName,
            username: this.admin.username,
            password: this.admin.password
          },
          subscription: {
            plan: this.selectedPlan,
            paymentMethod: this.payment.method,
            paymentDetails: this.payment
          }
        })
        
        this.success = response.data.message || 'Registration successful! Redirecting to login...'
        
        setTimeout(() => {
          this.$router.push('/login')
        }, 2000)
        
      } catch (err) {
        this.error = err.response?.data?.error || 'Registration failed. Please try again.'
      } finally {
        this.loading = false
      }
    }
  }
}
</script>
