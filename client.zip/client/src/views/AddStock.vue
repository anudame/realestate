<template>
  <div class="container">
    <h1>Add Stock</h1>
    
    <!-- Excel Import Section -->
    <v-card elevation="3" class="mb-4">
      <v-card-title>
        <v-icon class="mr-2">mdi-file-excel</v-icon>
        Bulk Import from Excel
      </v-card-title>
      <v-card-text>
        <v-row align="center">
          <v-col cols="12" md="4">
            <v-btn
              @click="downloadTemplate"
              color="success"
              prepend-icon="mdi-download"
              block
            >
              Download Template
            </v-btn>
          </v-col>
          <v-col cols="12" md="4">
            <input 
              type="file" 
              ref="fileInput"
              @change="handleFileUpload"
              accept=".xlsx,.xls"
              style="display: none;"
            />
            <v-btn
              @click="$refs.fileInput.click()"
              color="primary"
              prepend-icon="mdi-upload"
              block
            >
              Upload Excel File
            </v-btn>
          </v-col>
          <v-col cols="12" md="4" v-if="uploadedFileName">
            <v-chip color="success" prepend-icon="mdi-check">
              {{ uploadedFileName }}
            </v-chip>
          </v-col>
        </v-row>
        
        <!-- Preview -->
        <v-card v-if="importedData.length > 0" class="mt-4" variant="outlined">
          <v-card-title>Preview ({{ importedData.length }} items)</v-card-title>
          <v-card-text>
            <div style="max-height: 300px; overflow-y: auto;">
              <v-table density="compact">
                <thead>
                  <tr>
                    <th>Generic Name</th>
                    <th>Brand</th>
                    <th>Batch</th>
                    <th>Quantity</th>
                    <th>Expiry</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(item, idx) in importedData.slice(0, 10)" :key="idx">
                    <td>{{ item.genericName }}</td>
                    <td>{{ item.brandName }}</td>
                    <td>{{ item.batchNumber }}</td>
                    <td>{{ item.quantity }}</td>
                    <td>{{ item.expiryDate }}</td>
                  </tr>
                </tbody>
              </v-table>
            </div>
            <v-alert v-if="importedData.length > 10" type="info" density="compact" class="mt-2">
              Showing first 10 of {{ importedData.length }} items
            </v-alert>
            
            <v-row class="mt-4">
              <v-col>
                <v-btn
                  @click="importAllMedicines"
                  color="primary"
                  prepend-icon="mdi-check-all"
                  block
                >
                  Import All {{ importedData.length }} Medicines
                </v-btn>
              </v-col>
              <v-col>
                <v-btn
                  @click="clearImport"
                  color="grey"
                  prepend-icon="mdi-close"
                  block
                >
                  Cancel
                </v-btn>
              </v-col>
            </v-row>
          </v-card-text>
        </v-card>
      </v-card-text>
    </v-card>
    
    <div class="card">
      <h3>Add New Medicine</h3>
      <form @submit.prevent="addMedicine">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div class="form-group">
            <label>Generic Name *</label>
            <input v-model="medicine.genericName" required />
          </div>
          <div class="form-group">
            <label>Brand Name</label>
            <input v-model="medicine.brandName" />
          </div>
          <div class="form-group">
            <label>Category *</label>
            <input v-model="medicine.category" 
                   placeholder="Enter category (e.g., Analgesic, Antibiotic)" 
                   required />
          </div>
          <div class="form-group">
            <label>Form *</label>
            <input v-model="medicine.form" 
                   placeholder="Enter form (e.g., Tablet, Capsule, Syrup)" 
                   required />
          </div>
          <div class="form-group">
            <label>Strength</label>
            <input v-model="medicine.strength" placeholder="e.g., 500mg" />
          </div>
          <div class="form-group">
            <label>Barcode</label>
            <input v-model="medicine.barcode" />
          </div>
          <div class="form-group">
            <label>Purchase Price *</label>
            <input v-model.number="medicine.purchasePrice" type="number" step="0.01" required />
          </div>
          <div class="form-group">
            <label>Selling Price *</label>
            <input v-model.number="medicine.sellingPrice" type="number" step="0.01" required />
          </div>
          <div class="form-group">
            <label>Reorder Level</label>
            <input v-model.number="medicine.reorderLevel" type="number" value="10" />
          </div>
          <div class="form-group">
            <label>Batch Number *</label>
            <input v-model="medicine.batchNumber" placeholder="e.g., BATCH001" required />
          </div>
          <div class="form-group">
            <label>Expiry Date *</label>
            <input v-model="medicine.expiryDate" type="date" required />
          </div>
          <div class="form-group">
            <label>Quantity *</label>
            <input v-model.number="medicine.quantity" type="number" min="1" placeholder="Initial stock quantity" required />
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Add Medicine with Stock</button>
      </form>
    </div>

    <div class="card" style="margin-top: 20px;">
      <h3>Add Stock to Existing Medicine</h3>
      <form @submit.prevent="addBatch">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div class="form-group">
            <label>Search Medicine *</label>
            <input v-model="searchQuery" @input="searchMedicines" placeholder="Search by name or barcode" />
            <div v-if="searchResults.length" style="border: 1px solid #ddd; max-height: 200px; overflow-y: auto;">
              <div v-for="med in searchResults" :key="med.medicine_id" 
                   @click="selectMedicine(med)"
                   style="padding: 10px; cursor: pointer; border-bottom: 1px solid #eee;">
                {{ med.generic_name }} - {{ med.brand_name }} ({{ med.strength }})
              </div>
            </div>
            <p v-if="selectedMedicine" style="margin-top: 5px; color: green;">
              Selected: {{ selectedMedicine.generic_name }} - {{ selectedMedicine.brand_name }}
            </p>
          </div>
          <div class="form-group">
            <label>Batch Number *</label>
            <input v-model="batch.batchNumber" required placeholder="Enter batch number" />
          </div>
          <div class="form-group">
            <label>Expiry Date *</label>
            <input v-model="batch.expiryDate" type="date" required />
          </div>
          <div class="form-group">
            <label>Quantity *</label>
            <input v-model.number="batch.quantity" type="number" required />
          </div>
          <div class="form-group">
            <label>Purchase Price *</label>
            <input v-model.number="batch.purchasePrice" type="number" step="0.01" required />
          </div>
          <div class="form-group">
            <label>Selling Price *</label>
            <input v-model.number="batch.sellingPrice" type="number" step="0.01" required />
          </div>
        </div>
        <button type="submit" class="btn btn-primary" :disabled="!selectedMedicine">Add Stock Batch</button>
      </form>
    </div>
  </div>
</template>

<script>
import api from '../api'
import * as XLSX from 'xlsx'

export default {
  data() {
    return {
      importedData: [],
      uploadedFileName: '',
      medicine: {
        genericName: '',
        brandName: '',
        category: '',
        form: '',
        strength: '',
        barcode: '',
        purchasePrice: 0,
        sellingPrice: 0,
        reorderLevel: 10,
        batchNumber: '',
        expiryDate: '',
        quantity: 0
      },
      batch: {
        batchNumber: '',
        expiryDate: '',
        quantity: 0,
        purchasePrice: 0,
        sellingPrice: 0
      },
      searchQuery: '',
      searchResults: [],
      selectedMedicine: null
    }
  },
  mounted() {
  },
  methods: {
    async addMedicine() {
      try {
        const { data } = await api.post('/medicines', this.medicine)
        
        // Add initial stock batch if medicine was created successfully
        if (data.medicineId && this.medicine.quantity > 0) {
          await api.post('/stock/batch', {
            medicineId: data.medicineId,
            batchNumber: this.medicine.batchNumber,
            expiryDate: this.medicine.expiryDate,
            quantity: this.medicine.quantity,
            purchasePrice: this.medicine.purchasePrice,
            sellingPrice: this.medicine.sellingPrice
          })
        }
        
        alert('Medicine and initial stock added successfully!')
        this.medicine = {
          genericName: '',
          brandName: '',
          category: '',
          form: '',
          strength: '',
          barcode: '',
          purchasePrice: 0,
          sellingPrice: 0,
          reorderLevel: 10,
          batchNumber: '',
          expiryDate: '',
          quantity: 0
        }
      } catch (err) {
        alert(err.response?.data?.error || 'Failed to add medicine')
      }
    },
    async searchMedicines() {
      if (this.searchQuery.length < 2) {
        this.searchResults = []
        return
      }
      try {
        const { data } = await api.get(`/medicines/search?q=${this.searchQuery}`)
        this.searchResults = data
      } catch (err) {
        console.error(err)
      }
    },
    async selectMedicine(med) {
      this.selectedMedicine = med
      this.searchResults = []
      this.searchQuery = `${med.generic_name} - ${med.brand_name}`
      
      // Auto-fill prices from medicine defaults
      this.batch.purchasePrice = med.default_purchase_price || 0
      this.batch.sellingPrice = med.default_selling_price || 0
      
      // Fetch existing batches for this medicine
      try {
        const { data } = await api.get(`/stock/medicine/${med.medicine_id}`)
        if (data.length > 0) {
          // Get the most recent batch
          const latestBatch = data[0]
          // Auto-fill with the latest batch number (user can modify)
          this.batch.batchNumber = latestBatch.batch_number || ''
          this.batch.expiryDate = latestBatch.expiry_date ? latestBatch.expiry_date.split('T')[0] : ''
        } else {
          // No existing batches, leave fields empty for user input
          this.batch.batchNumber = ''
          this.batch.expiryDate = ''
        }
      } catch (err) {
        console.error('Error fetching batches:', err)
        // Leave fields empty on error
        this.batch.batchNumber = ''
        this.batch.expiryDate = ''
      }
      
      // Default quantity
      this.batch.quantity = 100
    },
    async addBatch() {
      if (!this.selectedMedicine) {
        alert('Please select a medicine first')
        return
      }
      try {
        await api.post('/stock/batch', {
          medicineId: this.selectedMedicine.medicine_id,
          ...this.batch
        })
        alert('Stock batch added successfully!')
        this.batch = {
          batchNumber: '',
          expiryDate: '',
          quantity: 0,
          purchasePrice: 0,
          sellingPrice: 0
        }
        this.selectedMedicine = null
        this.searchQuery = ''
      } catch (err) {
        alert(err.response?.data?.error || 'Failed to add stock')
      }
    },
    downloadTemplate() {
      const template = [
        {
          generic_name: 'Paracetamol',
          brand_name: 'Tylenol',
          category: 'Analgesic',
          form: 'Tablet',
          strength: '500mg',
          purchase_price: 5.00,
          selling_price: 8.00,
          reorder_level: 10,
          max_stock_level: 1000,
          batch_number: 'BATCH-001',
          quantity: 100,
          expiry_date: '2025-12-31',
          barcode: '1234567890',
          sku: 'MED-001'
        },
        {
          generic_name: 'Amoxicillin',
          brand_name: 'Amoxil',
          category: 'Antibiotic',
          form: 'Capsule',
          strength: '250mg',
          purchase_price: 10.00,
          selling_price: 15.00,
          reorder_level: 20,
          max_stock_level: 500,
          batch_number: 'BATCH-002',
          quantity: 200,
          expiry_date: '2026-06-30',
          barcode: '9876543210',
          sku: 'MED-002'
        }
      ]
      const ws = XLSX.utils.json_to_sheet(template)
      const wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, ws, 'Medicines')
      XLSX.writeFile(wb, 'medicine_import_template.xlsx')
    },
    handleFileUpload(event) {
      const file = event.target.files[0]
      if (!file) return
      this.uploadedFileName = file.name
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result)
          const workbook = XLSX.read(data, { type: 'array' })
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
          const jsonData = XLSX.utils.sheet_to_json(firstSheet)
          
          // Log first row to see column names
          if (jsonData.length > 0) {
            console.log('Excel columns found:', Object.keys(jsonData[0]))
            console.log('First row data:', jsonData[0])
          }
          
          this.importedData = jsonData.map(row => ({
            genericName: row.generic_name || row['Generic Name'] || row.GenericName || '',
            brandName: row.brand_name || row['Brand Name'] || row.BrandName || '',
            category: row.category || row['Category'] || '',
            form: row.form || row['Form'] || '',
            strength: row.strength || row['Strength'] || '',
            barcode: row.barcode || row['Barcode'] || '',
            sku: row.sku || row['SKU'] || '',
            purchasePrice: parseFloat(row.purchase_price || row['Purchase Price'] || row.PurchasePrice) || 0,
            sellingPrice: parseFloat(row.selling_price || row['Selling Price'] || row.SellingPrice) || 0,
            reorderLevel: parseInt(row.reorder_level || row['Reorder Level'] || row.ReorderLevel) || 10,
            maxStockLevel: parseInt(row.max_stock_level || row['Max Stock Level'] || row.MaxStockLevel) || 1000,
            batchNumber: row.batch_number || row['Batch Number'] || row.BatchNumber || '',
            quantity: parseInt(row.quantity || row['Quantity']) || 0,
            expiryDate: row.expiry_date || row['Expiry Date'] || row.ExpiryDate || ''
          }))
          
          if (this.importedData.length === 0) {
            alert('No data found in Excel file')
          } else {
            console.log('Parsed data sample:', this.importedData[0])
          }
        } catch (err) {
          alert('Error reading Excel file: ' + err.message)
        }
      }
      reader.readAsArrayBuffer(file)
    },
    async importAllMedicines() {
      if (this.importedData.length === 0) return
      
      let successCount = 0
      let errorCount = 0
      const errors = []
      
      for (const medicine of this.importedData) {
        try {
          // First create the medicine
          const { data } = await api.post('/medicines', {
            genericName: medicine.genericName,
            brandName: medicine.brandName,
            category: medicine.category,
            form: medicine.form,
            strength: medicine.strength,
            barcode: medicine.barcode,
            purchasePrice: medicine.purchasePrice,
            sellingPrice: medicine.sellingPrice,
            reorderLevel: medicine.reorderLevel
          })
          
          // Then add the initial stock batch
          if (data.medicineId && medicine.quantity > 0) {
            await api.post('/stock/batch', {
              medicineId: data.medicineId,
              batchNumber: medicine.batchNumber,
              expiryDate: medicine.expiryDate,
              quantity: medicine.quantity,
              purchasePrice: medicine.purchasePrice,
              sellingPrice: medicine.sellingPrice
            })
          }
          
          successCount++
        } catch (err) {
          errorCount++
          const errorMsg = err.response?.data?.error || err.response?.data?.sqlMessage || err.message
          errors.push(`${medicine.genericName}: ${errorMsg}`)
          console.error('Failed to import:', medicine.genericName, err.response?.data || err)
        }
      }
      
      let message = `Import complete!\nSuccess: ${successCount}\nFailed: ${errorCount}`
      if (errors.length > 0 && errors.length <= 5) {
        message += '\n\nErrors:\n' + errors.join('\n')
      }
      
      alert(message)
      
      if (successCount > 0) {
        this.clearImport()
      }
    },
    clearImport() {
      this.importedData = []
      this.uploadedFileName = ''
      if (this.$refs.fileInput) {
        this.$refs.fileInput.value = ''
      }
    }
  }
}
</script>
