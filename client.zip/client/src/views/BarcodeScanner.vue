<template>
  <div class="barcode-scanner">
    <div class="page-header">
      <h1>🔍 Barcode Scanner</h1>
      <select v-model="scanMode" class="mode-selector">
        <option value="lookup">Product Lookup</option>
        <option value="intake">Stock Intake</option>
        <option value="audit">Stock Audit</option>
        <option value="sale">Quick Sale</option>
      </select>
    </div>

    <!-- Scan Input -->
    <div class=""></div>