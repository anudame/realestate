<template>
  <div class="container">
    <h1>📊 Reports & Analytics</h1>

    <!-- Report Type Selector -->
    <div class="card">
      <div class="report-tabs">
        <button 
          v-for="tab in reportTabs" 
          :key="tab.id"
          @click="activeTab = tab.id"
          :class="['tab-btn', { active: activeTab === tab.id }]"
        >
          {{ tab.icon }} {{ tab.name }}
        </button>
      </div>
    </div>

    <!-- Date Range Filter -->
    <div class="card">
      <div class="filter-row">
        <div class="form-group">
          <label>From Date</label>
          <input v-model="filters.fromDate" type="date">
        </div>
        <div class="form-group">
          <label>To Date</label>
          <input v-model="filters.toDate" type="date">
        </div>
        <div class="form-group" v-if="activeTab === 'sales' || activeTab === 'products'">
          <label>Category</label>
          <select v-model="filters.categoryId">
            <option value="">All Categories</option>
            <option v-for="cat in categories" :key="cat.category_id" :value="cat.category_id">
              {{ cat.category_name }}
            </option>
          </select>
        </div>
        <button @click="loadReport" class="btn btn-primary" style="margin-top: 22px;">
          🔍 Generate Report
        </button>
        <button @click="exportReport" class="btn btn-secondary" style="margin-top: 22px;" :disabled="!reportData">
          📥 Export Excel
        </button>
      </div>
    </div>

    <!-- Sales Report -->
    <div v-if="activeTab === 'sales' && reportData" class="card">
      <h2>📈 Sales Report</h2>
      <div class="summary-grid">
        <div class="summary-card">
          <h4>Total Revenue</h4>
          <p class="big-number">ETB {{ reportData.reduce((sum, r) => sum + (r.net_sales || 0), 0).toFixed(2) }}</p>
        </div>
        <div class="summary-card">
          <h4>Total Transactions</h4>
          <p class="big-number">{{ reportData.reduce((sum, r) => sum + (r.total_invoices || 0), 0) }}</p>
        </div>
        <div class="summary-card">
          <h4>Items Sold</h4>
          <p class="big-number">{{ reportData.reduce((sum, r) => sum + (r.total_items_sold || 0), 0) }}</p>
        </div>
        <div class="summary-card">
          <h4>Avg Transaction</h4>
          <p class="big-number">ETB {{ (reportData.reduce((sum, r) => sum + (r.net_sales || 0), 0) / reportData.reduce((sum, r) => sum + (r.total_invoices || 0), 1)).toFixed(2) }}</p>
        </div>
      </div>
      
      <table class="table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Invoices</th>
            <th>Items Sold</th>
            <th>Gross Sales</th>
            <th>Discount</th>
            <th>Tax</th>
            <th>Net Sales</th>
            <th>Cash</th>
            <th>Card</th>
            <th>Mobile</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in reportData" :key="row.sale_date">
            <td>{{ formatDate(row.sale_date) }}</td>
            <td>{{ row.total_invoices }}</td>
            <td>{{ row.total_items_sold }}</td>
            <td>ETB {{ row.gross_sales?.toFixed(2) }}</td>
            <td>ETB {{ row.total_discount?.toFixed(2) }}</td>
            <td>ETB {{ row.total_tax?.toFixed(2) }}</td>
            <td><strong>ETB {{ row.net_sales?.toFixed(2) }}</strong></td>
            <td>ETB {{ row.cash_sales?.toFixed(2) }}</td>
            <td>ETB {{ row.card_sales?.toFixed(2) }}</td>
            <td>ETB {{ row.mobile_sales?.toFixed(2) }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Product Report -->
    <div v-if="activeTab === 'products' && reportData" class="card">
      <h2>📦 Product Performance Report</h2>
      <table class="table">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Product</th>
            <th>Category</th>
            <th>Times Sold</th>
            <th>Quantity Sold</th>
            <th>Revenue</th>
            <th>Avg Price</th>
            <th>Stock Status</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(row, idx) in reportData" :key="row.medicine_id">
            <td><strong>{{ idx + 1 }}</strong></td>
            <td>
              <strong>{{ row.generic_name }}</strong><br>
              <small>{{ row.brand_name }}</small>
            </td>
            <td>{{ row.category_name }}</td>
            <td>{{ row.times_sold }}</td>
            <td><strong>{{ row.total_quantity_sold }}</strong></td>
            <td><strong>ETB {{ row.total_revenue?.toFixed(2) }}</strong></td>
            <td>ETB {{ row.avg_selling_price?.toFixed(2) }}</td>
            <td>
              <span :class="'status-badge status-' + row.stock_status.toLowerCase().replace(' ', '-')">
                {{ row.stock_status }}
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Profit & Loss Report -->
    <div v-if="activeTab === 'profit-loss' && reportData" class="card">
      <h2>💰 Profit & Loss Statement</h2>
      
      <div class="summary-grid">
        <div class="summary-card success">
          <h4>Total Revenue</h4>
          <p class="big-number">ETB {{ reportData.totals.revenue.toFixed(2) }}</p>
        </div>
        <div class="summary-card danger">
          <h4>Total Cost</h4>
          <p class="big-number">ETB {{ reportData.totals.cost.toFixed(2) }}</p>
        </div>
        <div class="summary-card primary">
          <h4>Gross Profit</h4>
          <p class="big-number">ETB {{ reportData.totals.profit.toFixed(2) }}</p>
        </div>
        <div class="summary-card warning">
          <h4>Profit Margin</h4>
          <p class="big-number">{{ reportData.totals.margin }}%</p>
        </div>
      </div>

      <table class="table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Revenue</th>
            <th>Cost of Goods</th>
            <th>Gross Profit</th>
            <th>Profit Margin</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in reportData.daily" :key="row.report_date">
            <td>{{ formatDate(row.report_date) }}</td>
            <td>ETB {{ row.revenue?.toFixed(2) }}</td>
            <td>ETB {{ row.cost_of_goods?.toFixed(2) }}</td>
            <td><strong :style="{ color: row.gross_profit > 0 ? '#27ae60' : '#e74c3c' }">
              ETB {{ row.gross_profit?.toFixed(2) }}
            </strong></td>
            <td>{{ row.profit_margin?.toFixed(2) }}%</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Inventory Turnover Report -->
    <div v-if="activeTab === 'inventory' && reportData" class="card">
      <h2>🔄 Inventory Turnover Report</h2>
      <table class="table">
        <thead>
          <tr>
            <th>Product</th>
            <th>Category</th>
            <th>Current Stock</th>
            <th>Stock Value</th>
            <th>Units Sold</th>
            <th>Turnover Ratio</th>
            <th>Days to Sell</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in reportData" :key="row.medicine_id">
            <td>
              <strong>{{ row.generic_name }}</strong><br>
              <small>{{ row.brand_name }}</small>
            </td>
            <td>{{ row.category_name }}</td>
            <td>{{ row.current_stock }}</td>
            <td>ETB {{ row.stock_value?.toFixed(2) }}</td>
            <td>{{ row.units_sold }}</td>
            <td><strong>{{ row.turnover_ratio?.toFixed(2) }}</strong></td>
            <td>{{ Math.round(row.days_to_sell) }} days</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Order Status Report -->
    <div v-if="activeTab === 'orders' && reportData" class="card">
      <h2>📋 Order Status Report</h2>
      <table class="table">
        <thead>
          <tr>
            <th>Invoice #</th>
            <th>Date</th>
            <th>Customer</th>
            <th>Sales Person</th>
            <th>Items</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Carrier</th>
            <th>Tracking</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in reportData" :key="row.invoice_id">
            <td><strong>{{ row.invoice_number }}</strong></td>
            <td>{{ formatDate(row.invoice_date) }}</td>
            <td>{{ row.customer_name || 'Walk-in' }}</td>
            <td>{{ row.sales_person }}</td>
            <td>{{ row.total_items }} ({{ row.total_quantity }})</td>
            <td><strong>ETB {{ row.net_amount?.toFixed(2) }}</strong></td>
            <td>
              <span :class="'status-badge status-' + (row.order_status || 'completed')">
                {{ row.order_status || 'completed' }}
              </span>
            </td>
            <td>{{ row.carrier_name || '-' }}</td>
            <td>{{ row.tracking_id || '-' }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Expiry Report -->
    <div v-if="activeTab === 'expiry' && reportData" class="card">
      <h2>⏰ Expiry Report</h2>
      
      <div class="summary-grid">
        <div class="summary-card danger">
          <h4>Expired Items</h4>
          <p class="big-number">{{ reportData.summary.expired }}</p>
        </div>
        <div class="summary-card warning">
          <h4>Critical (7 days)</h4>
          <p class="big-number">{{ reportData.summary.critical }}</p>
        </div>
        <div class="summary-card info">
          <h4>High (30 days)</h4>
          <p class="big-number">{{ reportData.summary.high }}</p>
        </div>
        <div class="summary-card">
          <h4>Total Value at Risk</h4>
          <p class="big-number">₹{{ reportData.summary.totalValue?.toFixed(2) }}</p>
        </div>
      </div>

      <table class="table">
        <thead>
          <tr>
            <th>Product</th>
            <th>Batch</th>
            <th>Expiry Date</th>
            <th>Days Left</th>
            <th>Quantity</th>
            <th>Value</th>
            <th>Priority</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in reportData.items" :key="row.batch_id" :style="{ backgroundColor: getPriorityColor(row.priority) }">
            <td>
              <strong>{{ row.generic_name }}</strong><br>
              <small>{{ row.brand_name }}</small>
            </td>
            <td>{{ row.batch_number }}</td>
            <td>{{ formatDate(row.expiry_date) }}</td>
            <td><strong>{{ row.days_until_expiry }}</strong></td>
            <td>{{ row.quantity_in_stock }}</td>
            <td>₹{{ row.stock_value?.toFixed(2) }}</td>
            <td>
              <span :class="'status-badge status-' + row.priority">
                {{ row.priority }}
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <p v-if="!reportData && !loading" class="no-data">
      Select a report type and date range, then click "Generate Report"
    </p>
    
    <div v-if="loading" class="loading">
      <p>Loading report...</p>
    </div>
  </div>
</template>

<script>
import api from '../api'

export default {
  data() {
    const today = new Date()
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1)
    
    return {
      activeTab: 'sales',
      reportTabs: [
        { id: 'sales', name: 'Sales Report', icon: '📈' },
        { id: 'products', name: 'Product Performance', icon: '📦' },
        { id: 'profit-loss', name: 'Profit & Loss', icon: '💰' },
        { id: 'inventory', name: 'Inventory Turnover', icon: '🔄' },
        { id: 'orders', name: 'Order Status', icon: '📋' },
        { id: 'expiry', name: 'Expiry Report', icon: '⏰' }
      ],
      filters: {
        fromDate: firstDay.toISOString().split('T')[0],
        toDate: today.toISOString().split('T')[0],
        categoryId: ''
      },
      reportData: null,
      categories: [],
      loading: false
    }
  },
  async mounted() {
    await this.loadCategories()
  },
  methods: {
    async loadCategories() {
      try {
        const { data } = await api.get('/categories')
        this.categories = data
      } catch (error) {
        console.error('Error loading categories:', error)
      }
    },
    async loadReport() {
      this.loading = true
      this.reportData = null
      
      try {
        let endpoint = ''
        const params = new URLSearchParams()
        
        if (this.filters.fromDate) params.append('fromDate', this.filters.fromDate)
        if (this.filters.toDate) params.append('toDate', this.filters.toDate)
        if (this.filters.categoryId) params.append('categoryId', this.filters.categoryId)
        
        switch (this.activeTab) {
          case 'sales':
            endpoint = '/reports/sales'
            break
          case 'products':
            endpoint = '/reports/products'
            break
          case 'profit-loss':
            endpoint = '/reports/profit-loss'
            break
          case 'inventory':
            endpoint = '/reports/inventory-turnover'
            break
          case 'orders':
            endpoint = '/reports/orders'
            break
          case 'expiry':
            endpoint = '/reports/expiry'
            params.append('daysAhead', 90)
            break
        }
        
        const { data } = await api.get(`${endpoint}?${params.toString()}`)
        this.reportData = data
      } catch (error) {
        alert('Error loading report: ' + error.message)
      } finally {
        this.loading = false
      }
    },
    async exportReport() {
      // Simple CSV export
      if (!this.reportData) return
      
      let csv = ''
      let filename = `${this.activeTab}-report-${this.filters.fromDate}-to-${this.filters.toDate}.csv`
      
      // Convert report data to CSV based on type
      if (Array.isArray(this.reportData)) {
        if (this.reportData.length > 0) {
          const headers = Object.keys(this.reportData[0])
          csv = headers.join(',') + '\n'
          this.reportData.forEach(row => {
            csv += headers.map(h => row[h]).join(',') + '\n'
          })
        }
      } else if (this.reportData.items) {
        // For expiry report
        const headers = Object.keys(this.reportData.items[0])
        csv = headers.join(',') + '\n'
        this.reportData.items.forEach(row => {
          csv += headers.map(h => row[h]).join(',') + '\n'
        })
      }
      
      // Download
      const blob = new Blob([csv], { type: 'text/csv' })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = filename
      link.click()
    },
    formatDate(dateString) {
      return new Date(dateString).toLocaleDateString()
    },
    getPriorityColor(priority) {
      const colors = {
        'Expired': '#ffebee',
        'Critical': '#ffcdd2',
        'High': '#fff3e0',
        'Medium': '#e3f2fd',
        'Low': '#f1f8e9'
      }
      return colors[priority] || 'white'
    }
  }
}
</script>

<style scoped>
.report-tabs {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.tab-btn {
  padding: 12px 20px;
  border: 2px solid #ddd;
  background: white;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s;
}

.tab-btn:hover {
  border-color: #3498db;
  background: #ecf0f1;
}

.tab-btn.active {
  background: #3498db;
  color: white;
  border-color: #3498db;
}

.filter-row {
  display: flex;
  gap: 15px;
  align-items: flex-end;
  flex-wrap: wrap;
}

.form-group {
  display: flex;
  flex-direction: column;
}

.form-group label {
  margin-bottom: 5px;
  font-weight: bold;
  font-size: 14px;
}

.form-group input,
.form-group select {
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  min-width: 150px;
}

.summary-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
  margin-bottom: 20px;
}

.summary-card {
  padding: 20px;
  background: #f8f9fa;
  border-radius: 8px;
  border-left: 4px solid #3498db;
}

.summary-card.success {
  border-left-color: #27ae60;
  background: #e8f5e9;
}

.summary-card.danger {
  border-left-color: #e74c3c;
  background: #ffebee;
}

.summary-card.warning {
  border-left-color: #f39c12;
  background: #fff3e0;
}

.summary-card.primary {
  border-left-color: #3498db;
  background: #e3f2fd;
}

.summary-card.info {
  border-left-color: #9b59b6;
  background: #f3e5f5;
}

.summary-card h4 {
  margin: 0 0 10px 0;
  font-size: 14px;
  color: #7f8c8d;
}

.big-number {
  font-size: 28px;
  font-weight: bold;
  margin: 0;
  color: #2c3e50;
}

.status-badge {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: bold;
}

.status-low-stock {
  background: #ffebee;
  color: #c62828;
}

.status-normal {
  background: #e8f5e9;
  color: #2e7d32;
}

.status-overstock {
  background: #fff3e0;
  color: #e65100;
}

.status-expired,
.status-critical {
  background: #c62828;
  color: white;
}

.status-high {
  background: #f57c00;
  color: white;
}

.status-medium {
  background: #fbc02d;
  color: #333;
}

.status-low {
  background: #7cb342;
  color: white;
}

.status-order_made,
.status-processing {
  background: #2196f3;
  color: white;
}

.status-ready_for_dispatch {
  background: #ff9800;
  color: white;
}

.status-dispatched {
  background: #9c27b0;
  color: white;
}

.status-delivered,
.status-completed {
  background: #4caf50;
  color: white;
}

.no-data {
  text-align: center;
  padding: 40px;
  color: #95a5a6;
  font-size: 16px;
}

.loading {
  text-align: center;
  padding: 40px;
  color: #3498db;
  font-size: 16px;
}
</style>
