<template>
  <div class="container">
    <h1>User Management</h1>
    
    <div class="card">
      <h3>Add New User</h3>
      <form @submit.prevent="addUser">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div class="form-group">
            <label>Username *</label>
            <input v-model="newUser.username" required />
          </div>
          <div class="form-group">
            <label>Full Name *</label>
            <input v-model="newUser.fullName" required />
          </div>
          <div class="form-group">
            <label>Password *</label>
            <input v-model="newUser.password" type="password" required minlength="6" />
          </div>
          <div class="form-group">
            <label>Role *</label>
            <select v-model="newUser.roleId" required>
              <option value="">Select Role</option>
              <option v-for="role in roles" :key="role.role_id" :value="role.role_id">
                {{ role.role_name }}
              </option>
            </select>
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Add User</button>
      </form>
    </div>

    <div class="card" style="margin-top: 20px;">
      <h3>All Users</h3>
      <table class="table">
        <thead>
          <tr>
            <th>Username</th>
            <th>Full Name</th>
            <th>Role</th>
            <th>Status</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in users" :key="user.user_id">
            <td>{{ user.username }}</td>
            <td>{{ user.full_name }}</td>
            <td>
              <span :style="{
                padding: '4px 8px',
                borderRadius: '4px',
                fontSize: '12px',
                backgroundColor: getRoleColor(user.role_name),
                color: 'white'
              }">
                {{ user.role_name }}
              </span>
            </td>
            <td>
              <span :style="{
                padding: '4px 8px',
                borderRadius: '4px',
                fontSize: '12px',
                backgroundColor: user.status === 'active' ? '#27ae60' : '#e74c3c',
                color: 'white'
              }">
                {{ user.status }}
              </span>
            </td>
            <td>{{ new Date(user.created_at).toLocaleDateString() }}</td>
            <td>
              <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                <button @click="openEditModal(user)" class="action-btn edit-btn" title="Edit user details">
                  <span class="icon">✏️</span>
                  <span class="text">Edit</span>
                </button>
                <button @click="toggleStatus(user)" 
                        :class="['action-btn', user.status === 'active' ? 'deactivate-btn' : 'activate-btn']"
                        :title="user.status === 'active' ? 'Deactivate user' : 'Activate user'">
                  <span class="icon">{{ user.status === 'active' ? '🔒' : '✅' }}</span>
                  <span class="text">{{ user.status === 'active' ? 'Deactivate' : 'Activate' }}</span>
                </button>
                <button @click="openPasswordModal(user)" class="action-btn password-btn" title="Reset password">
                  <span class="icon">🔑</span>
                  <span class="text">Reset</span>
                </button>
                <button @click="deleteUser(user)" class="action-btn delete-btn" title="Delete user">
                  <span class="icon">🗑️</span>
                  <span class="text">Delete</span>
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="card" style="margin-top: 20px;">
      <h3>Role Privileges</h3>
      <table class="table">
        <thead>
          <tr>
            <th>Role</th>
            <th>Permissions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Admin</strong></td>
            <td>Full system access, user management, all reports, settings</td>
          </tr>
          <tr>
            <td><strong>Pharmacist</strong></td>
            <td>Prescriptions, sales, stock view, medicine management</td>
          </tr>
          <tr>
            <td><strong>Cashier</strong></td>
            <td>Sales, returns, customer management</td>
          </tr>
          <tr>
            <td><strong>Storekeeper</strong></td>
            <td>Purchases, stock management, inventory</td>
          </tr>
          <tr>
            <td><strong>Manager</strong></td>
            <td>Read-only access to all reports and analytics</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Edit User Modal -->
    <div v-if="showEditModal" class="modal-overlay" @click="closeEditModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>✏️ Edit User</h3>
          <button @click="closeEditModal" class="close-btn">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Username</label>
            <input v-model="editingUser.username" disabled style="background: #f5f5f5; cursor: not-allowed;" />
          </div>
          <div class="form-group">
            <label>Full Name</label>
            <input v-model="editingUser.fullName" />
          </div>
          <div class="form-group">
            <label>Role</label>
            <select v-model="editingUser.roleId">
              <option v-for="role in roles" :key="role.role_id" :value="role.role_id">
                {{ role.role_name }}
              </option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button @click="saveUserEdit" class="btn btn-primary">💾 Save Changes</button>
          <button @click="closeEditModal" class="btn" style="background: #95a5a6; color: white;">Cancel</button>
        </div>
      </div>
    </div>

    <!-- Reset Password Modal -->
    <div v-if="showPasswordModal" class="modal-overlay" @click="closePasswordModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>🔑 Reset Password</h3>
          <button @click="closePasswordModal" class="close-btn">✕</button>
        </div>
        <div class="modal-body">
          <p style="margin-bottom: 15px; color: #7f8c8d;">
            Reset password for: <strong>{{ selectedUser?.username }}</strong>
          </p>
          <div class="form-group">
            <label>New Password</label>
            <input v-model="newPassword" type="password" placeholder="Minimum 6 characters" minlength="6" />
          </div>
          <div class="form-group">
            <label>Confirm Password</label>
            <input v-model="confirmPassword" type="password" placeholder="Re-enter password" />
          </div>
          <p v-if="passwordError" style="color: #e74c3c; font-size: 14px; margin-top: 10px;">
            {{ passwordError }}
          </p>
        </div>
        <div class="modal-footer">
          <button @click="confirmResetPassword" class="btn btn-primary">🔑 Reset Password</button>
          <button @click="closePasswordModal" class="btn" style="background: #95a5a6; color: white;">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../api'

export default {
  data() {
    return {
      users: [],
      roles: [],
      newUser: {
        username: '',
        fullName: '',
        password: '',
        roleId: ''
      },
      showEditModal: false,
      showPasswordModal: false,
      editingUser: null,
      selectedUser: null,
      newPassword: '',
      confirmPassword: '',
      passwordError: ''
    }
  },
  async mounted() {
    await this.loadUsers()
    await this.loadRoles()
  },
  methods: {
    async loadUsers() {
      try {
        const { data } = await api.get('/users')
        this.users = data
      } catch (err) {
        console.error(err)
        alert('Failed to load users')
      }
    },
    async loadRoles() {
      try {
        const { data } = await api.get('/users/roles')
        this.roles = data
      } catch (err) {
        console.error(err)
      }
    },
    async addUser() {
      try {
        await api.post('/users', this.newUser)
        alert('User created successfully!')
        this.newUser = { username: '', fullName: '', password: '', roleId: '' }
        await this.loadUsers()
      } catch (err) {
        alert(err.response?.data?.error || 'Failed to create user')
      }
    },
    async toggleStatus(user) {
      const newStatus = user.status === 'active' ? 'inactive' : 'active'
      const action = newStatus === 'active' ? 'activate' : 'deactivate'
      
      if (!confirm(`Are you sure you want to ${action} user "${user.username}"?`)) {
        return
      }
      
      try {
        await api.patch(`/users/${user.user_id}/status`, { status: newStatus })
        alert(`User ${newStatus === 'active' ? 'activated' : 'deactivated'} successfully`)
        await this.loadUsers()
      } catch (err) {
        alert('Failed to update user status')
      }
    },
    openEditModal(user) {
      this.editingUser = {
        userId: user.user_id,
        username: user.username,
        fullName: user.full_name,
        roleId: user.role_id
      }
      this.showEditModal = true
    },
    closeEditModal() {
      this.showEditModal = false
      this.editingUser = null
    },
    async saveUserEdit() {
      try {
        await api.patch(`/users/${this.editingUser.userId}/role`, { 
          roleId: this.editingUser.roleId 
        })
        alert('User updated successfully!')
        this.closeEditModal()
        await this.loadUsers()
      } catch (err) {
        alert('Failed to update user')
      }
    },
    openPasswordModal(user) {
      this.selectedUser = user
      this.newPassword = ''
      this.confirmPassword = ''
      this.passwordError = ''
      this.showPasswordModal = true
    },
    closePasswordModal() {
      this.showPasswordModal = false
      this.selectedUser = null
      this.newPassword = ''
      this.confirmPassword = ''
      this.passwordError = ''
    },
    async confirmResetPassword() {
      this.passwordError = ''
      
      if (!this.newPassword || this.newPassword.length < 6) {
        this.passwordError = 'Password must be at least 6 characters'
        return
      }
      
      if (this.newPassword !== this.confirmPassword) {
        this.passwordError = 'Passwords do not match'
        return
      }
      
      try {
        await api.patch(`/users/${this.selectedUser.user_id}/password`, { 
          newPassword: this.newPassword 
        })
        alert('Password reset successfully!')
        this.closePasswordModal()
      } catch (err) {
        this.passwordError = 'Failed to reset password'
      }
    },
    async deleteUser(user) {
      if (!confirm(`Are you sure you want to delete user "${user.username}"? This action cannot be undone.`)) {
        return
      }
      
      try {
        await api.delete(`/users/${user.user_id}`)
        alert('User deleted successfully')
        await this.loadUsers()
      } catch (err) {
        alert('Failed to delete user')
      }
    },
    getRoleColor(role) {
      const colors = {
        'Admin': '#e74c3c',
        'Pharmacist': '#3498db',
        'Cashier': '#27ae60',
        'Storekeeper': '#f39c12',
        'Manager': '#9b59b6'
      }
      return colors[role] || '#95a5a6'
    }
  }
}
</script>

<style scoped>
.action-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 8px 12px;
  border: none;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  white-space: nowrap;
}

.action-btn .icon {
  font-size: 14px;
}

.action-btn .text {
  display: inline;
}

.action-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.edit-btn {
  background: linear-gradient(135deg, #3498db, #2980b9);
  color: white;
}

.edit-btn:hover {
  background: linear-gradient(135deg, #2980b9, #21618c);
}

.activate-btn {
  background: linear-gradient(135deg, #27ae60, #229954);
  color: white;
}

.activate-btn:hover {
  background: linear-gradient(135deg, #229954, #1e8449);
}

.deactivate-btn {
  background: linear-gradient(135deg, #e74c3c, #c0392b);
  color: white;
}

.deactivate-btn:hover {
  background: linear-gradient(135deg, #c0392b, #a93226);
}

.password-btn {
  background: linear-gradient(135deg, #f39c12, #e67e22);
  color: white;
}

.password-btn:hover {
  background: linear-gradient(135deg, #e67e22, #d35400);
}

.delete-btn {
  background: linear-gradient(135deg, #c0392b, #922b21);
  color: white;
}

.delete-btn:hover {
  background: linear-gradient(135deg, #922b21, #7b241c);
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.modal-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 10px 40px rgba(0,0,0,0.3);
  animation: slideUp 0.3s ease;
}

@keyframes slideUp {
  from {
    transform: translateY(50px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 25px;
  border-bottom: 2px solid #ecf0f1;
}

.modal-header h3 {
  margin: 0;
  color: #2c3e50;
  font-size: 20px;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  color: #95a5a6;
  cursor: pointer;
  padding: 0;
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: all 0.3s;
}

.close-btn:hover {
  background: #ecf0f1;
  color: #2c3e50;
}

.modal-body {
  padding: 25px;
}

.modal-footer {
  padding: 20px 25px;
  border-top: 2px solid #ecf0f1;
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}

.modal-footer .btn {
  padding: 10px 20px;
  border-radius: 6px;
  font-weight: 600;
}

@media (max-width: 768px) {
  .action-btn .text {
    display: none;
  }
  
  .action-btn {
    padding: 8px;
  }
}
</style>
