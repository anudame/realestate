<template>
  <div class="container" style="padding: 3rem 0;">
    <h1>About Us</h1>
    <div class="info-section" style="margin-top: 2rem;">
      <h2>Who We Are</h2>
      <p>We are Ethiopia's leading real estate platform, connecting property buyers, sellers, and renters across the country.</p>
      
      <h2 style="margin-top: 2rem;">Our Mission</h2>
      <p>To make property transactions simple, transparent, and accessible for everyone in Ethiopia.</p>
      
      <h2 style="margin-top: 2rem;">Our Services</h2>
      <ul style="line-height: 2;">
        <li>Property Buying</li>
        <li>Property Selling</li>
        <li>Property Renting</li>
        <li>Property Management</li>
        <li>Real Estate Consultation</li>
      </ul>
    </div>
  </div>
</template>
