<template>
  <div class="container" style="padding: 3rem 0;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
      <h1>Manage Properties</h1>
      <button class="btn btn-primary" @click="showAddForm = true">
        <i class="fas fa-plus"></i> Add New Property
      </button>
    </div>

    <!-- Add/Edit Property Form -->
    <div v-if="showAddForm" class="info-section" style="margin-bottom: 2rem;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
        <h2>{{ editingProperty ? 'Edit Property' : 'Add New Property' }}</h2>
        <button class="btn btn-outline" @click="cancelForm">Cancel</button>
      </div>

      <form @submit.prevent="saveProperty">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
          <div class="form-group">
            <label>Title *</label>
            <input v-model="form.title" type="text" required>
          </div>

          <div class="form-group">
            <label>Price (ETB) *</label>
            <input v-model="form.price" type="number" required>
          </div>

          <div class="form-group">
            <label>Property Type *</label>
            <select v-model="form.property_type" required>
              <option value="apartment">Apartment</option>
              <option value="villa">Villa</option>
              <option value="house">House</option>
              <option value="commercial">Commercial</option>
              <option value="land">Land</option>
            </select>
          </div>

          <div class="form-group">
            <label>Listing Type *</label>
            <select v-model="form.listing_type" required>
              <option value="sale">For Sale</option>
              <option value="rent">For Rent</option>
              <option value="lease">For Lease</option>
            </select>
          </div>

          <div class="form-group">
            <label>City *</label>
            <select v-model="form.city_id" required>
              <option value="">Select City</option>
              <option v-for="city in cities" :key="city.city_id" :value="city.city_id">
                {{ city.name }}
              </option>
            </select>
          </div>

          <div class="form-group">
            <label>Category</label>
            <select v-model="form.category_id">
              <option value="">Select Category</option>
              <option v-for="cat in categories" :key="cat.category_id" :value="cat.category_id">
                {{ cat.name }}
              </option>
            </select>
          </div>

          <div class="form-group">
            <label>Size (m²)</label>
            <input v-model="form.size" type="number" step="0.01">
          </div>

          <div class="form-group">
            <label>Bedrooms</label>
            <input v-model="form.bedrooms" type="number">
          </div>

          <div class="form-group">
            <label>Bathrooms</label>
            <input v-model="form.bathrooms" type="number">
          </div>

          <div class="form-group">
            <label>Parking Available</label>
            <select v-model="form.parking">
              <option :value="0">No</option>
              <option :value="1">Yes</option>
            </select>
          </div>

          <div class="form-group">
            <label>Floor Number</label>
            <input v-model="form.floor_number" type="number">
          </div>

          <div class="form-group">
            <label>Year Built</label>
            <input v-model="form.year_built" type="number" min="1900" :max="new Date().getFullYear()">
          </div>

          <div class="form-group">
            <label>Status</label>
            <select v-model="form.status">
              <option value="available">Available</option>
              <option value="sold">Sold</option>
              <option value="rented">Rented</option>
              <option value="reserved">Reserved</option>
            </select>
          </div>

          <div class="form-group">
            <label>
              <input type="checkbox" v-model="form.is_featured">
              Featured Property
            </label>
          </div>
        </div>

        <div class="form-group">
          <label>Address *</label>
          <input v-model="form.address" type="text" required>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
          <div class="form-group">
            <label>Latitude</label>
            <input v-model="form.latitude" type="number" step="0.000001">
          </div>

          <div class="form-group">
            <label>Longitude</label>
            <input v-model="form.longitude" type="number" step="0.000001">
          </div>
        </div>

        <div class="form-group">
          <label>Description *</label>
          <textarea v-model="form.description" rows="5" required></textarea>
        </div>

        <div class="form-group">
          <label>Amenities</label>
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem;">
            <label v-for="amenity in amenities" :key="amenity.amenity_id" style="display: flex; align-items: center; gap: 0.5rem;">
              <input type="checkbox" :value="amenity.amenity_id" v-model="form.amenities">
              {{ amenity.name }}
            </label>
          </div>
        </div>

        <!-- Media Upload Section -->
        <div style="margin-top: 2rem; padding-top: 2rem; border-top: 2px solid var(--border);">
          <h3>Property Media</h3>
          
          <!-- Images -->
          <div class="form-group">
            <label>Images (All formats supported)</label>
            <input 
              type="file" 
              @change="handleImageSelect" 
              multiple 
              accept="image/*"
              ref="imageInput"
            >
            <p style="font-size: 0.875rem; color: var(--text-light); margin-top: 0.5rem;">
              Select up to 10 images (JPG, PNG, GIF, WebP, BMP, SVG, TIFF - max 10MB each)
            </p>
            <div v-if="selectedImages.length > 0" style="margin-top: 0.5rem;">
              <strong>Selected: {{ selectedImages.length }} image(s)</strong>
              <ul style="font-size: 0.875rem; color: var(--text-light); margin-top: 0.25rem;">
                <li v-for="(file, index) in selectedImages" :key="index">
                  {{ file.name }} ({{ formatFileSize(file.size) }})
                </li>
              </ul>
            </div>
          </div>

          <!-- Videos -->
          <div class="form-group">
            <label>Videos (All formats supported)</label>
            <input 
              type="file" 
              @change="handleVideoSelect" 
              multiple 
              accept="video/*"
              ref="videoInput"
            >
            <p style="font-size: 0.875rem; color: var(--text-light); margin-top: 0.5rem;">
              Select up to 3 videos (MP4, AVI, MOV, WMV, FLV, MKV, WebM, MPEG - max 100MB each)
            </p>
            <div v-if="selectedVideos.length > 0" style="margin-top: 0.5rem;">
              <strong>Selected: {{ selectedVideos.length }} video(s)</strong>
              <ul style="font-size: 0.875rem; color: var(--text-light); margin-top: 0.25rem;">
                <li v-for="(file, index) in selectedVideos" :key="index">
                  {{ file.name }} ({{ formatFileSize(file.size) }})
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div v-if="error" class="alert alert-error">{{ error }}</div>
        <div v-if="successMessage" class="alert alert-success">{{ successMessage }}</div>
        <div v-if="uploadSuccess" class="alert alert-success">{{ uploadSuccess }}</div>

        <button type="submit" class="btn btn-primary" :disabled="saving">
          {{ saving ? 'Saving...' : (editingProperty ? 'Update Property' : 'Save Property & Upload Media') }}
        </button>
      </form>
    </div>

    <!-- Properties List -->
    <div v-if="loading" class="loading">
      <div class="spinner"></div>
      <p>Loading properties...</p>
    </div>

    <div v-else class="info-section">
      <h2>Your Properties</h2>
      
      <div v-if="properties.length === 0" style="text-align: center; padding: 2rem; color: var(--text-light);">
        <p>No properties yet. Add your first property!</p>
      </div>

      <table v-else style="width: 100%; margin-top: 1rem;">
        <thead>
          <tr style="border-bottom: 2px solid var(--border);">
            <th style="padding: 0.75rem; text-align: left;">Title</th>
            <th style="padding: 0.75rem; text-align: left;">Type</th>
            <th style="padding: 0.75rem; text-align: left;">Price</th>
            <th style="padding: 0.75rem; text-align: left;">Status</th>
            <th style="padding: 0.75rem; text-align: left;">Views</th>
            <th style="padding: 0.75rem; text-align: left;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="property in properties" :key="property.property_id" style="border-bottom: 1px solid var(--border);">
            <td style="padding: 0.75rem;">
              <strong>{{ property.title }}</strong>
              <br>
              <small style="color: var(--text-light);">{{ property.city_name }}</small>
            </td>
            <td style="padding: 0.75rem;">{{ property.property_type }}</td>
            <td style="padding: 0.75rem;">{{ formatPrice(property.price) }} ETB</td>
            <td style="padding: 0.75rem;">
              <span :style="{ 
                color: property.status === 'available' ? 'var(--secondary)' : 'var(--warning)',
                fontWeight: '500'
              }">
                {{ property.status }}
              </span>
            </td>
            <td style="padding: 0.75rem;">{{ property.views }}</td>
            <td style="padding: 0.75rem;">
              <button class="btn btn-outline" style="padding: 0.5rem 1rem; margin-right: 0.5rem;" @click="editProperty(property)">
                <i class="fas fa-edit"></i>
              </button>
              <button class="btn" style="padding: 0.5rem 1rem; background: var(--danger); color: white;" @click="deleteProperty(property.property_id)">
                <i class="fas fa-trash"></i>
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
import { useDialog } from '../composables/useDialog'

const { confirm, success, error: showError, alert: showAlert } = useDialog()

const loading = ref(true)
const saving = ref(false)
const uploading = ref(false)
const showAddForm = ref(false)
const editingProperty = ref(null)
const properties = ref([])
const cities = ref([])
const categories = ref([])
const amenities = ref([])
const error = ref('')
const successMessage = ref('')
const uploadSuccess = ref('')
const selectedImages = ref([])
const selectedVideos = ref([])
const imageInput = ref(null)
const videoInput = ref(null)

const form = ref({
  title: '',
  description: '',
  property_type: 'apartment',
  listing_type: 'sale',
  price: '',
  size: '',
  bedrooms: '',
  bathrooms: '',
  parking: 0,
  floor_number: '',
  year_built: '',
  city_id: '',
  address: '',
  latitude: '',
  longitude: '',
  category_id: '',
  status: 'available',
  is_featured: false,
  amenities: []
})

onMounted(async () => {
  await Promise.all([
    loadProperties(),
    loadCities(),
    loadCategories(),
    loadAmenities()
  ])
  loading.value = false
})

const loadProperties = async () => {
  try {
    const response = await api.getProperties({ limit: 100 })
    properties.value = response.data.properties
  } catch (err) {
    console.error('Error loading properties:', err)
  }
}

const loadCities = async () => {
  const response = await api.getCities()
  cities.value = response.data
}

const loadCategories = async () => {
  const response = await api.getCategories()
  categories.value = response.data
}

const loadAmenities = async () => {
  const response = await api.getAmenities()
  amenities.value = response.data
}

const saveProperty = async () => {
  saving.value = true
  error.value = ''
  successMessage.value = ''
  uploadSuccess.value = ''

  try {
    let propertyId;
    
    if (editingProperty.value) {
      await api.updateProperty(editingProperty.value.property_id, form.value)
      propertyId = editingProperty.value.property_id
      successMessage.value = 'Property updated successfully!'
    } else {
      const response = await api.createProperty(form.value)
      propertyId = response.data.property_id
      successMessage.value = 'Property created successfully!'
    }
    
    // Upload images if selected
    if (selectedImages.value.length > 0) {
      try {
        const formData = new FormData()
        selectedImages.value.forEach(file => {
          formData.append('images', file)
        })
        formData.append('is_primary', 'true')
        
        await api.uploadImages(propertyId, formData)
        uploadSuccess.value = `${selectedImages.value.length} image(s) uploaded successfully!`
      } catch (err) {
        error.value = 'Property saved but image upload failed: ' + (err.response?.data?.error || 'Unknown error')
      }
    }
    
    // Upload videos if selected
    if (selectedVideos.value.length > 0) {
      uploadSuccess.value += ` ${selectedVideos.value.length} video(s) uploaded successfully!`
      // Note: Video upload endpoint would need to be implemented on backend
    }
    
    await loadProperties()
    
    if (!editingProperty.value) {
      setTimeout(() => {
        showAddForm.value = false
        resetForm()
      }, 3000)
    }
  } catch (err) {
    error.value = err.response?.data?.error || 'Error saving property'
  } finally {
    saving.value = false
  }
}

const editProperty = (property) => {
  editingProperty.value = property
  form.value = {
    title: property.title,
    description: property.description,
    property_type: property.property_type,
    listing_type: property.listing_type,
    price: property.price,
    size: property.size,
    bedrooms: property.bedrooms,
    bathrooms: property.bathrooms,
    parking: property.parking,
    floor_number: property.floor_number,
    year_built: property.year_built,
    city_id: property.city_id,
    address: property.address,
    latitude: property.latitude,
    longitude: property.longitude,
    category_id: property.category_id,
    status: property.status,
    is_featured: property.is_featured,
    amenities: []
  }
  showAddForm.value = true
  window.scrollTo(0, 0)
}

const deleteProperty = async (id) => {
  const confirmed = await confirm(
    'Are you sure you want to delete this property? This action cannot be undone.',
    'Delete Property'
  )
  
  if (!confirmed) return
  
  try {
    await api.deleteProperty(id)
    await success('Property deleted successfully!')
    await loadProperties()
  } catch (err) {
    await showError('Failed to delete property. Please try again.')
  }
}

const cancelForm = () => {
  showAddForm.value = false
  resetForm()
}

const resetForm = () => {
  editingProperty.value = null
  form.value = {
    title: '',
    description: '',
    property_type: 'apartment',
    listing_type: 'sale',
    price: '',
    size: '',
    bedrooms: '',
    bathrooms: '',
    parking: 0,
    floor_number: '',
    year_built: '',
    city_id: '',
    address: '',
    latitude: '',
    longitude: '',
    category_id: '',
    status: 'available',
    is_featured: false,
    amenities: []
  }
  selectedImages.value = []
  selectedVideos.value = []
  if (imageInput.value) imageInput.value.value = ''
  if (videoInput.value) videoInput.value.value = ''
  error.value = ''
  successMessage.value = ''
  uploadSuccess.value = ''
}

const handleImageSelect = async (event) => {
  const files = Array.from(event.target.files)
  if (files.length > 10) {
    await showAlert('Maximum 10 images allowed. Only the first 10 will be selected.', 'Image Limit')
    selectedImages.value = files.slice(0, 10)
  } else {
    selectedImages.value = files
  }
}

const handleVideoSelect = async (event) => {
  const files = Array.from(event.target.files)
  if (files.length > 3) {
    await showAlert('Maximum 3 videos allowed. Only the first 3 will be selected.', 'Video Limit')
    selectedVideos.value = files.slice(0, 3)
  } else {
    selectedVideos.value = files
  }
}

const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
}

const formatPrice = (price) => {
  return new Intl.NumberFormat('en-US').format(price)
}
</script>
