<template>
  <div class="container" style="padding: 3rem 0;">
    <h1 style="margin-bottom: 2rem;">📧 Inquiries Management</h1>

    <!-- Filters -->
    <div class="info-section" style="margin-bottom: 2rem;">
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
        <div class="form-group">
          <label>Status</label>
          <select v-model="filters.status" @change="loadInquiries">
            <option value="">All Status</option>
            <option value="pending">Pending</option>
            <option value="responded">Responded</option>
            <option value="closed">Closed</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search</label>
          <input v-model="filters.search" type="text" placeholder="Name, email, phone..." @input="debounceSearch">
        </div>
      </div>
    </div>

    <!-- Stats Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
      <div class="stat-card" style="background: #fff3cd; border-left: 4px solid #ffc107;">
        <div class="stat-value">{{ stats.pending }}</div>
        <div class="stat-label">Pending</div>
      </div>
      <div class="stat-card" style="background: #d1ecf1; border-left: 4px solid #17a2b8;">
        <div class="stat-value">{{ stats.responded }}</div>
        <div class="stat-label">Responded</div>
      </div>
      <div class="stat-card" style="background: #d4edda; border-left: 4px solid #28a745;">
        <div class="stat-value">{{ stats.closed }}</div>
        <div class="stat-label">Closed</div>
      </div>
    </div>

    <!-- Loading -->
    <div v-if="loading" class="loading">
      <div class="spinner"></div>
      <p>Loading inquiries...</p>
    </div>

    <!-- Error -->
    <div v-else-if="error" class="alert alert-error">
      {{ error }}
    </div>

    <!-- Inquiries Table -->
    <div v-else class="info-section">
      <div v-if="inquiries.length === 0" style="text-align: center; padding: 2rem;">
        <i class="fas fa-inbox" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
        <p>No inquiries found</p>
      </div>

      <div v-else class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Property</th>
              <th>Customer</th>
              <th>Contact</th>
              <th>Message</th>
              <th>Status</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="inquiry in inquiries" :key="inquiry.inquiry_id">
              <td>#{{ inquiry.inquiry_id }}</td>
              <td>
                <div style="font-weight: 500;">{{ inquiry.property_title }}</div>
              </td>
              <td>{{ inquiry.name }}</td>
              <td>
                <div>📧 {{ inquiry.email }}</div>
                <div>📱 {{ inquiry.phone }}</div>
              </td>
              <td>
                <div style="max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                  {{ inquiry.message }}
                </div>
              </td>
              <td>
                <span :class="['badge', `badge-${inquiry.status}`]">
                  {{ inquiry.status }}
                </span>
              </td>
              <td>{{ formatDateTime(inquiry.created_at) }}</td>
              <td>
                <div class="action-buttons">
                  <button 
                    class="btn-icon" 
                    title="View Details"
                    @click="viewInquiry(inquiry)"
                  >
                    <i class="fas fa-eye"></i>
                  </button>
                  <button 
                    v-if="inquiry.status === 'pending'"
                    class="btn-icon btn-success" 
                    title="Mark as Responded"
                    @click="updateStatus(inquiry.inquiry_id, 'responded')"
                  >
                    <i class="fas fa-check"></i>
                  </button>
                  <button 
                    v-if="inquiry.status !== 'closed'"
                    class="btn-icon btn-danger" 
                    title="Close"
                    @click="updateStatus(inquiry.inquiry_id, 'closed')"
                  >
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div v-if="pagination.pages > 1" class="pagination">
        <button 
          @click="changePage(pagination.page - 1)" 
          :disabled="pagination.page === 1"
          class="btn btn-outline"
        >
          Previous
        </button>
        <span>Page {{ pagination.page }} of {{ pagination.pages }}</span>
        <button 
          @click="changePage(pagination.page + 1)" 
          :disabled="pagination.page === pagination.pages"
          class="btn btn-outline"
        >
          Next
        </button>
      </div>
    </div>

    <!-- Inquiry Details Modal -->
    <div v-if="selectedInquiry" class="modal" @click.self="selectedInquiry = null">
      <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
          <h2>Inquiry Details #{{ selectedInquiry.inquiry_id }}</h2>
          <button class="btn-close" @click="selectedInquiry = null">×</button>
        </div>
        <div class="modal-body">
          <div class="detail-section">
            <h3>Customer Information</h3>
            <div class="detail-row">
              <span class="detail-label">Name:</span>
              <span>{{ selectedInquiry.name }}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Email:</span>
              <span>{{ selectedInquiry.email }}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Phone:</span>
              <span>{{ selectedInquiry.phone }}</span>
            </div>
          </div>

          <div class="detail-section">
            <h3>Property Information</h3>
            <div class="detail-row">
              <span class="detail-label">Property:</span>
              <span>{{ selectedInquiry.property_title }}</span>
            </div>
          </div>

          <div class="detail-section">
            <h3>Message</h3>
            <p style="line-height: 1.6;">{{ selectedInquiry.message }}</p>
          </div>

          <div class="detail-section">
            <h3>Status</h3>
            <div class="detail-row">
              <span class="detail-label">Current Status:</span>
              <span :class="['badge', `badge-${selectedInquiry.status}`]">
                {{ selectedInquiry.status }}
              </span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Received:</span>
              <span>{{ formatDateTime(selectedInquiry.created_at) }}</span>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline" @click="selectedInquiry = null">Close</button>
          <a :href="`mailto:${selectedInquiry.email}`" class="btn btn-primary">
            <i class="fas fa-envelope"></i> Reply via Email
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'
import { useDialog } from '../composables/useDialog'

const { confirm, success, error: showError } = useDialog()

const loading = ref(true)
const error = ref('')
const inquiries = ref([])
const selectedInquiry = ref(null)
const stats = ref({
  pending: 0,
  responded: 0,
  closed: 0
})

const filters = ref({
  status: '',
  search: ''
})

const pagination = ref({
  page: 1,
  limit: 20,
  total: 0,
  pages: 1
})

let searchTimeout = null

onMounted(() => {
  loadInquiries()
})

const loadInquiries = async () => {
  try {
    loading.value = true
    error.value = ''
    
    const params = {
      page: pagination.value.page,
      limit: pagination.value.limit,
      ...filters.value
    }

    const response = await api.getInquiries(params)
    inquiries.value = response.data.inquiries || response.data
    
    if (response.data.pagination) {
      pagination.value = response.data.pagination
    }
    
    if (response.data.stats) {
      stats.value = response.data.stats
    }
  } catch (err) {
    console.error('Error loading inquiries:', err)
    error.value = 'Failed to load inquiries'
  } finally {
    loading.value = false
  }
}

const debounceSearch = () => {
  clearTimeout(searchTimeout)
  searchTimeout = setTimeout(() => {
    loadInquiries()
  }, 500)
}

const changePage = (page) => {
  pagination.value.page = page
  loadInquiries()
}

const updateStatus = async (inquiryId, status) => {
  const confirmed = await confirm(
    `Are you sure you want to mark this inquiry as ${status}?`,
    'Confirm Action'
  )
  
  if (!confirmed) return

  try {
    await api.updateInquiry(inquiryId, { status })
    await success(`Inquiry marked as ${status} successfully!`)
    await loadInquiries()
  } catch (err) {
    console.error('Error updating inquiry:', err)
    await showError('Failed to update inquiry status. Please try again.')
  }
}

const viewInquiry = (inquiry) => {
  selectedInquiry.value = inquiry
}

const formatDateTime = (date) => {
  return new Date(date).toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}
</script>

<style scoped>
.stat-card {
  padding: 1.5rem;
  border-radius: 8px;
  text-align: center;
}

.stat-value {
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
}

.stat-label {
  color: #666;
  font-size: 0.9rem;
}

.table-responsive {
  overflow-x: auto;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
}

.data-table th,
.data-table td {
  padding: 1rem;
  text-align: left;
  border-bottom: 1px solid #eee;
}

.data-table th {
  background: #f8f9fa;
  font-weight: 600;
  color: #333;
}

.data-table tbody tr:hover {
  background: #f8f9fa;
}

.badge {
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.85rem;
  font-weight: 500;
  text-transform: capitalize;
}

.badge-pending {
  background: #fff3cd;
  color: #856404;
}

.badge-responded {
  background: #d1ecf1;
  color: #0c5460;
}

.badge-closed {
  background: #d4edda;
  color: #155724;
}

.action-buttons {
  display: flex;
  gap: 0.5rem;
}

.btn-icon {
  padding: 0.5rem;
  border: none;
  background: #007bff;
  color: white;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-icon:hover {
  opacity: 0.8;
}

.btn-icon.btn-success {
  background: #28a745;
}

.btn-icon.btn-danger {
  background: #dc3545;
}

.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1rem;
  margin-top: 2rem;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 8px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  border-bottom: 1px solid #eee;
}

.modal-header h2 {
  margin: 0;
}

.btn-close {
  background: none;
  border: none;
  font-size: 2rem;
  cursor: pointer;
  color: #999;
}

.btn-close:hover {
  color: #333;
}

.modal-body {
  padding: 1.5rem;
}

.modal-footer {
  padding: 1.5rem;
  border-top: 1px solid #eee;
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
}

.detail-section {
  margin-bottom: 2rem;
}

.detail-section h3 {
  margin-bottom: 1rem;
  color: #333;
  font-size: 1.1rem;
}

.detail-row {
  display: flex;
  padding: 0.75rem 0;
  border-bottom: 1px solid #f0f0f0;
}

.detail-label {
  font-weight: 600;
  width: 150px;
  color: #666;
}
</style>
