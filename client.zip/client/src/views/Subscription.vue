<template>
  <div class="container">
    <h1>💳 Subscription Management</h1>

    <!-- Current Subscription -->
    <div class="card" v-if="subscription">
      <div style="display: flex; justify-content: space-between; align-items: start;">
        <div>
          <h2>{{ subscription.plan_name }}</h2>
          <p style="color: #7f8c8d;">{{ subscription.tenant_name }}</p>
        </div>
        <span :style="{
          padding: '8px 16px',
          borderRadius: '20px',
          fontSize: '14px',
          fontWeight: 'bold',
          backgroundColor: getStatusColor(subscription.status),
          color: 'white'
        }">
          {{ subscription.status.toUpperCase() }}
        </span>
      </div>

      <!-- Trial Info -->
      <div v-if="subscription.status === 'trial'" style="margin-top: 20px; padding: 20px; background: #fff3cd; border-radius: 8px;">
        <h3 style="margin: 0 0 10px 0; color: #856404;">⏰ Trial Period</h3>
        <p style="margin: 0; color: #856404;">
          <strong>{{ subscription.trial_days_remaining }}</strong> days remaining in your free trial
        </p>
        <p style="margin: 10px 0 0 0; color: #856404; font-size: 14px;">
          Trial ends on: {{ formatDate(subscription.trial_end_date) }}
        </p>
      </div>

      <!-- Active Subscription Info -->
      <div v-if="subscription.status === 'active'" style="margin-top: 20px; padding: 20px; background: #d4edda; border-radius: 8px;">
        <h3 style="margin: 0 0 10px 0; color: #155724;">✅ Active Subscription</h3>
        <p style="margin: 0; color: #155724;">
          Next billing date: <strong>{{ formatDate(subscription.next_billing_date) }}</strong>
        </p>
        <p style="margin: 10px 0 0 0; color: #155724;">
          Amount: <strong>ETB {{ subscription.price }}</strong> / {{ subscription.billing_cycle }}
        </p>
      </div>

      <!-- Usage Stats -->
      <div style="margin-top: 30px;">
        <h3>📊 Current Usage</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 15px;">
          <div style="padding: 20px; background: #f8f9fa; border-radius: 8px;">
            <p style="margin: 0; color: #7f8c8d; font-size: 14px;">Branches</p>
            <p style="margin: 10px 0 0 0; font-size: 32px; font-weight: bold; color: #2c3e50;">
              {{ subscription.currentUsage.branches }} / {{ subscription.max_branches }}
            </p>
          </div>
          <div style="padding: 20px; background: #f8f9fa; border-radius: 8px;">
            <p style="margin: 0; color: #7f8c8d; font-size: 14px;">Users</p>
            <p style="margin: 10px 0 0 0; font-size: 32px; font-weight: bold; color: #2c3e50;">
              {{ subscription.currentUsage.users }} / {{ subscription.max_users }}
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- Available Plans -->
    <div class="card" style="margin-top: 30px;">
      <h2>📦 Available Plans</h2>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-top: 20px;">
        <div v-for="plan in plans" :key="plan.plan_id" 
             :style="{
               border: '2px solid',
               borderColor: plan.plan_type === 'pro' ? '#667eea' : '#e0e0e0',
               borderRadius: '12px',
               padding: '25px',
               position: 'relative',
               background: plan.plan_type === 'pro' ? '#f8f9ff' : 'white'
             }">
          <span v-if="plan.plan_type === 'pro'" 
                style="position: absolute; top: -12px; right: 20px; background: #667eea; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: bold;">
            POPULAR
          </span>
          
          <h3 style="margin: 0 0 10px 0;">{{ plan.plan_name }}</h3>
          <p style="font-size: 36px; font-weight: bold; margin: 15px 0; color: #2c3e50;">
            ETB {{ plan.price }}
            <span style="font-size: 16px; font-weight: normal; color: #7f8c8d;">
              / {{ plan.billing_cycle }}
            </span>
          </p>

          <ul style="list-style: none; padding: 0; margin: 20px 0;">
            <li style="padding: 8px 0; color: #2c3e50;">✅ {{ plan.max_branches }} Branch{{ plan.max_branches > 1 ? 'es' : '' }}</li>
            <li style="padding: 8px 0; color: #2c3e50;">✅ {{ plan.max_users }} Users</li>
            <li style="padding: 8px 0; color: #2c3e50;">✅ {{ plan.max_storage_gb }}GB Storage</li>
            <li v-if="plan.features.basic_reports" style="padding: 8px 0; color: #2c3e50;">✅ Basic Reports</li>
            <li v-if="plan.features.advanced_reports" style="padding: 8px 0; color: #2c3e50;">✅ Advanced Reports</li>
            <li v-if="plan.features.api_access" style="padding: 8px 0; color: #2c3e50;">✅ API Access</li>
            <li v-if="plan.features.priority_support" style="padding: 8px 0; color: #2c3e50;">✅ Priority Support</li>
          </ul>

          <button v-if="subscription && subscription.plan_id !== plan.plan_id && plan.plan_type !== 'free'" 
                  @click="upgradePlan(plan)" 
                  class="btn btn-primary" 
                  style="width: 100%;">
            {{ plan.price > subscription.price ? 'Upgrade' : 'Switch' }} to {{ plan.plan_name }}
          </button>
          
          <button v-if="subscription && subscription.plan_id === plan.plan_id" 
                  class="btn" 
                  style="width: 100%; background: #27ae60; color: white;" 
                  disabled>
            Current Plan
          </button>
        </div>
      </div>
    </div>

    <!-- Upgrade Modal -->
    <div v-if="showUpgradeModal" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 1000;" @click="showUpgradeModal = false">
      <div class="card" style="max-width: 500px; width: 90%;" @click.stop>
        <h2>Upgrade Subscription</h2>
        <p>Upgrade to <strong>{{ selectedPlan?.plan_name }}</strong></p>
        <p style="font-size: 24px; font-weight: bold; color: #2c3e50; margin: 20px 0;">
          ETB {{ selectedPlan?.price }} / {{ selectedPlan?.billing_cycle }}
        </p>

        <div class="form-group">
          <label>Payment Method</label>
          <select v-model="paymentMethod">
            <option value="mobile">Mobile Money</option>
            <option value="card">Credit/Debit Card</option>
            <option value="bank_transfer">Bank Transfer</option>
          </select>
        </div>

        <div class="form-group" v-if="paymentMethod === 'mobile'">
          <label>Transaction Code</label>
          <input v-model="transactionCode" placeholder="Enter transaction code" />
        </div>

        <div style="display: flex; gap: 10px; margin-top: 20px;">
          <button @click="confirmUpgrade" class="btn btn-primary" style="flex: 1;">
            Confirm Upgrade
          </button>
          <button @click="showUpgradeModal = false" class="btn" style="flex: 1; background: #95a5a6; color: white;">
            Cancel
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../api'

export default {
  data() {
    return {
      subscription: null,
      plans: [],
      showUpgradeModal: false,
      selectedPlan: null,
      paymentMethod: 'mobile',
      transactionCode: ''
    }
  },
  async mounted() {
    await this.loadSubscription()
    await this.loadPlans()
  },
  methods: {
    async loadSubscription() {
      try {
        const { data } = await api.get('/tenant/subscription')
        this.subscription = data
      } catch (err) {
        console.error(err)
      }
    },
    async loadPlans() {
      try {
        const { data } = await api.get('/tenant/plans')
        this.plans = data.map(p => ({
          ...p,
          features: JSON.parse(p.features)
        }))
      } catch (err) {
        console.error(err)
      }
    },
    upgradePlan(plan) {
      this.selectedPlan = plan
      this.showUpgradeModal = true
    },
    async confirmUpgrade() {
      try {
        await api.post('/tenant/upgrade', {
          planId: this.selectedPlan.plan_id,
          paymentMethod: this.paymentMethod,
          transactionCode: this.transactionCode
        })
        
        alert('Subscription upgraded successfully!')
        this.showUpgradeModal = false
        await this.loadSubscription()
      } catch (err) {
        alert(err.response?.data?.error || 'Failed to upgrade subscription')
      }
    },
    getStatusColor(status) {
      const colors = {
        trial: '#f39c12',
        active: '#27ae60',
        past_due: '#e74c3c',
        cancelled: '#95a5a6',
        expired: '#c0392b'
      }
      return colors[status] || '#95a5a6'
    },
    formatDate(dateString) {
      return new Date(dateString).toLocaleDateString()
    }
  }
}
</script>
