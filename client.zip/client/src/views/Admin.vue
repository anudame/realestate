<template>
  <div class="container" style="padding: 3rem 0;">
    <h1>Admin Dashboard</h1>
    
    <div v-if="loading" class="loading">
      <div class="spinner"></div>
      <p>Loading...</p>
    </div>

    <div v-else>
      <!-- Stats -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 2rem 0;">
        <div class="info-section" style="text-align: center;">
          <h3>{{ stats.total_properties }}</h3>
          <p>Total Properties</p>
        </div>
        <div class="info-section" style="text-align: center;">
          <h3>{{ stats.available_properties }}</h3>
          <p>Available</p>
        </div>
        <div class="info-section" style="text-align: center;">
          <h3>{{ stats.pending_inquiries }}</h3>
          <p>Pending Inquiries</p>
        </div>
        <div class="info-section" style="text-align: center;">
          <h3>{{ stats.pending_bookings }}</h3>
          <p>Pending Bookings</p>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="info-section">
        <h2>Quick Actions</h2>
        <div style="display: flex; gap: 1rem; flex-wrap: wrap; margin-top: 1rem;">
          <router-link to="/admin/properties" class="btn btn-primary">
            <i class="fas fa-building"></i> Manage Properties
          </router-link>
          <router-link to="/admin/bookings" class="btn btn-primary">
            <i class="fas fa-calendar"></i> Manage Bookings
          </router-link>
          <router-link to="/admin/inquiries" class="btn btn-primary">
            <i class="fas fa-envelope"></i> Manage Inquiries
          </router-link>
          <router-link v-if="user?.role === 'admin'" to="/super-admin" class="btn btn-danger">
            <i class="fas fa-crown"></i> Super Admin
          </router-link>
          <router-link to="/properties" class="btn btn-outline">
            <i class="fas fa-eye"></i> View Public Site
          </router-link>
        </div>
      </div>

      <!-- Recent Activity -->
      <div class="info-section" style="margin-top: 2rem;">
        <h2>Recent Inquiries</h2>
        <div v-if="inquiries.length === 0">
          <p>No inquiries yet</p>
        </div>
        <table v-else style="width: 100%; margin-top: 1rem;">
          <thead>
            <tr style="border-bottom: 2px solid var(--border);">
              <th style="padding: 0.75rem; text-align: left;">Name</th>
              <th style="padding: 0.75rem; text-align: left;">Property</th>
              <th style="padding: 0.75rem; text-align: left;">Date</th>
              <th style="padding: 0.75rem; text-align: left;">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="inquiry in inquiries.slice(0, 5)" :key="inquiry.inquiry_id" style="border-bottom: 1px solid var(--border);">
              <td style="padding: 0.75rem;">{{ inquiry.name }}</td>
              <td style="padding: 0.75rem;">{{ inquiry.property_title }}</td>
              <td style="padding: 0.75rem;">{{ formatDate(inquiry.created_at) }}</td>
              <td style="padding: 0.75rem;">
                <span :style="{ color: inquiry.status === 'pending' ? 'var(--warning)' : 'var(--secondary)' }">
                  {{ inquiry.status }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import api from '../api'
import { useDialog } from '../composables/useDialog'

const { alert: showAlert } = useDialog()
const router = useRouter()
const authStore = useAuthStore()
const user = computed(() => authStore.user)
const loading = ref(true)
const stats = ref({})
const inquiries = ref([])

onMounted(async () => {
  try {
    const [statsRes, inquiriesRes] = await Promise.all([
      api.getStats(),
      api.getInquiries({ limit: 10 })
    ])
    stats.value = statsRes.data
    inquiries.value = inquiriesRes.data
  } catch (error) {
    console.error('Error loading dashboard:', error)
  } finally {
    loading.value = false
  }
})

const formatDate = (date) => {
  return new Date(date).toLocaleDateString()
}

const viewInquiries = async () => {
  await showAlert('Inquiries management coming soon!', 'Coming Soon')
}

const viewBookings = () => {
  router.push('/admin/bookings')
}
</script>
