<template>
  <v-container fluid class="pa-6">
    <!-- Header -->
    <v-row>
      <v-col cols="12">
        <div class="d-flex align-center mb-6">
          <v-icon size="48" color="primary" class="mr-3">mdi-shield-crown</v-icon>
          <div>
            <h1 class="text-h4 font-weight-bold">Super Admin Control Center</h1>
            <p class="text-subtitle-1 text-grey">Complete system-wide configuration and oversight</p>
          </div>
        </div>
      </v-col>
    </v-row>

    <!-- Quick Stats -->
    <v-row>
      <v-col cols="12" sm="6" md="3">
        <v-card elevation="2" color="primary" dark>
          <v-card-text>
            <div class="d-flex align-center">
              <v-avatar color="white" size="56" class="mr-4">
                <v-icon size="32" color="primary">mdi-office-building</v-icon>
              </v-avatar>
              <div>
                <div class="text-h4 font-weight-bold">{{ stats.branches }}</div>
                <div class="text-subtitle-2">Active Branches</div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card elevation="2" color="success" dark>
          <v-card-text>
            <div class="d-flex align-center">
              <v-avatar color="white" size="56" class="mr-4">
                <v-icon size="32" color="success">mdi-account-group</v-icon>
              </v-avatar>
              <div>
                <div class="text-h4 font-weight-bold">{{ stats.users }}</div>
                <div class="text-subtitle-2">Active Users</div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card elevation="2" color="info" dark>
          <v-card-text>
            <div class="d-flex align-center">
              <v-avatar color="white" size="56" class="mr-4">
                <v-icon size="32" color="info">mdi-pill</v-icon>
              </v-avatar>
              <div>
                <div class="text-h4 font-weight-bold">{{ stats.medicines }}</div>
                <div class="text-subtitle-2">Total Medicines</div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>

      <v-col cols="12" sm="6" md="3">
        <v-card elevation="2" color="warning" dark>
          <v-card-text>
            <div class="d-flex align-center">
              <v-avatar color="white" size="56" class="mr-4">
                <v-icon size="32" color="warning">mdi-cash-multiple</v-icon>
              </v-avatar>
              <div>
                <div class="text-h4 font-weight-bold">{{ formatCurrency(stats.todaySales) }}</div>
                <div class="text-subtitle-2">Today's Sales</div>
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <!-- Main Control Sections -->
    <v-row class="mt-4">
      <v-col cols="12">
        <v-card elevation="2">
          <v-tabs v-model="activeTab" color="primary">
            <v-tab value="config">
              <v-icon left>mdi-cog</v-icon>
              System Configuration
            </v-tab>
            <v-tab value="users">
              <v-icon left>mdi-account-group</v-icon>
              User Management
            </v-tab>
            <v-tab value="master">
              <v-icon left>mdi-database</v-icon>
              Master Data
            </v-tab>
            <v-tab value="pricing">
              <v-icon left>mdi-cash</v-icon>
              Pricing & Rules
            </v-tab>
            <v-tab value="security">
              <v-icon left>mdi-shield-check</v-icon>
              Security & Audit
            </v-tab>
            <v-tab value="reports">
              <v-icon left>mdi-chart-bar</v-icon>
              Reports & Oversight
            </v-tab>
          </v-tabs>

          <v-window v-model="activeTab">
            <!-- System Configuration Tab -->
            <v-window-item value="config">
              <v-card-text>
                <h3 class="text-h6 mb-4">System-wide Configuration</h3>
                
                <v-row>
                  <v-col cols="12" md="6">
                    <v-card elevation="1" class="mb-4">
                      <v-card-title>Company Profile</v-card-title>
                      <v-card-text>
                        <v-text-field label="Company Name" v-model="companySettings.name" density="compact"></v-text-field>
                        <v-text-field label="Address" v-model="companySettings.address" density="compact"></v-text-field>
                        <v-text-field label="Phone" v-model="companySettings.phone" density="compact"></v-text-field>
                        <v-text-field label="Email" v-model="companySettings.email" density="compact"></v-text-field>
                        <v-text-field label="Tax ID / VAT" v-model="companySettings.taxId" density="compact"></v-text-field>
                      </v-card-text>
                      <v-card-actions>
                        <v-btn color="primary" @click="saveCompanySettings">Save Company Profile</v-btn>
                      </v-card-actions>
                    </v-card>
                  </v-col>

                  <v-col cols="12" md="6">
                    <v-card elevation="1" class="mb-4">
                      <v-card-title>Regional Settings</v-card-title>
                      <v-card-text>
                        <v-select label="Currency" v-model="regionalSettings.currency" :items="['ETB', 'USD', 'EUR']" density="compact"></v-select>
                        <v-select label="Timezone" v-model="regionalSettings.timezone" :items="timezones" density="compact"></v-select>
                        <v-select label="Date Format" v-model="regionalSettings.dateFormat" :items="['DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD']" density="compact"></v-select>
                        <v-select label="Time Format" v-model="regionalSettings.timeFormat" :items="['12h', '24h']" density="compact"></v-select>
                        <v-select label="Language" v-model="regionalSettings.language" :items="['en', 'am']" density="compact"></v-select>
                      </v-card-text>
                      <v-card-actions>
                        <v-btn color="primary" @click="saveRegionalSettings">Save Regional Settings</v-btn>
                      </v-card-actions>
                    </v-card>
                  </v-col>
                </v-row>

                <v-row>
                  <v-col cols="12" md="4">
                    <v-card elevation="1" hover @click="$router.push('/branches')" class="text-center pa-4">
                      <v-icon size="48" color="primary" class="mb-2">mdi-office-building</v-icon>
                      <div class="text-subtitle-1 font-weight-medium">Manage Branches</div>
                      <div class="text-caption">Add / Edit / Deactivate</div>
                    </v-card>
                  </v-col>
                </v-row>
              </v-card-text>
            </v-window-item>

            <!-- User Management Tab -->
            <v-window-item value="users">
              <v-card-text>
                <h3 class="text-h6 mb-4">User Management & Access Control</h3>
                
                <v-row>
                  <v-col cols="12" md="4">
                    <v-card elevation="1" hover @click="$router.push('/users')" class="text-center pa-4">
                      <v-icon size="48" color="success" class="mb-2">mdi-account-multiple</v-icon>
                      <div class="text-subtitle-1 font-weight-medium">Manage Users</div>
                      <div class="text-caption">Create, Edit, Assign Roles</div>
                    </v-card>
                  </v-col>

                  <v-col cols="12" md="4">
                    <v-card elevation="1" hover @click="openRolesPermissions" class="text-center pa-4" style="cursor: pointer;">
                      <v-icon size="48" color="info" class="mb-2">mdi-shield-account</v-icon>
                      <div class="text-subtitle-1 font-weight-medium">Roles & Permissions</div>
                      <div class="text-caption">Configure Access Control</div>
                    </v-card>
                  </v-col>

                  <v-col cols="12" md="4">
                    <v-card elevation="1" hover @click="openPasswordManagement" class="text-center pa-4" style="cursor: pointer;">
                      <v-icon size="48" color="warning" class="mb-2">mdi-lock-reset</v-icon>
                      <div class="text-subtitle-1 font-weight-medium">Password Management</div>
                      <div class="text-caption">Reset, Lock/Unlock Users</div>
                    </v-card>
                  </v-col>
                </v-row>
              </v-card-text>
            </v-window-item>

            <!-- Master Data Tab -->
            <v-window-item value="master">
              <v-card-text>
                <h3 class="text-h6 mb-4">Master Data Control</h3>
                
                <v-row>
                  <v-col cols="12" md="4">
                    <v-card elevation="1" hover @click="$router.push('/medicines')" class="text-center pa-4">
                      <v-icon size="48" color="primary" class="mb-2">mdi-pill</v-icon>
                      <div class="text-subtitle-1 font-weight-medium">Medicine Master List</div>
                      <div class="text-caption">Manage All Medicines</div>
                    </v-card>
                  </v-col>

                  <v-col cols="12" md="4">
                    <v-card elevation="1" hover @click="openCategoriesForms" class="text-center pa-4" style="cursor: pointer;">
                      <v-icon size="48" color="success" class="mb-2">mdi-tag-multiple</v-icon>
                      <div class="text-subtitle-1 font-weight-medium">Categories & Forms</div>
                      <div class="text-caption">Define Classifications</div>
                    </v-card>
                  </v-col>

                  <v-col cols="12" md="4">
                    <v-card elevation="1" hover @click="openBulkImport" class="text-center pa-4" style="cursor: pointer;">
                      <v-icon size="48" color="info" class="mb-2">mdi-file-excel</v-icon>
                      <div class="text-subtitle-1 font-weight-medium">Bulk Import</div>
                      <div class="text-caption">Import from Excel</div>
                    </v-card>
                  </v-col>
                </v-row>
              </v-card-text>
            </v-window-item>

            <!-- Pricing & Rules Tab -->
            <v-window-item value="pricing">
              <v-card-text>
                <h3 class="text-h6 mb-4">Pricing & Business Rules</h3>
                
                <v-row>
                  <v-col cols="12" md="6">
                    <v-card elevation="1">
                      <v-card-title>Tax & VAT Rules</v-card-title>
                      <v-card-text>
                        <v-text-field label="Default Tax Rate (%)" v-model="taxSettings.rate" type="number" density="compact"></v-text-field>
                        <v-switch label="Enable Tax Calculation" v-model="taxSettings.enabled" color="primary"></v-switch>
                        <v-switch label="Tax Inclusive Pricing" v-model="taxSettings.inclusive" color="primary"></v-switch>
                      </v-card-text>
                      <v-card-actions>
                        <v-btn color="primary" @click="saveTaxSettings">Save Tax Settings</v-btn>
                      </v-card-actions>
                    </v-card>
                  </v-col>

                  <v-col cols="12" md="6">
                    <v-card elevation="1">
                      <v-card-title>Discount Rules</v-card-title>
                      <v-card-text>
                        <v-switch label="Enable Discounts" v-model="discountSettings.enabled" color="primary"></v-switch>
                        <v-text-field label="Maximum Discount (%)" v-model="discountSettings.maxPercent" type="number" density="compact"></v-text-field>
                        <v-switch label="Require Manager Approval" v-model="discountSettings.requireApproval" color="primary"></v-switch>
                      </v-card-text>
                      <v-card-actions>
                        <v-btn color="primary" @click="saveDiscountSettings">Save Discount Settings</v-btn>
                      </v-card-actions>
                    </v-card>
                  </v-col>
                </v-row>

                <v-row class="mt-4">
                  <v-col cols="12" md="6">
                    <v-card elevation="1">
                      <v-card-title>Invoice Settings</v-card-title>
                      <v-card-text>
                        <v-text-field label="Invoice Prefix" v-model="invoiceSettings.prefix" density="compact"></v-text-field>
                        <v-text-field label="Starting Number" v-model="invoiceSettings.startNumber" type="number" density="compact"></v-text-field>
                        <v-textarea label="Footer Text" v-model="invoiceSettings.footerText" rows="2" density="compact"></v-textarea>
                        <v-switch label="Auto-print Invoice" v-model="invoiceSettings.autoPrint" color="primary"></v-switch>
                      </v-card-text>
                      <v-card-actions>
                        <v-btn color="primary" @click="saveInvoiceSettings">Save Invoice Settings</v-btn>
                      </v-card-actions>
                    </v-card>
                  </v-col>

                  <v-col cols="12" md="6">
                    <v-card elevation="1">
                      <v-card-title>Stock Policies</v-card-title>
                      <v-card-text>
                        <v-text-field label="Default Reorder Level" v-model="stockSettings.reorderLevel" type="number" density="compact"></v-text-field>
                        <v-text-field label="Low Stock Threshold" v-model="stockSettings.lowStockThreshold" type="number" density="compact"></v-text-field>
                        <v-switch label="Allow Negative Stock" v-model="stockSettings.allowNegative" color="primary"></v-switch>
                      </v-card-text>
                      <v-card-actions>
                        <v-btn color="primary" @click="saveStockSettings">Save Stock Settings</v-btn>
                      </v-card-actions>
                    </v-card>
                  </v-col>
                </v-row>
              </v-card-text>
            </v-window-item>

            <!-- Security & Audit Tab -->
            <v-window-item value="security">
              <v-card-text>
                <h3 class="text-h6 mb-4">Security, Audit & Compliance</h3>
                
                <v-row>
                  <v-col cols="12" md="6">
                    <v-card elevation="1">
                      <v-card-title>Security Settings</v-card-title>
                      <v-card-text>
                        <v-text-field label="Min Password Length" v-model="securitySettings.minPasswordLength" type="number" density="compact"></v-text-field>
                        <v-text-field label="Session Timeout (minutes)" v-model="securitySettings.sessionTimeout" type="number" density="compact"></v-text-field>
                        <v-text-field label="Max Login Attempts" v-model="securitySettings.maxLoginAttempts" type="number" density="compact"></v-text-field>
                        <v-switch label="Require Special Characters" v-model="securitySettings.requireSpecial" color="primary"></v-switch>
                      </v-card-text>
                      <v-card-actions>
                        <v-btn color="primary" @click="saveSecuritySettings">Save Security Settings</v-btn>
                      </v-card-actions>
                    </v-card>
                  </v-col>

                  <v-col cols="12" md="6">
                    <v-card elevation="1">
                      <v-card-title>Audit & Compliance</v-card-title>
                      <v-card-text>
                        <v-switch label="Enable Audit Logging" v-model="auditSettings.enabled" color="primary"></v-switch>
                        <v-text-field label="Backup Frequency (days)" v-model="auditSettings.backupFrequency" type="number" density="compact"></v-text-field>
                        <p class="text-caption mt-2">Audit logs track: Price changes, Stock adjustments, Deleted invoices</p>
                      </v-card-text>
                      <v-card-actions>
                        <v-btn color="primary" @click="viewAuditLogs">View Audit Logs</v-btn>
                      </v-card-actions>
                    </v-card>
                  </v-col>
                </v-row>
              </v-card-text>
            </v-window-item>

            <!-- Reports & Oversight Tab -->
            <v-window-item value="reports">
              <v-card-text>
                <h3 class="text-h6 mb-4">Reporting & Oversight</h3>
                
                <v-row>
                  <v-col cols="12" md="4" v-for="report in reports" :key="report.type">
                    <v-card elevation="1" hover @click="generateReport(report.type)" class="text-center pa-4">
                      <v-icon size="48" :color="report.color" class="mb-2">{{ report.icon }}</v-icon>
                      <div class="text-subtitle-1 font-weight-medium">{{ report.title }}</div>
                      <div class="text-caption">{{ report.description }}</div>
                    </v-card>
                  </v-col>
                </v-row>
              </v-card-text>
            </v-window-item>
          </v-window>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import api from '../api';

export default {
  name: 'ComprehensiveSuperAdmin',
  data() {
    return {
      activeTab: 'config',
      stats: {
        branches: 0,
        users: 0,
        medicines: 0,
        todaySales: 0
      },
      companySettings: {
        name: '',
        address: '',
        phone: '',
        email: '',
        taxId: ''
      },
      regionalSettings: {
        currency: 'ETB',
        timezone: 'Africa/Addis_Ababa',
        dateFormat: 'DD/MM/YYYY',
        timeFormat: '24h',
        language: 'en'
      },
      taxSettings: {
        rate: 15,
        enabled: true,
        inclusive: false
      },
      discountSettings: {
        enabled: true,
        maxPercent: 20,
        requireApproval: false
      },
      invoiceSettings: {
        prefix: 'INV',
        startNumber: 1001,
        footerText: 'Thank you for your business!',
        autoPrint: false
      },
      stockSettings: {
        reorderLevel: 20,
        lowStockThreshold: 10,
        allowNegative: false
      },
      securitySettings: {
        minPasswordLength: 6,
        sessionTimeout: 480,
        maxLoginAttempts: 5,
        requireSpecial: false
      },
      auditSettings: {
        enabled: true,
        backupFrequency: 7
      },
      timezones: [
        'Africa/Addis_Ababa',
        'Africa/Nairobi',
        'Africa/Cairo',
        'UTC'
      ],
      reports: [
        { type: 'all-branch-sales', title: 'All-Branch Sales', description: 'Total sales across company', icon: 'mdi-chart-line', color: 'primary' },
        { type: 'inventory-value', title: 'Inventory Valuation', description: 'Stock value by branch', icon: 'mdi-package-variant', color: 'success' },
        { type: 'top-selling', title: 'Top Selling Items', description: 'Best performers', icon: 'mdi-trophy', color: 'warning' },
        { type: 'slow-moving', title: 'Slow Moving Items', description: 'Items needing attention', icon: 'mdi-turtle', color: 'secondary' },
        { type: 'near-expiry', title: 'Near-Expiry Items', description: 'Expiring soon', icon: 'mdi-alert', color: 'error' },
        { type: 'branch-performance', title: 'Branch Performance', description: 'Compare branches', icon: 'mdi-chart-bar', color: 'info' }
      ]
    };
  },
  mounted() {
    this.loadStats();
    this.loadSettings();
  },
  methods: {
    async loadStats() {
      try {
        // Load statistics from API
        const statsRes = await api.get('/system/statistics');
        if (statsRes.data && statsRes.data.statistics) {
          this.stats.branches = statsRes.data.statistics.active_branches || 0;
          this.stats.users = statsRes.data.statistics.active_users || 0;
          this.stats.medicines = statsRes.data.statistics.total_medicines || 0;
          this.stats.todaySales = statsRes.data.statistics.today_sales_amount || 0;
        }
        
        // Also load actual counts from branches and users endpoints
        const [branchesRes, usersRes] = await Promise.all([
          api.get('/branches').catch(() => ({ data: [] })),
          api.get('/users').catch(() => ({ data: [] }))
        ]);
        
        // Update with actual counts if available
        if (branchesRes.data) {
          this.stats.branches = Array.isArray(branchesRes.data) ? branchesRes.data.length : this.stats.branches;
        }
        if (usersRes.data) {
          this.stats.users = Array.isArray(usersRes.data) ? usersRes.data.length : this.stats.users;
        }
      } catch (error) {
        console.error('Error loading stats:', error);
        // Set default values on error
        this.stats = {
          branches: 0,
          users: 0,
          medicines: 0,
          todaySales: 0
        };
      }
    },
    async loadSettings() {
      // Load settings from API
      console.log('Loading settings...');
    },
    async saveCompanySettings() {
      alert('Company settings saved!');
    },
    async saveRegionalSettings() {
      alert('Regional settings saved!');
    },
    async saveTaxSettings() {
      alert('Tax settings saved!');
    },
    async saveDiscountSettings() {
      alert('Discount settings saved!');
    },
    async saveInvoiceSettings() {
      alert('Invoice settings saved!');
    },
    async saveStockSettings() {
      alert('Stock settings saved!');
    },
    async saveSecuritySettings() {
      alert('Security settings saved!');
    },
    viewAuditLogs() {
      alert('Viewing audit logs...');
    },
    generateReport(type) {
      this.$router.push(`/reports?type=${type}`);
    },
    openRolesPermissions() {
      // Navigate to users page where roles can be managed
      this.$router.push('/users');
    },
    openPasswordManagement() {
      // Navigate to users page for password management
      this.$router.push('/users');
    },
    openCategoriesForms() {
      // Show categories management dialog or navigate
      alert('Categories & Forms management - Coming soon!\nFor now, categories are managed when adding medicines.');
    },
    openBulkImport() {
      // Navigate to bulk import if available, otherwise show message
      alert('Bulk Import - Use the Medicines page to import from Excel template.');
    },
    formatCurrency(amount) {
      return `Br ${Number(amount || 0).toLocaleString('en-ET', { minimumFractionDigits: 2 })}`;
    }
  }
};
</script>
