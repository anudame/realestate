<template>
  <div class="register-container">
    <div class="register-box">
      <h1>🚀 Start Your Free 30-Day Trial</h1>
      <p style="text-align: center; color: #7f8c8d; margin-bottom: 30px;">
        No credit card required • Full access to all features • Cancel anytime
      </p>

      <div v-if="error" class="error">{{ error }}</div>
      <div v-if="success" class="success">{{ success }}</div>

      <form @submit.prevent="startTrial" v-if="!success">
        <!-- Pharmacy Information -->
        <div class="section">
          <h3>📋 Pharmacy Information</h3>
          <div class="form-group">
            <label>Pharmacy Name *</label>
            <input v-model="pharmacy.name" required placeholder="e.g., City Pharmacy" />
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Location *</label>
              <input v-model="pharmacy.location" required placeholder="e.g., Addis Ababa" />
            </div>
            <div class="form-group">
              <label>Phone</label>
              <input v-model="pharmacy.phone" type="tel" placeholder="+251..." />
            </div>
          </div>
        </div>

        <!-- Owner Information -->
        <div class="section">
          <h3>👤 Owner Information</h3>
          <div class="form-group">
            <label>Full Name *</label>
            <input v-model="owner.name" required placeholder="Your full name" />
          </div>
          <div class="form-group">
            <label>Email Address *</label>
            <input v-model="owner.email" type="email" required placeholder="your@email.com" />
            <small>We'll send your trial details here</small>
          </div>
        </div>

        <!-- Admin Account -->
        <div class="section">
          <h3>🔐 Create Admin Account</h3>
          <div class="form-group">
            <label>Username *</label>
            <input v-model="admin.username" required placeholder="Choose a username" />
          </div>
          <div class="form-group">
            <label>Password *</label>
            <input v-model="admin.password" type="password" required minlength="6" placeholder="Minimum 6 characters" />
          </div>
        </div>

        <!-- Trial Benefits -->
        <div class="benefits">
          <h4>✨ What's included in your trial:</h4>
          <ul>
            <li>✅ 1 Branch location</li>
            <li>✅ Up to 2 users</li>
            <li>✅ Full POS system</li>
            <li>✅ Inventory management</li>
            <li>✅ Basic reports</li>
            <li>✅ Email support</li>
          </ul>
        </div>

        <button type="submit" class="btn btn-primary" :disabled="loading">
          {{ loading ? 'Creating Your Account...' : '🚀 Start Free Trial' }}
        </button>

        <p style="text-align: center; margin-top: 20px; font-size: 14px; color: #7f8c8d;">
          Already have an account? <router-link to="/login">Login here</router-link>
        </p>
      </form>
    </div>
  </div>
</template>

<script>
import api from '../api'

export default {
  data() {
    return {
      pharmacy: {
        name: '',
        location: '',
        phone: ''
      },
      owner: {
        name: '',
        email: ''
      },
      admin: {
        username: '',
        password: ''
      },
      loading: false,
      error: '',
      success: ''
    }
  },
  methods: {
    async startTrial() {
      this.error = ''
      this.loading = true

      try {
        const response = await api.post('/tenant/start-trial', {
          pharmacy: this.pharmacy,
          owner: this.owner,
          admin: this.admin
        })

        this.success = response.data.message
        
        setTimeout(() => {
          this.$router.push('/login')
        }, 3000)

      } catch (err) {
        this.error = err.response?.data?.error || 'Failed to start trial. Please try again.'
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style scoped>
.register-container {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.register-box {
  background: white;
  padding: 40px;
  border-radius: 12px;
  box-shadow: 0 10px 40px rgba(0,0,0,0.2);
  max-width: 600px;
  width: 100%;
}

.register-box h1 {
  text-align: center;
  color: #2c3e50;
  margin-bottom: 10px;
}

.section {
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 1px solid #ecf0f1;
}

.section h3 {
  color: #2c3e50;
  margin-bottom: 15px;
  font-size: 18px;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 15px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #2c3e50;
  font-weight: 600;
}

.form-group input {
  width: 100%;
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
}

.form-group input:focus {
  outline: none;
  border-color: #667eea;
}

.form-group small {
  display: block;
  margin-top: 5px;
  color: #7f8c8d;
  font-size: 12px;
}

.benefits {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
}

.benefits h4 {
  color: #2c3e50;
  margin-bottom: 15px;
}

.benefits ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.benefits li {
  padding: 8px 0;
  color: #2c3e50;
}

.btn {
  width: 100%;
  padding: 15px;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.btn-primary:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}

.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.error {
  background: #fee;
  color: #c00;
  padding: 12px;
  border-radius: 6px;
  margin-bottom: 20px;
}

.success {
  background: #efe;
  color: #060;
  padding: 12px;
  border-radius: 6px;
  margin-bottom: 20px;
}

a {
  color: #667eea;
  text-decoration: none;
  font-weight: 600;
}

a:hover {
  text-decoration: underline;
}
</style>
