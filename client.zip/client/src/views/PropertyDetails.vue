<template>
  <div class="property-details">
    <div v-if="loading" class="loading container">
      <div class="spinner"></div>
      <p>Loading property...</p>
    </div>

    <div v-else-if="property" class="container">
      <!-- Gallery -->
      <div class="property-gallery" v-if="property.images && property.images.length > 0">
        <img 
          v-for="image in property.images" 
          :key="image.image_id"
          :src="image.image_url" 
          :alt="property.title"
        >
      </div>

      <!-- Videos -->
      <div class="property-videos" v-if="property.videos && property.videos.length > 0">
        <h2 style="margin: 2rem 0 1rem 0;">Property Videos</h2>
        <div class="videos-grid">
          <video 
            v-for="video in property.videos" 
            :key="video.video_id"
            :src="video.video_url"
            controls
            class="property-video"
          >
            Your browser does not support the video tag.
          </video>
        </div>
      </div>

      <!-- Info -->
      <div class="property-info">
        <div>
          <div class="info-section">
            <div class="property-price" style="font-size: 2rem;">
              {{ formatPrice(property.price) }} ETB
            </div>
            <h1>{{ property.title }}</h1>
            <div class="property-location" style="font-size: 1.125rem; margin: 1rem 0;">
              <i class="fas fa-map-marker-alt"></i>
              {{ property.address }}, {{ property.city_name }}
            </div>

            <div class="property-features" style="font-size: 1.125rem; margin: 1.5rem 0;">
              <span v-if="property.bedrooms">
                <i class="fas fa-bed"></i> {{ property.bedrooms }} Beds
              </span>
              <span v-if="property.bathrooms">
                <i class="fas fa-bath"></i> {{ property.bathrooms }} Baths
              </span>
              <span v-if="property.size">
                <i class="fas fa-ruler-combined"></i> {{ property.size }} m²
              </span>
              <span v-if="property.parking">
                <i class="fas fa-car"></i> Parking Available
              </span>
            </div>

            <h2>Description</h2>
            <p style="line-height: 1.8;">{{ property.description }}</p>

            <div v-if="property.amenities && property.amenities.length > 0" style="margin-top: 2rem;">
              <h2>Amenities</h2>
              <div class="amenities-grid">
                <div v-for="amenity in sortedAmenities" :key="amenity.amenity_id" class="amenity-item">
                  <i class="fas fa-check-circle" style="color: var(--secondary);"></i>
                  {{ amenity.name }}
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Contact Form -->
        <div>
          <div class="info-section">
            <h2>Contact Agent</h2>
            <p><strong>{{ property.owner_name }}</strong></p>
            <p><i class="fas fa-phone"></i> {{ property.owner_phone }}</p>
            
            <form @submit.prevent="submitInquiry" style="margin-top: 1.5rem;">
              <div class="form-group">
                <input v-model="inquiry.name" type="text" placeholder="Your Name" required>
              </div>
              <div class="form-group">
                <input v-model="inquiry.email" type="email" placeholder="Your Email" required>
              </div>
              <div class="form-group">
                <input v-model="inquiry.phone" type="tel" placeholder="Your Phone" required>
              </div>
              <div class="form-group">
                <textarea v-model="inquiry.message" placeholder="Your Message" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary" style="width: 100%;" :disabled="submitting">
                {{ submitting ? 'Sending...' : 'Send Inquiry' }}
              </button>
            </form>

            <div v-if="inquirySuccess" class="alert alert-success" style="margin-top: 1rem;">
              Inquiry sent successfully!
            </div>
          </div>

          <!-- Book Visit -->
          <div class="info-section" style="margin-top: 1rem;">
            <h2>Book a Visit</h2>
            <form @submit.prevent="submitBooking">
              <div class="form-group">
                <input v-model="booking.name" type="text" placeholder="Your Name" required>
              </div>
              <div class="form-group">
                <input v-model="booking.email" type="email" placeholder="Your Email" required>
              </div>
              <div class="form-group">
                <input v-model="booking.phone" type="tel" placeholder="Your Phone" required>
              </div>
              <div class="form-group">
                <input v-model="booking.date" type="date" required>
              </div>
              <div class="form-group">
                <input v-model="booking.time" type="time" required>
              </div>
              <button type="submit" class="btn btn-secondary" style="width: 100%;" :disabled="bookingSubmitting">
                {{ bookingSubmitting ? 'Booking...' : 'Book Visit' }}
              </button>
            </form>

            <div v-if="bookingSuccess" class="alert alert-success" style="margin-top: 1rem;">
              Booking request sent successfully!
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import api from '../api'

const route = useRoute()
const loading = ref(true)
const property = ref(null)

// Sort amenities alphabetically
const sortedAmenities = computed(() => {
  if (!property.value?.amenities) return []
  return [...property.value.amenities].sort((a, b) => a.name.localeCompare(b.name))
})
const submitting = ref(false)
const inquirySuccess = ref(false)
const bookingSubmitting = ref(false)
const bookingSuccess = ref(false)

const inquiry = ref({
  name: '',
  email: '',
  phone: '',
  message: 'I am interested in this property. Please contact me.'
})

const booking = ref({
  name: '',
  email: '',
  phone: '',
  date: '',
  time: ''
})

onMounted(async () => {
  try {
    const response = await api.getProperty(route.params.id)
    property.value = response.data
  } catch (error) {
    console.error('Error loading property:', error)
  } finally {
    loading.value = false
  }
})

const formatPrice = (price) => {
  return new Intl.NumberFormat('en-US').format(price)
}

const submitInquiry = async () => {
  submitting.value = true
  inquirySuccess.value = false
  try {
    await api.submitInquiry({
      property_id: property.value.property_id,
      ...inquiry.value
    })
    inquirySuccess.value = true
    inquiry.value.message = 'I am interested in this property. Please contact me.'
  } catch (error) {
    await showError('Error sending inquiry. Please try again.')
  } finally {
    submitting.value = false
  }
}

const submitBooking = async () => {
  bookingSubmitting.value = true
  bookingSuccess.value = false
  try {
    await api.submitBooking({
      property_id: property.value.property_id,
      ...booking.value,
      booking_date: booking.value.date,
      booking_time: booking.value.time
    })
    bookingSuccess.value = true
    booking.value = { name: '', email: '', phone: '', date: '', time: '' }
  } catch (error) {
    await showError('Error booking visit. Please try again.')
  } finally {
    bookingSubmitting.value = false
  }
}
</script>

<style scoped>
.property-videos {
  margin: 2rem 0;
}

.videos-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 1.5rem;
}

.property-video {
  width: 100%;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  background: #000;
}

@media (max-width: 768px) {
  .videos-grid {
    grid-template-columns: 1fr;
  }
}
</style>
