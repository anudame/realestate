<template>
  <div class="container">
    <h1>Branch Management</h1>
    
    <!-- Add New Branch -->
    <div class="card">
      <h3>{{ editingBranch ? 'Edit Branch' : 'Add New Branch' }}</h3>
      <form @submit.prevent="saveBranch">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div class="form-group">
            <label>Branch Name *</label>
            <input v-model="branch.branchName" required />
          </div>
          <div class="form-group">
            <label>Location *</label>
            <input v-model="branch.location" required />
          </div>
          <div class="form-group">
            <label>Phone</label>
            <input v-model="branch.phone" type="tel" />
          </div>
          <div class="form-group">
            <label>Manager Name</label>
            <input v-model="branch.managerName" />
          </div>
          <div class="form-group">
            <label>Branch Password *</label>
            <input v-model="branch.password" type="password" required minlength="6" 
                   placeholder="Minimum 6 characters" />
          </div>
          <div class="form-group" v-if="editingBranch">
            <label>Status</label>
            <select v-model="branch.status">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
        <div style="display: flex; gap: 10px;">
          <button type="submit" class="btn btn-primary">
            {{ editingBranch ? 'Update Branch' : 'Add Branch' }}
          </button>
          <button v-if="editingBranch" @click="cancelEdit" type="button" class="btn" 
                  style="background: #95a5a6; color: white;">
            Cancel
          </button>
        </div>
      </form>
    </div>

    <!-- Branches List -->
    <div class="card" style="margin-top: 20px;">
      <h3>All Branches</h3>
      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; margin-top: 20px;">
        <div v-for="b in branches" :key="b.branch_id" 
             style="border: 2px solid #e0e0e0; border-radius: 12px; padding: 20px; background: #f8f9fa; position: relative;">
          <div style="position: absolute; top: 15px; right: 15px; display: flex; gap: 8px;">
            <span v-if="b.is_main" :style="{
              padding: '4px 12px',
              borderRadius: '12px',
              fontSize: '12px',
              fontWeight: 'bold',
              backgroundColor: '#9b59b6',
              color: 'white'
            }">
              Main Branch
            </span>
            <span :style="{
              padding: '4px 12px',
              borderRadius: '12px',
              fontSize: '12px',
              fontWeight: 'bold',
              backgroundColor: b.status === 'active' ? '#27ae60' : '#e74c3c',
              color: 'white'
            }">
              {{ b.status }}
            </span>
          </div>
          
          <h4 style="margin-bottom: 15px; color: #2c3e50;">{{ b.branch_name }}</h4>
          
          <div v-if="b.parent_branch_name" style="margin-bottom: 10px;">
            <strong style="color: #7f8c8d;">🏢 Parent Branch:</strong>
            <p style="margin: 5px 0;">{{ b.parent_branch_name }}</p>
          </div>
          
          <div v-if="b.sub_branch_count > 0" style="margin-bottom: 10px;">
            <strong style="color: #7f8c8d;">📊 Sub-Branches:</strong>
            <p style="margin: 5px 0;">{{ b.sub_branch_count }}</p>
          </div>
          
          <div style="margin-bottom: 10px;">
            <strong style="color: #7f8c8d;">📍 Location:</strong>
            <p style="margin: 5px 0;">{{ b.location }}</p>
          </div>
          
          <div style="margin-bottom: 10px;" v-if="b.phone">
            <strong style="color: #7f8c8d;">📞 Phone:</strong>
            <p style="margin: 5px 0;">{{ b.phone }}</p>
          </div>
          
          <div style="margin-bottom: 15px;" v-if="b.manager_name">
            <strong style="color: #7f8c8d;">👤 Manager:</strong>
            <p style="margin: 5px 0;">{{ b.manager_name }}</p>
          </div>
          
          <div style="display: flex; gap: 10px; margin-top: 15px;">
            <button @click="editBranch(b)" class="btn btn-primary" style="flex: 1; padding: 8px;">
              Edit
            </button>
            <button @click="deleteBranch(b.branch_id)" class="btn" 
                    style="flex: 1; padding: 8px; background: #e74c3c; color: white;">
              Delete
            </button>
          </div>
        </div>
      </div>
      
      <p v-if="branches.length === 0" style="text-align: center; color: #95a5a6; padding: 40px;">
        No branches found. Add your first branch above.
      </p>
    </div>

    <!-- Branch Statistics -->
    <div class="card" style="margin-top: 20px;">
      <h3>Branch Statistics</h3>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
        <div style="padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 8px; color: white;">
          <h4 style="margin: 0; font-size: 16px;">Total Branches</h4>
          <p style="font-size: 32px; font-weight: bold; margin: 10px 0 0 0;">{{ branches.length }}</p>
        </div>
        <div style="padding: 20px; background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%); border-radius: 8px; color: white;">
          <h4 style="margin: 0; font-size: 16px;">Active Branches</h4>
          <p style="font-size: 32px; font-weight: bold; margin: 10px 0 0 0;">{{ activeBranches }}</p>
        </div>
        <div style="padding: 20px; background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%); border-radius: 8px; color: white;">
          <h4 style="margin: 0; font-size: 16px;">Inactive Branches</h4>
          <p style="font-size: 32px; font-weight: bold; margin: 10px 0 0 0;">{{ inactiveBranches }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../api'

export default {
  data() {
    return {
      branches: [],
      branch: {
        branchName: '',
        location: '',
        phone: '',
        managerName: '',
        password: '',
        status: 'active'
      },
      editingBranch: null
    }
  },
  computed: {
    activeBranches() {
      return this.branches.filter(b => b.status === 'active').length
    },
    inactiveBranches() {
      return this.branches.filter(b => b.status === 'inactive').length
    }
  },
  async mounted() {
    await this.loadBranches()
    this.checkSuperAdmin()
  },
  methods: {
    checkSuperAdmin() {
      const userStr = localStorage.getItem('user')
      if (userStr) {
        const user = JSON.parse(userStr)
        if (user.isSuperAdmin) {
          // Redirect Super Admins to the Super Admin Dashboard
          this.$router.push('/super-admin')
        }
      }
    },
    async loadBranches() {
      try {
        console.log('Loading branches...');
        // Load hierarchy view for better branch management
        const { data } = await api.get('/branches/hierarchy/all')
        console.log('Branches loaded:', data);
        this.branches = data
        if (this.branches.length === 0) {
          console.warn('No branches returned from API');
        }
      } catch (err) {
        console.error('Error loading branches:', err);
        console.error('Error response:', err.response?.data);
        alert('Failed to load branches: ' + (err.response?.data?.error || err.message))
      }
    },
    async saveBranch() {
      try {
        if (this.editingBranch) {
          await api.put(`/branches/${this.editingBranch.branch_id}`, this.branch)
          alert('Branch updated successfully!')
        } else {
          await api.post('/branches', this.branch)
          alert('Branch created successfully!')
        }
        
        this.branch = { branchName: '', location: '', phone: '', managerName: '', password: '', status: 'active' }
        this.editingBranch = null
        await this.loadBranches()
      } catch (err) {
        alert(err.response?.data?.error || 'Failed to save branch')
      }
    },
    editBranch(b) {
      this.editingBranch = b
      this.branch = {
        branchName: b.branch_name,
        location: b.location,
        phone: b.phone,
        managerName: b.manager_name,
        password: '',
        status: b.status
      }
      window.scrollTo({ top: 0, behavior: 'smooth' })
    },
    cancelEdit() {
      this.editingBranch = null
      this.branch = { branchName: '', location: '', phone: '', managerName: '', password: '', status: 'active' }
    },
    async deleteBranch(branchId) {
      if (!confirm('Are you sure you want to delete this branch?')) return
      
      try {
        await api.delete(`/branches/${branchId}`)
        alert('Branch deleted successfully!')
        await this.loadBranches()
      } catch (err) {
        alert('Failed to delete branch')
      }
    }
  }
}
</script>
