<template>
  <div class="home">
    <!-- Hero Section -->
    <section class="hero">
      <div class="container">
        <h1>Find Your Dream Property</h1>
        <p>Discover the best real estate deals in Ethiopia</p>
        
        <!-- Search Bar -->
        <div class="search-bar">
          <input v-model="search.keyword" type="text" placeholder="Search properties...">
          <select v-model="search.city">
            <option value="">All Cities</option>
            <option v-for="city in cities" :key="city.city_id" :value="city.city_id">
              {{ city.name }}
            </option>
          </select>
          <select v-model="search.type">
            <option value="">Property Type</option>
            <option value="apartment">Apartment</option>
            <option value="villa">Villa</option>
            <option value="house">House</option>
            <option value="commercial">Commercial</option>
            <option value="land">Land</option>
          </select>
          <select v-model="search.listing_type">
            <option value="">For Sale/Rent</option>
            <option value="sale">For Sale</option>
            <option value="rent">For Rent</option>
            <option value="lease">For Lease</option>
          </select>
          <button class="btn btn-primary" @click="searchProperties">
            <i class="fas fa-search"></i> Search
          </button>
        </div>
        
        <!-- Price Range -->
        <div class="price-range-home">
          <div class="price-inputs-home">
            <input 
              v-model.number="search.min_price" 
              type="number" 
              placeholder="Min Price (ETB)"
            >
            <span>-</span>
            <input 
              v-model.number="search.max_price" 
              type="number" 
              placeholder="Max Price (ETB)"
            >
          </div>
        </div>
      </div>
    </section>

    <!-- All Properties -->
    <section class="container" style="padding: 3rem 0;">
      <h2 style="margin-bottom: 2rem; text-align: center;">Available Properties</h2>
      
      <div v-if="loading" class="loading">
        <div class="spinner"></div>
        <p>Loading properties...</p>
      </div>

      <div v-else-if="properties.length === 0" class="loading">
        <p>No properties available</p>
      </div>

      <div v-else class="property-grid">
        <div 
          v-for="property in properties" 
          :key="property.property_id"
          class="property-card"
          @click="viewProperty(property.property_id)"
        >
          <img 
            :src="property.primary_image || '/placeholder.jpg'" 
            :alt="property.title"
            class="property-image"
          >
          <div class="property-content">
            <div class="property-price">
              {{ formatPrice(property.price) }} {{ property.currency || 'ETB' }}
            </div>
            <h3 class="property-title">{{ property.title }}</h3>
            <div class="property-location">
              <i class="fas fa-map-marker-alt"></i>
              {{ property.city_name || 'Location' }}
            </div>
            <div class="property-features">
              <span v-if="property.bedrooms">
                <i class="fas fa-bed"></i> {{ property.bedrooms }} Beds
              </span>
              <span v-if="property.bathrooms">
                <i class="fas fa-bath"></i> {{ property.bathrooms }} Baths
              </span>
              <span v-if="property.size">
                <i class="fas fa-ruler-combined"></i> {{ property.size }} m²
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Why Choose Us -->
    <section style="background: var(--light); padding: 3rem 0;">
      <div class="container">
        <h2 style="text-align: center; margin-bottom: 3rem;">Why Choose Us</h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem;">
          <div style="text-align: center;">
            <i class="fas fa-home" style="font-size: 3rem; color: var(--primary); margin-bottom: 1rem;"></i>
            <h3>Wide Selection</h3>
            <p>Browse thousands of properties across Ethiopia</p>
          </div>
          <div style="text-align: center;">
            <i class="fas fa-shield-alt" style="font-size: 3rem; color: var(--primary); margin-bottom: 1rem;"></i>
            <h3>Trusted Service</h3>
            <p>Verified listings and secure transactions</p>
          </div>
          <div style="text-align: center;">
            <i class="fas fa-headset" style="font-size: 3rem; color: var(--primary); margin-bottom: 1rem;"></i>
            <h3>24/7 Support</h3>
            <p>Our team is always here to help you</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'

const router = useRouter()
const loading = ref(true)
const properties = ref([])
const cities = ref([])

const search = ref({
  keyword: '',
  city: '',
  type: '',
  listing_type: '',
  min_price: '',
  max_price: ''
})

onMounted(async () => {
  try {
    const [propertiesRes, citiesRes] = await Promise.all([
      api.getProperties({ limit: 100 }),
      api.getCities()
    ])
    properties.value = propertiesRes.data.properties || []
    cities.value = citiesRes.data
  } catch (error) {
    console.error('Error loading data:', error)
  } finally {
    loading.value = false
  }
})

const formatPrice = (price) => {
  return new Intl.NumberFormat('en-US').format(price)
}

const viewProperty = (id) => {
  router.push(`/properties/${id}`)
}

const searchProperties = () => {
  const query = {}
  if (search.value.keyword) query.search = search.value.keyword
  if (search.value.city) query.city_id = search.value.city
  if (search.value.type) query.type = search.value.type
  if (search.value.listing_type) query.listing_type = search.value.listing_type
  if (search.value.min_price) query.min_price = search.value.min_price
  if (search.value.max_price) query.max_price = search.value.max_price
  
  router.push({ path: '/properties', query })
}
</script>

<style scoped>
.price-range-home {
  margin-top: 1rem;
  display: flex;
  justify-content: center;
}

.price-inputs-home {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: white;
  padding: 0.5rem 1rem;
  border-radius: 50px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.price-inputs-home input {
  width: 200px;
  padding: 0.75rem 1rem;
  border: 1px solid #ddd;
  border-radius: 25px;
  font-size: 1rem;
}

.price-inputs-home span {
  color: #666;
  font-weight: 500;
}
</style>
