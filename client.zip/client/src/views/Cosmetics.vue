<template>
  <div class="container">
    <div class="header-row">
      <h1>Cosmetics Management</h1>
      <div class="actions">
        <button @click="showAddModal = true" class="btn btn-primary">
          ➕ Add Cosmetic
        </button>
      </div>
    </div>
    

    
    <!-- Add New Cosmetic Product -->
    <div class="card">
      <h3>Add New Cosmetic Product</h3>
      <form @submit.prevent="addCosmetic">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div class="form-group">
            <label>Product Name *</label>
            <input v-model="cosmetic.productName" required />
          </div>
          <div class="form-group">
            <label>Brand *</label>
            <input v-model="cosmetic.brand" required />
          </div>
          <div class="form-group">
            <label>Category *</label>
            <input v-model="cosmetic.category" 
                   list="cosmetic-categories" 
                   placeholder="Skincare, Makeup, Haircare, etc." 
                   required />
            <datalist id="cosmetic-categories">
              <option value="Skincare" />
              <option value="Makeup" />
              <option value="Haircare" />
              <option value="Fragrance" />
              <option value="Body Care" />
              <option value="Nail Care" />
            </datalist>
          </div>
          <div class="form-group">
            <label>Size/Volume</label>
            <input v-model="cosmetic.size" placeholder="e.g., 50ml, 100g" />
          </div>
          <div class="form-group">
            <label>Barcode</label>
            <input v-model="cosmetic.barcode" />
          </div>
          <div class="form-group">
            <label>Purchase Price *</label>
            <input v-model.number="cosmetic.purchasePrice" type="number" step="0.01" required />
          </div>
          <div class="form-group">
            <label>Selling Price *</label>
            <input v-model.number="cosmetic.sellingPrice" type="number" step="0.01" required />
          </div>
          <div class="form-group">
            <label>Reorder Level</label>
            <input v-model.number="cosmetic.reorderLevel" type="number" value="5" />
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Add Product</button>
      </form>
    </div>

    <!-- Add Stock to Existing Product -->
    <div class="card" style="margin-top: 20px;">
      <h3>Add Stock</h3>
      <form @submit.prevent="addStock">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div class="form-group">
            <label>Search Product *</label>
            <input v-model="searchQuery" @input="searchProducts" placeholder="Search by name or barcode" />
            <div v-if="searchResults.length" style="border: 1px solid #ddd; max-height: 200px; overflow-y: auto;">
              <div v-for="prod in searchResults" :key="prod.cosmetic_id" 
                   @click="selectProduct(prod)"
                   style="padding: 10px; cursor: pointer; border-bottom: 1px solid #eee;">
                {{ prod.product_name }} - {{ prod.brand }} ({{ prod.size }})
              </div>
            </div>
            <p v-if="selectedProduct" style="margin-top: 5px; color: green;">
              Selected: {{ selectedProduct.product_name }} - {{ selectedProduct.brand }}
            </p>
          </div>
          <div class="form-group">
            <label>Batch Number *</label>
            <input v-model="stock.batchNumber" required />
          </div>
          <div class="form-group">
            <label>Expiry Date</label>
            <input v-model="stock.expiryDate" type="date" />
          </div>
          <div class="form-group">
            <label>Quantity *</label>
            <input v-model.number="stock.quantity" type="number" required />
          </div>
        </div>
        <button type="submit" class="btn btn-primary" :disabled="!selectedProduct">Add Stock</button>
      </form>
    </div>

    <!-- Cosmetics Inventory -->
    <div class="card" style="margin-top: 20px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h3>Cosmetics Inventory</h3>
        <input v-model="filterQuery" @input="filterProducts" 
               placeholder="Filter products..." 
               style="padding: 8px; width: 300px; border: 1px solid #ddd; border-radius: 4px;" />
      </div>
      
      <table class="table">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Brand</th>
            <th>Category</th>
            <th>Size</th>
            <th>Batch Number</th>
            <th>Expiry Date</th>
            <th>Stock</th>
            <th>Purchase Price</th>
            <th>Selling Price</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in filteredProducts" :key="item.stock_id">
            <td><strong>{{ item.product_name }}</strong></td>
            <td>{{ item.brand }}</td>
            <td>{{ item.category }}</td>
            <td>{{ item.size }}</td>
            <td>{{ item.batch_number }}</td>
            <td>{{ item.expiry_date ? formatDate(item.expiry_date) : '-' }}</td>
            <td>
              <strong :style="{ color: item.quantity_in_stock <= item.reorder_level ? 'red' : 'green' }">
                {{ item.quantity_in_stock }}
              </strong>
            </td>
            <td>ETB {{ item.purchase_price }}</td>
            <td>ETB {{ item.selling_price }}</td>
            <td>
              <span :style="{ 
                padding: '4px 8px', 
                borderRadius: '4px', 
                fontSize: '12px',
                backgroundColor: item.quantity_in_stock > item.reorder_level ? '#27ae60' : '#e74c3c',
                color: 'white'
              }">
                {{ item.quantity_in_stock > item.reorder_level ? 'In Stock' : 'Low Stock' }}
              </span>
            </td>
            <td>
              <div class="d-flex gap-1">
                <v-btn
                  @click="editProduct(item)"
                  color="primary"
                  size="small"
                  icon="mdi-pencil"
                  variant="tonal"
                  density="comfortable"
                ></v-btn>
                <v-btn
                  @click="adjustProductStock(item)"
                  color="orange"
                  size="small"
                  icon="mdi-package-variant"
                  variant="tonal"
                  density="comfortable"
                ></v-btn>
                <v-btn
                  @click="deleteProduct(item.cosmetic_id)"
                  color="error"
                  size="small"
                  icon="mdi-delete"
                  variant="tonal"
                  density="comfortable"
                ></v-btn>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Edit Product Modal -->
    <div v-if="showEditModal" class="modal" @click.self="closeEditModal">
      <div class="modal-content">
        <h2>Edit Product</h2>
        <form @submit.prevent="saveEdit">
          <div class="form-group">
            <label>Product Name *</label>
            <input v-model="editForm.productName" required>
          </div>
          <div class="form-group">
            <label>Brand *</label>
            <input v-model="editForm.brand" required>
          </div>
          <div class="form-group">
            <label>Category *</label>
            <input v-model="editForm.category" 
                   list="cosmetic-categories-edit" 
                   placeholder="Type or select category" 
                   required>
            <datalist id="cosmetic-categories-edit">
              <option value="Skincare" />
              <option value="Makeup" />
              <option value="Haircare" />
              <option value="Fragrance" />
              <option value="Body Care" />
              <option value="Nail Care" />
            </datalist>
          </div>
          <div class="form-group">
            <label>Size</label>
            <input v-model="editForm.size">
          </div>
          <div class="form-group">
            <label>Barcode</label>
            <input v-model="editForm.barcode">
          </div>
          <div class="form-group">
            <label>Purchase Price *</label>
            <input v-model.number="editForm.purchasePrice" type="number" step="0.01" required>
          </div>
          <div class="form-group">
            <label>Selling Price *</label>
            <input v-model.number="editForm.sellingPrice" type="number" step="0.01" required>
          </div>
          <div class="form-group">
            <label>Reorder Level</label>
            <input v-model.number="editForm.reorderLevel" type="number">
          </div>
          <div class="modal-actions">
            <button type="button" @click="closeEditModal" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn btn-primary">Update Product</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Adjust Stock Modal -->
    <div v-if="showAdjustModal" class="modal" @click.self="closeAdjustModal">
      <div class="modal-content">
        <h2>Adjust Stock</h2>
        <p><strong>{{ adjustForm.productName }}</strong></p>
        <p>Current Stock: <strong>{{ adjustForm.currentStock }}</strong></p>
        
        <form @submit.prevent="saveStockAdjustment">
          <div class="form-group">
            <label>Adjustment Type *</label>
            <select v-model="adjustForm.type" required>
              <option value="add">Add Stock</option>
              <option value="remove">Remove Stock</option>
              <option value="set">Set Exact Quantity</option>
            </select>
          </div>
          <div class="form-group">
            <label>{{ adjustForm.type === 'set' ? 'New Quantity' : 'Quantity to ' + (adjustForm.type === 'add' ? 'Add' : 'Remove') }} *</label>
            <input v-model.number="adjustForm.quantity" type="number" min="0" required>
          </div>
          <div class="form-group">
            <label>Reason *</label>
            <select v-model="adjustForm.reason" required>
              <option value="damage">Damaged</option>
              <option value="expiry">Expired</option>
              <option value="return">Return to Supplier</option>
              <option value="correction">Stock Correction</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div class="form-group">
            <label>Notes</label>
            <textarea v-model="adjustForm.notes" rows="3"></textarea>
          </div>
          <div class="modal-actions">
            <button type="button" @click="closeAdjustModal" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn btn-primary">Apply Adjustment</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../api'
import * as XLSX from 'xlsx'

export default {
  data() {
    return {
      importedData: [],
      uploadedFileName: '',
      cosmetic: {
        productName: '',
        brand: '',
        category: '',
        size: '',
        barcode: '',
        purchasePrice: 0,
        sellingPrice: 0,
        reorderLevel: 5
      },
      stock: {
        batchNumber: '',
        expiryDate: '',
        quantity: 0
      },
      products: [],
      filteredProducts: [],
      searchQuery: '',
      searchResults: [],
      selectedProduct: null,
      filterQuery: '',
      showEditModal: false,
      showAdjustModal: false,
      editForm: {
        cosmeticId: null,
        productName: '',
        brand: '',
        category: '',
        size: '',
        barcode: '',
        purchasePrice: 0,
        sellingPrice: 0,
        reorderLevel: 5
      },
      adjustForm: {
        cosmeticId: null,
        productName: '',
        currentStock: 0,
        type: 'add',
        quantity: 0,
        reason: 'correction',
        notes: ''
      }
    }
  },
  async mounted() {
    await this.loadProducts()
  },
  methods: {
    async loadProducts() {
      try {
        const { data } = await api.get('/cosmetics/inventory/batches')
        this.products = data
        this.filteredProducts = data
      } catch (err) {
        console.error(err)
      }
    },
    formatDate(dateString) {
      if (!dateString) return '-'
      const date = new Date(dateString)
      return date.toLocaleDateString()
    },
    async addCosmetic() {
      try {
        await api.post('/cosmetics', this.cosmetic)
        alert('Cosmetic product added successfully!')
        this.cosmetic = {
          productName: '',
          brand: '',
          category: '',
          size: '',
          barcode: '',
          purchasePrice: 0,
          sellingPrice: 0,
          reorderLevel: 5
        }
        await this.loadProducts()
      } catch (err) {
        alert(err.response?.data?.error || 'Failed to add product')
      }
    },
    async searchProducts() {
      if (this.searchQuery.length < 2) {
        this.searchResults = []
        return
      }
      try {
        const { data } = await api.get(`/cosmetics/search?q=${this.searchQuery}`)
        this.searchResults = data
      } catch (err) {
        console.error(err)
      }
    },
    selectProduct(prod) {
      this.selectedProduct = prod
      this.searchResults = []
      this.searchQuery = `${prod.product_name} - ${prod.brand}`
    },
    async addStock() {
      if (!this.selectedProduct) {
        alert('Please select a product first')
        return
      }
      try {
        await api.post('/cosmetics/stock', {
          cosmeticId: this.selectedProduct.cosmetic_id,
          ...this.stock
        })
        alert('Stock added successfully!')
        this.stock = { batchNumber: '', expiryDate: '', quantity: 0 }
        this.selectedProduct = null
        this.searchQuery = ''
        await this.loadProducts()
      } catch (err) {
        alert(err.response?.data?.error || 'Failed to add stock')
      }
    },
    filterProducts() {
      if (!this.filterQuery) {
        this.filteredProducts = this.products
        return
      }
      const query = this.filterQuery.toLowerCase()
      this.filteredProducts = this.products.filter(p =>
        p.product_name.toLowerCase().includes(query) ||
        p.brand.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query)
      )
    },
    downloadTemplate() {
      // Create sample data with all fields
      const template = [
        {
          'Product Name': 'Face Cream',
          'Brand': 'Nivea',
          'Category': 'Skincare',
          'Size': '50ml',
          'Purchase Price': 15.00,
          'Selling Price': 25.00,
          'Reorder Level': 10,
          'Batch Number': 'BATCH-001',
          'Quantity': 50,
          'Expiry Date': '2025-12-31',
          'Barcode': 'COS001'
        },
        {
          'Product Name': 'Lipstick',
          'Brand': 'Maybelline',
          'Category': 'Makeup',
          'Size': '3.9g',
          'Purchase Price': 8.00,
          'Selling Price': 15.00,
          'Reorder Level': 5,
          'Batch Number': 'BATCH-002',
          'Quantity': 100,
          'Expiry Date': '2026-06-30',
          'Barcode': 'COS002'
        }
      ]
      
      // Create workbook and worksheet
      const ws = XLSX.utils.json_to_sheet(template)
      const wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, ws, 'Cosmetics')
      
      // Download
      XLSX.writeFile(wb, 'cosmetics_import_template.xlsx')
    },
    handleFileUpload(event) {
      const file = event.target.files[0]
      if (!file) return
      
      this.uploadedFileName = file.name
      const reader = new FileReader()
      
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result)
          const workbook = XLSX.read(data, { type: 'array' })
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
          const jsonData = XLSX.utils.sheet_to_json(firstSheet)
          
          // Map Excel columns to our format
          this.importedData = jsonData.map(row => ({
            productName: row['Product Name'] || '',
            brand: row['Brand'] || '',
            category: row['Category'] || '',
            size: row['Size'] || '',
            barcode: row['Barcode'] || '',
            purchasePrice: parseFloat(row['Purchase Price']) || 0,
            sellingPrice: parseFloat(row['Selling Price']) || 0,
            reorderLevel: parseInt(row['Reorder Level']) || 5
          }))
          
          if (this.importedData.length === 0) {
            alert('No data found in Excel file')
          }
        } catch (err) {
          alert('Error reading Excel file: ' + err.message)
        }
      }
      
      reader.readAsArrayBuffer(file)
    },
    async importAllCosmetics() {
      if (this.importedData.length === 0) return
      
      let successCount = 0
      let errorCount = 0
      
      for (const cosmetic of this.importedData) {
        try {
          await api.post('/cosmetics', cosmetic)
          successCount++
        } catch (err) {
          errorCount++
          console.error('Failed to import:', cosmetic.productName, err)
        }
      }
      
      alert(`Import complete!\nSuccess: ${successCount}\nFailed: ${errorCount}`)
      
      if (successCount > 0) {
        this.clearImport()
        await this.loadProducts()
      }
    },
    clearImport() {
      this.importedData = []
      this.uploadedFileName = ''
      if (this.$refs.fileInput) {
        this.$refs.fileInput.value = ''
      }
    },
    editProduct(item) {
      this.editForm = {
        cosmeticId: item.cosmetic_id,
        productName: item.product_name,
        brand: item.brand,
        category: item.category,
        size: item.size,
        barcode: item.barcode,
        purchasePrice: item.purchase_price,
        sellingPrice: item.selling_price,
        reorderLevel: item.reorder_level
      }
      this.showEditModal = true
    },
    async saveEdit() {
      try {
        await api.put(`/cosmetics/${this.editForm.cosmeticId}`, {
          productName: this.editForm.productName,
          brand: this.editForm.brand,
          category: this.editForm.category,
          size: this.editForm.size,
          barcode: this.editForm.barcode,
          purchasePrice: this.editForm.purchasePrice,
          sellingPrice: this.editForm.sellingPrice,
          reorderLevel: this.editForm.reorderLevel
        })
        alert('Product updated successfully!')
        this.closeEditModal()
        await this.loadProducts()
      } catch (error) {
        alert('Error updating product: ' + (error.response?.data?.error || error.message))
      }
    },
    closeEditModal() {
      this.showEditModal = false
      this.editForm = {
        cosmeticId: null,
        productName: '',
        brand: '',
        category: '',
        size: '',
        barcode: '',
        purchasePrice: 0,
        sellingPrice: 0,
        reorderLevel: 5
      }
    },
    adjustProductStock(item) {
      this.adjustForm = {
        cosmeticId: item.cosmetic_id,
        productName: `${item.product_name} - ${item.brand} (Batch: ${item.batch_number})`,
        currentStock: item.quantity_in_stock,
        type: 'add',
        quantity: 0,
        reason: 'correction',
        notes: ''
      }
      this.showAdjustModal = true
    },
    async saveStockAdjustment() {
      try {
        let newQuantity = this.adjustForm.currentStock
        
        if (this.adjustForm.type === 'add') {
          newQuantity += this.adjustForm.quantity
        } else if (this.adjustForm.type === 'remove') {
          newQuantity -= this.adjustForm.quantity
        } else {
          newQuantity = this.adjustForm.quantity
        }

        if (newQuantity < 0) {
          alert('Quantity cannot be negative!')
          return
        }

        await api.post('/cosmetics/adjust-stock', {
          cosmeticId: this.adjustForm.cosmeticId,
          newQuantity: newQuantity,
          reason: this.adjustForm.reason,
          notes: this.adjustForm.notes
        })
        
        alert('Stock adjusted successfully!')
        this.closeAdjustModal()
        await this.loadProducts()
      } catch (error) {
        alert('Error adjusting stock: ' + (error.response?.data?.error || error.message))
      }
    },
    closeAdjustModal() {
      this.showAdjustModal = false
      this.adjustForm = {
        cosmeticId: null,
        productName: '',
        currentStock: 0,
        type: 'add',
        quantity: 0,
        reason: 'correction',
        notes: ''
      }
    },
    async deleteProduct(cosmeticId) {
      if (!confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
        return
      }

      try {
        await api.delete(`/cosmetics/${cosmeticId}`)
        alert('Product deleted successfully!')
        await this.loadProducts()
      } catch (error) {
        alert('Error deleting product: ' + (error.response?.data?.error || error.message))
      }
    }
  }
}
</script>

<style scoped>
.header-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.actions {
  display: flex;
  gap: 10px;
}

.d-flex {
  display: flex;
}

.gap-1 {
  gap: 4px;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 30px;
  border-radius: 8px;
  max-width: 600px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.form-group {
  display: flex;
  flex-direction: column;
  margin-bottom: 15px;
}

.form-group label {
  margin-bottom: 5px;
  font-weight: bold;
}

.form-group input,
.form-group select,
.form-group textarea {
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}
</style>
