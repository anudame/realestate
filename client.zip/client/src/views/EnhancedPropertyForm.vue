<template>
  <div class="property-form">
    <form @submit.prevent="$emit('save', form)">
      <!-- Basic Information -->
      <div class="form-section">
        <h3>📋 Basic Information</h3>
        <div class="form-grid">
          <div class="form-group">
            <label>Property Title *</label>
            <input v-model="form.title" type="text" required placeholder="e.g., Luxury 2 Bedroom Apartment">
          </div>

          <div class="form-group">
            <label>Property Code</label>
            <input v-model="form.property_code" type="text" readonly placeholder="Auto-generated">
          </div>

          <div class="form-group">
            <label>Property Type *</label>
            <select v-model="form.property_type" required>
              <option value="apartment">Apartment</option>
              <option value="villa">Villa</option>
              <option value="house">House</option>
              <option value="commercial">Commercial</option>
              <option value="land">Land</option>
            </select>
          </div>

          <div class="form-group">
            <label>Listing Type *</label>
            <select v-model="form.listing_type" required>
              <option value="sale">For Sale</option>
              <option value="rent">For Rent</option>
              <option value="lease">For Lease</option>
            </select>
          </div>

          <div class="form-group">
            <label>Price *</label>
            <input v-model="form.price" type="number" step="0.01" required>
          </div>

          <div class="form-group">
            <label>Price Type</label>
            <select v-model="form.price_type">
              <option value="fixed">Fixed</option>
              <option value="negotiable">Negotiable</option>
            </select>
          </div>

          <div class="form-group">
            <label>Currency</label>
            <select v-model="form.currency">
              <option value="ETB">ETB (Birr)</option>
              <option value="USD">USD (Dollar)</option>
            </select>
          </div>

          <div class="form-group">
            <label>Status</label>
            <select v-model="form.status">
              <option value="available">Available</option>
              <option value="reserved">Reserved</option>
              <option value="sold">Sold</option>
              <option value="rented">Rented</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label>Description *</label>
          <textarea v-model="form.description" rows="4" required placeholder="Full details of the property"></textarea>
        </div>
      </div>

      <!-- Size & Structure -->
      <div class="form-section">
        <h3>📐 Size & Structure</h3>
        <div class="form-grid">
          <div class="form-group">
            <label>Total Area (m²)</label>
            <input v-model="form.size" type="number" step="0.01">
          </div>

          <div class="form-group">
            <label>Built-up Area (m²)</label>
            <input v-model="form.built_up_area" type="number" step="0.01">
          </div>

          <div class="form-group">
            <label>Land Size (m²)</label>
            <input v-model="form.land_size" type="number" step="0.01">
          </div>

          <div class="form-group">
            <label>Bedrooms</label>
            <input v-model="form.bedrooms" type="number" min="0">
          </div>

          <div class="form-group">
            <label>Bathrooms</label>
            <input v-model="form.bathrooms" type="number" min="0">
          </div>

          <div class="form-group">
            <label>Living Rooms</label>
            <input v-model="form.living_rooms" type="number" min="0" value="1">
          </div>

          <div class="form-group">
            <label>Kitchen Count</label>
            <input v-model="form.kitchen_count" type="number" min="0" value="1">
          </div>

          <div class="form-group">
            <label>Parking Available</label>
            <select v-model="form.parking">
              <option :value="0">No</option>
              <option :value="1">Yes</option>
            </select>
          </div>

          <div class="form-group">
            <label>Floor Number</label>
            <input v-model="form.floor_number" type="number">
          </div>

          <div class="form-group">
            <label>Total Floors</label>
            <input v-model="form.total_floors" type="number">
          </div>

          <div class="form-group">
            <label>Year Built</label>
            <input v-model="form.year_built" type="number" min="1900" :max="new Date().getFullYear()">
          </div>

          <div class="form-group">
            <label>Furnishing</label>
            <select v-model="form.furnishing">
              <option value="unfurnished">Unfurnished</option>
              <option value="semi-furnished">Semi-furnished</option>
              <option value="furnished">Furnished</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label>
            <input v-model="form.has_balcony" type="checkbox">
            Has Balcony
          </label>
        </div>
      </div>

      <!-- Location -->
      <div class="form-section">
        <h3>📍 Location</h3>
        <div class="form-grid">
          <div class="form-group">
            <label>City *</label>
            <select v-model="form.city_id" required>
              <option value="">Select City</option>
              <option v-for="city in cities" :key="city.city_id" :value="city.city_id">
                {{ city.name }}
              </option>
            </select>
          </div>

          <div class="form-group">
            <label>Sub-City</label>
            <input v-model="form.sub_city" type="text" placeholder="e.g., Bole">
          </div>

          <div class="form-group">
            <label>Area Name</label>
            <input v-model="form.area_name" type="text" placeholder="e.g., Megenagna">
          </div>

          <div class="form-group">
            <label>Category</label>
            <select v-model="form.category_id">
              <option value="">Select Category</option>
              <option v-for="cat in categories" :key="cat.category_id" :value="cat.category_id">
                {{ cat.name }}
              </option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label>Full Address</label>
          <textarea v-model="form.address" rows="2" placeholder="Complete address"></textarea>
        </div>

        <div class="form-grid">
          <div class="form-group">
            <label>Latitude</label>
            <input v-model="form.latitude" type="number" step="0.000001" placeholder="9.0320">
          </div>

          <div class="form-group">
            <label>Longitude</label>
            <input v-model="form.longitude" type="number" step="0.000001" placeholder="38.7469">
          </div>
        </div>
      </div>

      <!-- Amenities -->
      <div class="form-section">
        <h3>✨ Amenities & Facilities</h3>
        <div class="amenities-grid">
          <label v-for="amenity in sortedAmenities" :key="amenity.amenity_id" class="amenity-checkbox">
            <input 
              type="checkbox" 
              :value="amenity.amenity_id"
              v-model="form.amenities"
            >
            <i :class="`fas fa-${amenity.icon}`"></i>
            {{ amenity.name }}
          </label>
        </div>
      </div>

      <!-- SEO & Marketing -->
      <div class="form-section">
        <h3>🎯 SEO & Marketing</h3>
        <div class="form-grid">
          <div class="form-group">
            <label>SEO Title</label>
            <input v-model="form.seo_title" type="text" placeholder="Leave empty to use property title">
          </div>

          <div class="form-group">
            <label>Highlight Tag</label>
            <select v-model="form.highlight_tag">
              <option value="none">None</option>
              <option value="hot">🔥 Hot</option>
              <option value="new">✨ New</option>
              <option value="discount">💰 Discount</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label>Meta Description</label>
          <textarea v-model="form.meta_description" rows="2" placeholder="SEO description (160 characters)"></textarea>
        </div>

        <div class="form-group">
          <label>Search Keywords (comma separated)</label>
          <input v-model="form.search_keywords" type="text" placeholder="apartment, bole, 2 bedroom">
        </div>

        <div class="form-group">
          <label>
            <input v-model="form.is_featured" type="checkbox">
            Featured Property
          </label>
        </div>
      </div>

      <!-- Admin Controls -->
      <div class="form-section" v-if="isAdmin">
        <h3>⚙️ Admin Controls</h3>
        <div class="form-grid">
          <div class="form-group">
            <label>
              <input v-model="form.is_approved" type="checkbox">
              Approved
            </label>
          </div>

          <div class="form-group">
            <label>
              <input v-model="form.is_hidden" type="checkbox">
              Hidden
            </label>
          </div>

          <div class="form-group">
            <label>Expiry Date</label>
            <input v-model="form.expiry_date" type="date">
          </div>
        </div>
      </div>

      <!-- Form Actions -->
      <div class="form-actions">
        <button type="button" class="btn btn-outline" @click="$emit('cancel')">Cancel</button>
        <button type="submit" class="btn btn-primary">
          <i class="fas fa-save"></i> {{ editMode ? 'Update' : 'Create' }} Property
        </button>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref, watch, computed } from 'vue'

const props = defineProps({
  modelValue: Object,
  cities: Array,
  categories: Array,
  amenities: Array,
  editMode: Boolean,
  isAdmin: Boolean
})

const emit = defineEmits(['save', 'cancel', 'update:modelValue'])

// Sort amenities alphabetically
const sortedAmenities = computed(() => {
  if (!props.amenities) return []
  return [...props.amenities].sort((a, b) => a.name.localeCompare(b.name))
})

const form = ref({
  title: '',
  property_code: '',
  property_type: 'apartment',
  listing_type: 'sale',
  price: '',
  price_type: 'fixed',
  currency: 'ETB',
  status: 'available',
  description: '',
  size: '',
  built_up_area: '',
  land_size: '',
  bedrooms: 0,
  bathrooms: 0,
  living_rooms: 1,
  kitchen_count: 1,
  has_balcony: false,
  parking: 0,
  floor_number: '',
  total_floors: '',
  year_built: '',
  furnishing: 'unfurnished',
  city_id: '',
  sub_city: '',
  area_name: '',
  address: '',
  latitude: '',
  longitude: '',
  category_id: '',
  amenities: [],
  seo_title: '',
  meta_description: '',
  search_keywords: '',
  highlight_tag: 'none',
  is_featured: false,
  is_approved: false,
  is_hidden: false,
  expiry_date: '',
  ...props.modelValue
})

watch(() => props.modelValue, (newVal) => {
  if (newVal) {
    Object.assign(form.value, newVal)
  }
}, { deep: true })
</script>

<style scoped>
.property-form {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.form-section {
  margin-bottom: 2rem;
  padding-bottom: 2rem;
  border-bottom: 1px solid #eee;
}

.form-section:last-of-type {
  border-bottom: none;
}

.form-section h3 {
  margin-bottom: 1rem;
  color: #333;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
}

.form-group {
  margin-bottom: 1rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
  color: #555;
}

.form-group input[type="text"],
.form-group input[type="number"],
.form-group input[type="date"],
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}

.form-group input[type="checkbox"] {
  margin-right: 0.5rem;
}

.amenities-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 0.75rem;
}

.amenity-checkbox {
  display: flex;
  align-items: center;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
}

.amenity-checkbox:hover {
  background: #f8f9fa;
  border-color: #007bff;
}

.amenity-checkbox input {
  margin-right: 0.5rem;
}

.amenity-checkbox i {
  margin-right: 0.5rem;
  color: #007bff;
}

.form-actions {
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 2rem;
  padding-top: 2rem;
  border-top: 2px solid #eee;
}

.btn {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-primary {
  background: #007bff;
  color: white;
}

.btn-primary:hover {
  background: #0056b3;
}

.btn-outline {
  background: white;
  color: #007bff;
  border: 1px solid #007bff;
}

.btn-outline:hover {
  background: #007bff;
  color: white;
}
</style>
