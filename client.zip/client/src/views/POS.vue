<template>
  <v-container fluid>
    <v-row class="mb-4">
      <v-col cols="12">
        <h1 class="text-h4 font-weight-bold">
          <v-icon size="32" class="mr-2" color="primary">mdi-cash-register</v-icon>
          Point of Sale
        </h1>
      </v-col>
    </v-row>

    <v-row>
      <!-- Left Panel - Product Search & Cart -->
      <v-col cols="12" md="8">
        <v-card elevation="4" class="pos-card mb-4">
          <v-card-title class="d-flex align-center">
            <v-icon class="mr-2">mdi-magnify</v-icon>
            Product Search
          </v-card-title>
          <v-divider></v-divider>
          <v-card-text>
            <!-- Product Type Toggle -->
            <v-btn-toggle
              v-model="productType"
              mandatory
              color="primary"
              class="mb-4"
              rounded="lg"
            >
              <v-btn value="medicine" size="large">
                <v-icon left>mdi-pill</v-icon>
                Medicines
              </v-btn>
              <v-btn value="cosmetic" size="large">
                <v-icon left>mdi-lipstick</v-icon>
                Cosmetics
              </v-btn>
            </v-btn-toggle>

            <!-- Search Field -->
            <v-text-field
              v-model="searchQuery"
              @input="searchProduct"
              label="Scan barcode or search product"
              prepend-inner-icon="mdi-barcode-scan"
              variant="outlined"
              clearable
              autofocus
              hide-details
            ></v-text-field>

            <!-- Search Results -->
            <v-list v-if="searchResults.length" class="mt-4" elevation="2" rounded>
              <v-list-item
                v-for="item in searchResults"
                :key="item.id"
                @click="addToCart(item)"
                class="search-result-item"
              >
                <template v-slot:prepend>
                  <v-avatar :color="productType === 'medicine' ? 'primary' : 'pink'">
                    <v-icon color="white">{{ productType === 'medicine' ? 'mdi-pill' : 'mdi-lipstick' }}</v-icon>
                  </v-avatar>
                </template>
                <v-list-item-title v-if="productType === 'medicine'">
                  {{ item.generic_name }} - {{ item.brand_name }}
                </v-list-item-title>
                <v-list-item-title v-else>
                  {{ item.product_name }} - {{ item.brand }}
                </v-list-item-title>
                <v-list-item-subtitle>
                  <v-chip size="small" :color="item.total_stock > 0 ? 'success' : 'error'">
                    Stock: {{ item.total_stock }}
                  </v-chip>
                </v-list-item-subtitle>
              </v-list-item>
            </v-list>
          </v-card-text>
        </v-card>

        <!-- Cart -->
        <v-card elevation="4" class="pos-card">
          <v-card-title class="d-flex align-center justify-space-between">
            <div>
              <v-icon class="mr-2">mdi-cart</v-icon>
              Shopping Cart
            </div>
            <v-chip color="primary">{{ cart.length }} items</v-chip>
          </v-card-title>
          <v-divider></v-divider>
          <v-card-text>
            <v-table v-if="cart.length > 0" density="comfortable">
              <thead>
                <tr>
                  <th>Product</th>
                  <th class="text-center">Quantity</th>
                  <th class="text-right">Price</th>
                  <th class="text-right">Total</th>
                  <th class="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, idx) in cart" :key="idx" class="cart-item">
                  <td>
                    <div class="font-weight-medium">{{ item.name }}</div>
                  </td>
                  <td class="text-center">
                    <v-text-field
                      v-model.number="item.quantity"
                      type="number"
                      min="1"
                      density="compact"
                      variant="outlined"
                      hide-details
                      style="width: 80px; margin: 0 auto;"
                    ></v-text-field>
                  </td>
                  <td class="text-right">ETB {{ Number(item.price).toFixed(2) }}</td>
                  <td class="text-right font-weight-bold text-primary">
                    ETB {{ (Number(item.quantity) * Number(item.price)).toFixed(2) }}
                  </td>
                  <td class="text-center">
                    <v-btn
                      icon="mdi-delete"
                      size="small"
                      color="error"
                      variant="text"
                      @click="removeFromCart(idx)"
                    ></v-btn>
                  </td>
                </tr>
              </tbody>
            </v-table>
            <v-alert v-else type="info" variant="tonal" class="mt-4">
              <v-icon left>mdi-cart-outline</v-icon>
              Cart is empty. Search and add products to start a sale.
            </v-alert>
          </v-card-text>
        </v-card>
      </v-col>

      <!-- Right Panel - Summary & Checkout -->
      <v-col cols="12" md="4">
        <v-card elevation="8" class="summary-card gradient-primary">
          <v-card-title class="text-white">
            <v-icon class="mr-2" color="white">mdi-receipt</v-icon>
            Order Summary
          </v-card-title>
          <v-divider color="white" opacity="0.3"></v-divider>
          <v-card-text class="text-white">
            <!-- Subtotal -->
            <div class="d-flex justify-space-between align-center mb-4">
              <span class="text-h6">Subtotal:</span>
              <span class="text-h5 font-weight-bold">ETB {{ subtotal.toFixed(2) }}</span>
            </div>

            <!-- Tax Toggle -->
            <v-switch
              v-model="applyTax"
              label="Apply Tax (15%)"
              color="white"
              hide-details
              class="mb-2"
            ></v-switch>

            <!-- Tax Amount -->
            <div v-if="applyTax" class="d-flex justify-space-between align-center mb-4">
              <span class="text-subtitle-1">Tax (15%):</span>
              <span class="text-h6">ETB {{ tax.toFixed(2) }}</span>
            </div>

            <v-divider color="white" opacity="0.3" class="my-4"></v-divider>

            <!-- Total -->
            <div class="d-flex justify-space-between align-center mb-4">
              <span class="text-h5">Total:</span>
              <span class="text-h4 font-weight-bold">ETB {{ total.toFixed(2) }}</span>
            </div>

            <!-- Payment Mode -->
            <v-select
              v-model="paymentMode"
              :items="paymentModes"
              label="Payment Mode"
              prepend-inner-icon="mdi-cash"
              variant="outlined"
              bg-color="white"
              class="mb-4"
            ></v-select>

            <!-- Mobile Payment Transaction Code -->
            <v-expand-transition>
              <v-text-field
                v-if="paymentMode === 'mobile'"
                v-model="transactionCode"
                label="Transaction Code"
                prepend-inner-icon="mdi-cellphone"
                variant="outlined"
                bg-color="white"
                required
                :rules="[v => !!v || 'Transaction code is required']"
                hint="Enter mobile payment transaction code"
                persistent-hint
                class="mb-4"
              ></v-text-field>
            </v-expand-transition>

            <!-- Complete Sale Button -->
            <v-btn
              @click="completeSale"
              :disabled="cart.length === 0 || (paymentMode === 'mobile' && !transactionCode)"
              color="white"
              size="x-large"
              block
              class="complete-sale-btn"
            >
              <v-icon left>mdi-check-circle</v-icon>
              Complete Sale
            </v-btn>
          </v-card-text>
        </v-card>

        <!-- Quick Stats -->
        <v-card elevation="4" class="mt-4">
          <v-card-text>
            <div class="text-center">
              <v-icon size="48" color="success" class="mb-2">mdi-cart-check</v-icon>
              <div class="text-h6 text-medium-emphasis">Items in Cart</div>
              <div class="text-h3 font-weight-bold text-primary">{{ cart.length }}</div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <!-- Success Snackbar -->
    <v-snackbar
      v-model="snackbar"
      :color="snackbarColor"
      timeout="3000"
      location="top"
    >
      {{ snackbarText }}
      <template v-slot:actions>
        <v-btn variant="text" @click="snackbar = false">Close</v-btn>
      </template>
    </v-snackbar>
  </v-container>
</template>

<script>
import api from '../api'

export default {
  data() {
    return {
      searchQuery: '',
      searchResults: [],
      cart: [],
      paymentMode: 'cash',
      applyTax: false,
      productType: 'medicine',
      transactionCode: '',
      snackbar: false,
      snackbarText: '',
      snackbarColor: 'success',
      paymentModes: [
        { title: 'Cash', value: 'cash' },
        { title: 'Card', value: 'card' },
        { title: 'Mobile Payment', value: 'mobile' }
      ]
    }
  },
  computed: {
    subtotal() {
      return this.cart.reduce((sum, item) => sum + (item.quantity * item.price), 0)
    },
    tax() {
      return this.applyTax ? this.subtotal * 0.15 : 0
    },
    total() {
      return this.subtotal + this.tax
    }
  },
  methods: {
    async searchProduct() {
      if (this.searchQuery.length < 2) {
        this.searchResults = []
        return
      }
      try {
        if (this.productType === 'medicine') {
          const { data } = await api.get(`/medicines/search?q=${this.searchQuery}`)
          this.searchResults = data.map(m => ({ ...m, id: m.medicine_id }))
        } else {
          const { data } = await api.get(`/cosmetics/search?q=${this.searchQuery}`)
          this.searchResults = data.map(c => ({ ...c, id: c.cosmetic_id }))
        }
      } catch (err) {
        console.error(err)
      }
    },
    async addToCart(item) {
      if (this.productType === 'medicine') {
        const { data: batches } = await api.get(`/stock/medicine/${item.medicine_id}`)
        if (batches.length === 0) {
          this.showSnackbar('No stock available', 'error')
          return
        }
        
        const sellingPrice = item.default_selling_price || batches[0].selling_price || 0
        
        if (!sellingPrice || sellingPrice === 0) {
          this.showSnackbar('This medicine has no selling price set', 'error')
          return
        }
        
        this.cart.push({
          type: 'medicine',
          medicineId: item.medicine_id,
          batchId: batches[0].batch_id,
          name: `${item.generic_name} - ${item.brand_name}`,
          quantity: 1,
          price: Number(sellingPrice),
          unitPrice: Number(sellingPrice)
        })
      } else {
        const { data: stock } = await api.get(`/cosmetics/${item.cosmetic_id}/stock`)
        if (stock.length === 0) {
          this.showSnackbar('No stock available', 'error')
          return
        }
        
        const sellingPrice = item.selling_price || stock[0].selling_price || 0
        
        if (!sellingPrice || sellingPrice === 0) {
          this.showSnackbar('This cosmetic has no selling price set', 'error')
          return
        }
        
        this.cart.push({
          type: 'cosmetic',
          cosmeticId: item.cosmetic_id,
          stockId: stock[0].stock_id,
          name: `${item.product_name} - ${item.brand}`,
          quantity: 1,
          price: Number(sellingPrice),
          unitPrice: Number(sellingPrice)
        })
      }
      
      this.searchQuery = ''
      this.searchResults = []
      this.showSnackbar('Product added to cart', 'success')
    },
    removeFromCart(index) {
      this.cart.splice(index, 1)
      this.showSnackbar('Product removed from cart', 'info')
    },
    async completeSale() {
      if (this.cart.length === 0) return
      
      if (this.paymentMode === 'mobile' && !this.transactionCode) {
        this.showSnackbar('Please enter the mobile payment transaction code', 'error')
        return
      }
      
      try {
        const medicines = this.cart.filter(item => item.type === 'medicine')
        const cosmetics = this.cart.filter(item => item.type === 'cosmetic')
        
        await api.post('/sales', {
          customerId: null,
          items: medicines,
          cosmetics: cosmetics,
          paymentMode: this.paymentMode,
          discount: 0,
          applyTax: this.applyTax,
          transactionCode: this.paymentMode === 'mobile' ? this.transactionCode : null
        })
        
        this.showSnackbar('Sale completed successfully!', 'success')
        this.cart = []
        this.applyTax = false
        this.transactionCode = ''
      } catch (err) {
        this.showSnackbar(err.response?.data?.error || 'Sale failed', 'error')
      }
    },
    showSnackbar(text, color) {
      this.snackbarText = text
      this.snackbarColor = color
      this.snackbar = true
    }
  }
}
</script>

<style scoped>
.pos-card {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.pos-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.12) !important;
}

.search-result-item {
  cursor: pointer;
  transition: all 0.2s;
}

.search-result-item:hover {
  background: rgba(99, 102, 241, 0.05);
  transform: scale(1.02);
}

.cart-item {
  transition: all 0.2s;
}

.cart-item:hover {
  background: rgba(99, 102, 241, 0.03);
}

.summary-card {
  position: sticky;
  top: 80px;
}

.gradient-primary {
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
}

.complete-sale-btn {
  color: #6366f1 !important;
  font-weight: bold;
  letter-spacing: 0.5px;
  transition: all 0.3s;
}

.complete-sale-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.v-card {
  animation: fadeInUp 0.5s ease-out;
}
</style>
