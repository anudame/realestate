import { ref } from 'vue'

const dialogState = ref({
  isOpen: false,
  type: 'info',
  title: '',
  message: '',
  confirmText: 'OK',
  cancelText: 'Cancel',
  showCancel: false,
  onConfirm: null,
  onCancel: null
})

export function useDialog() {
  const showDialog = (options) => {
    return new Promise((resolve) => {
      dialogState.value = {
        isOpen: true,
        type: options.type || 'info',
        title: options.title || 'Notification',
        message: options.message || '',
        confirmText: options.confirmText || 'OK',
        cancelText: options.cancelText || 'Cancel',
        showCancel: options.showCancel || false,
        onConfirm: () => resolve(true),
        onCancel: () => resolve(false)
      }
    })
  }

  const alert = (message, title = 'Alert', type = 'info') => {
    return showDialog({
      type,
      title,
      message,
      showCancel: false
    })
  }

  const confirm = (message, title = 'Confirm') => {
    return showDialog({
      type: 'confirm',
      title,
      message,
      confirmText: 'Yes',
      cancelText: 'No',
      showCancel: true
    })
  }

  const success = (message, title = 'Success') => {
    return showDialog({
      type: 'success',
      title,
      message,
      showCancel: false
    })
  }

  const error = (message, title = 'Error') => {
    return showDialog({
      type: 'error',
      title,
      message,
      showCancel: false
    })
  }

  const warning = (message, title = 'Warning') => {
    return showDialog({
      type: 'warning',
      title,
      message,
      showCancel: false
    })
  }

  const closeDialog = () => {
    dialogState.value.isOpen = false
  }

  const handleConfirm = () => {
    if (dialogState.value.onConfirm) {
      dialogState.value.onConfirm()
    }
    closeDialog()
  }

  const handleCancel = () => {
    if (dialogState.value.onCancel) {
      dialogState.value.onCancel()
    }
    closeDialog()
  }

  return {
    dialogState,
    showDialog,
    alert,
    confirm,
    success,
    error,
    warning,
    closeDialog,
    handleConfirm,
    handleCancel
  }
}
