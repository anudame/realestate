import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/Home.vue')
  },
  {
    path: '/properties',
    name: 'Properties',
    component: () => import('../views/Properties.vue')
  },
  {
    path: '/properties/:id',
    name: 'PropertyDetails',
    component: () => import('../views/PropertyDetails.vue')
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue')
  },
  {
    path: '/contact',
    name: 'Contact',
    component: () => import('../views/Contact.vue')
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue')
  },
  {
    path: '/admin',
    name: 'Admin',
    component: () => import('../views/Admin.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/admin/properties',
    name: 'ManageProperties',
    component: () => import('../views/ManageProperties.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/admin/bookings',
    name: 'ManageBookings',
    component: () => import('../views/ManageBookings.vue'),
    meta: { requiresAuth: true }
  },

  {
    path: '/admin/inquiries',
    name: 'ManageInquiries',
    component: () => import('../views/ManageInquiries.vue'),
    meta: { requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior() {
    return { top: 0 }
  }
})

router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()
  
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next('/login')
  } else if (to.meta.requiresAdmin && authStore.user?.role !== 'admin') {
    next('/admin')
  } else {
    next()
  }
})

export default router
